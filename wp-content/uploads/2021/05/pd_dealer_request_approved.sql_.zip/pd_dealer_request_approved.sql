-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2021 at 12:40 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poultry-demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `pd_dealer_request_approved`
--

CREATE TABLE `pd_dealer_request_approved` (
  `id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `request_id` int(15) NOT NULL,
  `pickup_date` datetime NOT NULL DEFAULT current_timestamp(),
  `approved_qty` varchar(20) NOT NULL,
  `farm_id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `integrator_id` int(11) NOT NULL,
  `supervisor_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pd_dealer_request_approved`
--

INSERT INTO `pd_dealer_request_approved` (`id`, `dealer_id`, `request_id`, `pickup_date`, `approved_qty`, `farm_id`, `batch_id`, `integrator_id`, `supervisor_id`, `created_on`, `updated_on`) VALUES
(14, 62, 7, '2021-04-26 00:00:00', '200', 2048, 2113, 1, 53, '2021-04-27 16:02:29', '2021-04-28 10:46:36'),
(15, 62, 7, '2021-04-26 00:00:00', '200', 2048, 2113, 1, 53, '2021-04-27 17:48:58', '2021-04-28 10:46:42'),
(16, 62, 9, '2021-04-13 00:00:00', '50', 2048, 2113, 1, 53, '2021-04-28 10:56:55', '2021-04-28 10:56:55'),
(17, 62, 9, '2021-04-13 00:00:00', '50', 2048, 2113, 1, 53, '2021-04-28 11:35:31', '2021-04-28 11:35:31'),
(18, 62, 5, '2021-04-26 00:00:00', '100', 2048, 2113, 1, 53, '2021-04-28 11:45:38', '2021-04-28 11:45:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pd_dealer_request_approved`
--
ALTER TABLE `pd_dealer_request_approved`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pd_dealer_request_approved`
--
ALTER TABLE `pd_dealer_request_approved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
