-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2021 at 07:46 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upstore`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `empty_custom_table_data` ()  BEGIN
TRUNCATE TABLE us_items;
TRUNCATE TABLE us_services;
TRUNCATE table us_shops;
TRUNCATE TABLE us_user_data;
TRUNCATE TABLE us_user_relation;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `us_actionscheduler_actions`
--

CREATE TABLE `us_actionscheduler_actions` (
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `hook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheduled_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_actionscheduler_actions`
--

INSERT INTO `us_actionscheduler_actions` (`action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(452, 'action_scheduler/migration_hook', 'complete', '2021-04-06 15:56:28', '2021-04-06 15:56:28', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1617724588;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1617724588;}', 1, 1, '2021-04-06 15:56:52', '2021-04-06 15:56:52', 0, NULL),
(453, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[1]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 2, 1, '2021-04-06 15:57:31', '2021-04-06 15:57:31', 0, NULL),
(454, 'action_scheduler/migration_hook', 'complete', '2021-04-07 02:41:57', '2021-04-07 02:41:57', '[]', 'O:30:\"ActionScheduler_SimpleSchedule\":2:{s:22:\"\0*\0scheduled_timestamp\";i:1617763317;s:41:\"\0ActionScheduler_SimpleSchedule\0timestamp\";i:1617763317;}', 1, 1, '2021-04-07 02:42:52', '2021-04-07 02:42:52', 0, NULL),
(455, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[2]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 2, 1, '2021-04-19 06:03:56', '2021-04-19 06:03:56', 0, NULL),
(456, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[3]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 2, 1, '2021-04-19 06:14:16', '2021-04-19 06:14:16', 0, NULL),
(457, 'wp_mail_smtp_admin_notifications_update', 'complete', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '[4]', 'O:28:\"ActionScheduler_NullSchedule\":0:{}', 2, 1, '2021-05-01 04:59:05', '2021-05-01 04:59:05', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `us_actionscheduler_claims`
--

CREATE TABLE `us_actionscheduler_claims` (
  `claim_id` bigint(20) UNSIGNED NOT NULL,
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `us_actionscheduler_groups`
--

CREATE TABLE `us_actionscheduler_groups` (
  `group_id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_actionscheduler_groups`
--

INSERT INTO `us_actionscheduler_groups` (`group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'wp_mail_smtp');

-- --------------------------------------------------------

--
-- Table structure for table `us_actionscheduler_logs`
--

CREATE TABLE `us_actionscheduler_logs` (
  `log_id` bigint(20) UNSIGNED NOT NULL,
  `action_id` bigint(20) UNSIGNED NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_actionscheduler_logs`
--

INSERT INTO `us_actionscheduler_logs` (`log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 452, 'action created', '2021-04-06 15:55:28', '2021-04-06 15:55:28'),
(2, 452, 'action started via WP Cron', '2021-04-06 15:56:52', '2021-04-06 15:56:52'),
(3, 452, 'action complete via WP Cron', '2021-04-06 15:56:52', '2021-04-06 15:56:52'),
(4, 453, 'action created', '2021-04-06 15:57:04', '2021-04-06 15:57:04'),
(5, 453, 'action started via WP Cron', '2021-04-06 15:57:31', '2021-04-06 15:57:31'),
(6, 453, 'action complete via WP Cron', '2021-04-06 15:57:31', '2021-04-06 15:57:31'),
(7, 454, 'action created', '2021-04-07 02:40:57', '2021-04-07 02:40:57'),
(8, 454, 'action started via WP Cron', '2021-04-07 02:42:52', '2021-04-07 02:42:52'),
(9, 454, 'action complete via WP Cron', '2021-04-07 02:42:52', '2021-04-07 02:42:52'),
(10, 455, 'action created', '2021-04-19 05:56:02', '2021-04-19 05:56:02'),
(11, 455, 'action started via WP Cron', '2021-04-19 06:03:56', '2021-04-19 06:03:56'),
(12, 455, 'action complete via WP Cron', '2021-04-19 06:03:56', '2021-04-19 06:03:56'),
(13, 456, 'action created', '2021-04-19 06:03:56', '2021-04-19 06:03:56'),
(14, 456, 'action started via WP Cron', '2021-04-19 06:14:15', '2021-04-19 06:14:15'),
(15, 456, 'action complete via WP Cron', '2021-04-19 06:14:16', '2021-04-19 06:14:16'),
(16, 457, 'action created', '2021-05-01 04:44:08', '2021-05-01 04:44:08'),
(17, 457, 'action started via WP Cron', '2021-05-01 04:59:04', '2021-05-01 04:59:04'),
(18, 457, 'action complete via WP Cron', '2021-05-01 04:59:05', '2021-05-01 04:59:05');

-- --------------------------------------------------------

--
-- Table structure for table `us_commentmeta`
--

CREATE TABLE `us_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `us_comments`
--

CREATE TABLE `us_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_comments`
--

INSERT INTO `us_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-03-10 04:05:09', '2021-03-10 04:05:09', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_districts`
--

CREATE TABLE `us_districts` (
  `id` int(8) NOT NULL DEFAULT 0,
  `state_id` int(8) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `us_districts`
--

INSERT INTO `us_districts` (`id`, `state_id`, `name`) VALUES
(1, 1, 'North Andaman'),
(2, 1, 'South Andaman'),
(3, 1, 'Nicobar'),
(4, 2, 'Adilabad'),
(5, 2, 'Anantapur'),
(6, 2, 'Chittoor'),
(7, 2, 'East Godavari'),
(8, 2, 'Guntur'),
(9, 2, 'Hyderabad'),
(10, 2, 'Karimnagar'),
(11, 2, 'Khammam'),
(12, 2, 'Krishna'),
(13, 2, 'Kurnool'),
(14, 2, 'Mahbubnagar'),
(15, 2, 'Medak'),
(16, 2, 'Nalgonda'),
(17, 2, 'Nizamabad'),
(18, 2, 'Prakasam'),
(19, 2, 'Ranga Reddy'),
(20, 2, 'Srikakulam'),
(21, 2, 'Sri Potti Sri Ramulu Nellore'),
(22, 2, 'Vishakhapatnam'),
(23, 2, 'Vizianagaram'),
(24, 2, 'Warangal'),
(25, 2, 'West Godavari'),
(26, 2, 'Cudappah'),
(27, 3, 'Anjaw'),
(28, 3, 'Changlang'),
(29, 3, 'East Siang'),
(30, 3, 'East Kameng'),
(31, 3, 'Kurung Kumey'),
(32, 3, 'Lohit'),
(33, 3, 'Lower Dibang Valley'),
(34, 3, 'Lower Subansiri'),
(35, 3, 'Papum Pare'),
(36, 3, 'Tawang'),
(37, 3, 'Tirap'),
(38, 3, 'Dibang Valley'),
(39, 3, 'Upper Siang'),
(40, 3, 'Upper Subansiri'),
(41, 3, 'West Kameng'),
(42, 3, 'West Siang'),
(43, 4, 'Baksa'),
(44, 4, 'Barpeta'),
(45, 4, 'Bongaigaon'),
(46, 4, 'Cachar'),
(47, 4, 'Chirang'),
(48, 4, 'Darrang'),
(49, 4, 'Dhemaji'),
(50, 4, 'Dima Hasao'),
(51, 4, 'Dhubri'),
(52, 4, 'Dibrugarh'),
(53, 4, 'Goalpara'),
(54, 4, 'Golaghat'),
(55, 4, 'Hailakandi'),
(56, 4, 'Jorhat'),
(57, 4, 'Kamrup'),
(58, 4, 'Kamrup Metropolitan'),
(59, 4, 'Karbi Anglong'),
(60, 4, 'Karimganj'),
(61, 4, 'Kokrajhar'),
(62, 4, 'Lakhimpur'),
(63, 4, 'Morigaon'),
(64, 4, 'Nagaon'),
(65, 4, 'Nalbari'),
(66, 4, 'Sivasagar'),
(67, 4, 'Sonitpur'),
(68, 4, 'Tinsukia'),
(69, 4, 'Udalguri'),
(70, 5, 'Araria'),
(71, 5, 'Arwal'),
(72, 5, 'Aurangabad'),
(73, 5, 'Banka'),
(74, 5, 'Begusarai'),
(75, 5, 'Bhagalpur'),
(76, 5, 'Bhojpur'),
(77, 5, 'Buxar'),
(78, 5, 'Darbhanga'),
(79, 5, 'East Champaran'),
(80, 5, 'Gaya'),
(81, 5, 'Gopalganj'),
(82, 5, 'Jamui'),
(83, 5, 'Jehanabad'),
(84, 5, 'Kaimur'),
(85, 5, 'Katihar'),
(86, 5, 'Khagaria'),
(87, 5, 'Kishanganj'),
(88, 5, 'Lakhisarai'),
(89, 5, 'Madhepura'),
(90, 5, 'Madhubani'),
(91, 5, 'Munger'),
(92, 5, 'Muzaffarpur'),
(93, 5, 'Nalanda'),
(94, 5, 'Nawada'),
(95, 5, 'Patna'),
(96, 5, 'Purnia'),
(97, 5, 'Rohtas'),
(98, 5, 'Saharsa'),
(99, 5, 'Samastipur'),
(100, 5, 'Saran'),
(101, 5, 'Sheikhpura'),
(102, 5, 'Sheohar'),
(103, 5, 'Sitamarhi'),
(104, 5, 'Siwan'),
(105, 5, 'Supaul'),
(106, 6, 'Chandigarh'),
(107, 7, 'Bastar'),
(108, 7, 'Bijapur'),
(109, 7, 'Bilaspur'),
(110, 7, 'Dantewada'),
(111, 7, 'Dhamtari'),
(112, 7, 'Durg'),
(113, 7, 'Jashpur'),
(114, 7, 'Janjgir-Champa'),
(115, 7, 'Korba'),
(116, 7, 'Koriya'),
(117, 7, 'Kanker'),
(118, 7, 'Kabirdham (formerly Kawardha)'),
(119, 7, 'Mahasamund'),
(120, 7, 'Narayanpur'),
(121, 7, 'Raigarh'),
(122, 7, 'Rajnandgaon'),
(123, 7, 'Raipur'),
(124, 7, 'Surguja'),
(125, 8, 'Dadra and Nagar Haveli'),
(126, 9, 'Daman'),
(127, 9, 'Diu'),
(128, 10, 'Central Delhi'),
(129, 10, 'East Delhi'),
(130, 10, 'New Delhi'),
(131, 10, 'North Delhi'),
(132, 10, 'North East Delhi'),
(133, 10, 'North West Delhi'),
(134, 10, 'South Delhi'),
(135, 10, 'South West Delhi'),
(136, 10, 'West Delhi'),
(137, 11, 'North Goa'),
(138, 11, 'South Goa'),
(139, 12, 'Ahmedabad'),
(140, 12, 'Amreli district'),
(141, 12, 'Anand'),
(142, 12, 'Banaskantha'),
(143, 12, 'Bharuch'),
(144, 12, 'Bhavnagar'),
(145, 12, 'Dahod'),
(146, 12, 'The Dangs'),
(147, 12, 'Gandhinagar'),
(148, 12, 'Jamnagar'),
(149, 12, 'Junagadh'),
(150, 12, 'Kutch'),
(151, 12, 'Kheda'),
(152, 12, 'Mehsana'),
(153, 12, 'Narmada'),
(154, 12, 'Navsari'),
(155, 12, 'Patan'),
(156, 12, 'Panchmahal'),
(157, 12, 'Porbandar'),
(158, 12, 'Rajkot'),
(159, 12, 'Sabarkantha'),
(160, 12, 'Surendranagar'),
(161, 12, 'Surat'),
(162, 12, 'Tapi'),
(163, 12, 'Vadodara'),
(164, 12, 'Valsad'),
(165, 13, 'Ambala'),
(166, 13, 'Bhiwani'),
(167, 13, 'Faridabad'),
(168, 13, 'Fatehabad'),
(169, 13, 'Gurgaon'),
(170, 13, 'Hissar'),
(171, 13, 'Jhajjar'),
(172, 13, 'Jind'),
(173, 13, 'Karnal'),
(174, 13, 'Kaithal'),
(175, 13, 'Kurukshetra'),
(176, 13, 'Mahendragarh'),
(177, 13, 'Mewat'),
(178, 13, 'Palwal'),
(179, 13, 'Panchkula'),
(180, 13, 'Panipat'),
(181, 13, 'Rewari'),
(182, 13, 'Rohtak'),
(183, 13, 'Sirsa'),
(184, 13, 'Sonipat'),
(185, 13, 'Yamuna Nagar'),
(186, 14, 'Bilaspur'),
(187, 14, 'Chamba'),
(188, 14, 'Hamirpur'),
(189, 14, 'Kangra'),
(190, 14, 'Kinnaur'),
(191, 14, 'Kullu'),
(192, 14, 'Lahaul and Spiti'),
(193, 14, 'Mandi'),
(194, 14, 'Shimla'),
(195, 14, 'Sirmaur'),
(196, 14, 'Solan'),
(197, 14, 'Una'),
(198, 15, 'Anantnag'),
(199, 15, 'Badgam'),
(200, 15, 'Bandipora'),
(201, 15, 'Baramulla'),
(202, 15, 'Doda'),
(203, 15, 'Ganderbal'),
(204, 15, 'Jammu'),
(205, 15, 'Kargil'),
(206, 15, 'Kathua'),
(207, 15, 'Kishtwar'),
(208, 15, 'Kupwara'),
(209, 15, 'Kulgam'),
(210, 15, 'Leh'),
(211, 15, 'Poonch'),
(212, 15, 'Pulwama'),
(213, 15, 'Rajouri'),
(214, 15, 'Ramban'),
(215, 15, 'Reasi'),
(216, 15, 'Samba'),
(217, 15, 'Shopian'),
(218, 15, 'Srinagar'),
(219, 15, 'Udhampur'),
(220, 16, 'Bokaro'),
(221, 16, 'Chatra'),
(222, 16, 'Deoghar'),
(223, 16, 'Dhanbad'),
(224, 16, 'Dumka'),
(225, 16, 'East Singhbhum'),
(226, 16, 'Garhwa'),
(227, 16, 'Giridih'),
(228, 16, 'Godda'),
(229, 16, 'Gumla'),
(230, 16, 'Hazaribag'),
(231, 16, 'Jamtara'),
(232, 16, 'Khunti'),
(233, 16, 'Koderma'),
(234, 16, 'Latehar'),
(235, 16, 'Lohardaga'),
(236, 16, 'Pakur'),
(237, 16, 'Palamu'),
(238, 16, 'Ramgarh'),
(239, 16, 'Ranchi'),
(240, 16, 'Sahibganj'),
(241, 16, 'Seraikela Kharsawan'),
(242, 16, 'Simdega'),
(243, 16, 'West Singhbhum'),
(244, 17, 'Bagalkot'),
(245, 17, 'Bangalore Rural'),
(246, 17, 'Bangalore Urban'),
(247, 17, 'Belgaum'),
(248, 17, 'Bellary'),
(249, 17, 'Bidar'),
(250, 17, 'Bijapur'),
(251, 17, 'Chamarajnagar'),
(252, 17, 'Chikkamagaluru'),
(253, 17, 'Chikkaballapur'),
(254, 17, 'Chitradurga'),
(255, 17, 'Davanagere'),
(256, 17, 'Dharwad'),
(257, 17, 'Dakshina Kannada'),
(258, 17, 'Gadag'),
(259, 17, 'Gulbarga'),
(260, 17, 'Hassan'),
(261, 17, 'Haveri district'),
(262, 17, 'Kodagu'),
(263, 17, 'Kolar'),
(264, 17, 'Koppal'),
(265, 17, 'Mandya'),
(266, 17, 'Mysore'),
(267, 17, 'Raichur'),
(268, 17, 'Shimoga'),
(269, 17, 'Tumkur'),
(270, 17, 'Udupi'),
(271, 17, 'Uttara Kannada'),
(272, 17, 'Ramanagara'),
(273, 17, 'Yadgir'),
(274, 18, 'Alappuzha'),
(275, 18, 'Ernakulam'),
(276, 18, 'Idukki'),
(277, 18, 'Kannur'),
(278, 18, 'Kasaragod'),
(279, 18, 'Kollam'),
(280, 18, 'Kottayam'),
(281, 18, 'Kozhikode'),
(282, 18, 'Malappuram'),
(283, 18, 'Palakkad'),
(284, 18, 'Pathanamthitta'),
(285, 18, 'Thrissur'),
(286, 18, 'Thiruvananthapuram'),
(287, 18, 'Wayanad'),
(288, 19, 'Lakshadweep'),
(289, 20, 'Agar'),
(290, 20, 'Alirajpur'),
(291, 20, 'Anuppur'),
(292, 20, 'Ashok Nagar'),
(293, 20, 'Balaghat'),
(294, 20, 'Barwani'),
(295, 20, 'Betul'),
(296, 20, 'Bhind'),
(297, 20, 'Bhopal'),
(298, 20, 'Burhanpur'),
(299, 20, 'Chhatarpur'),
(300, 20, 'Chhindwara'),
(301, 20, 'Damoh'),
(302, 20, 'Datia'),
(303, 20, 'Dewas'),
(304, 20, 'Dhar'),
(305, 20, 'Dindori'),
(306, 20, 'Guna'),
(307, 20, 'Gwalior'),
(308, 20, 'Harda'),
(309, 20, 'Hoshangabad'),
(310, 20, 'Indore'),
(311, 20, 'Jabalpur'),
(312, 20, 'Jhabua'),
(313, 20, 'Katni'),
(314, 20, 'Khandwa (East Nimar)'),
(315, 20, 'Khargone (West Nimar)'),
(316, 20, 'Mandla'),
(317, 20, 'Mandsaur'),
(318, 20, 'Morena'),
(319, 20, 'Narsinghpur'),
(320, 20, 'Neemuch'),
(321, 20, 'Panna'),
(322, 20, 'Raisen'),
(323, 20, 'Rajgarh'),
(324, 20, 'Ratlam'),
(325, 20, 'Rewa'),
(326, 20, 'Sagar'),
(327, 20, 'Satna'),
(328, 20, 'Sehore'),
(329, 20, 'Seoni'),
(330, 20, 'Shahdol'),
(331, 20, 'Shajapur'),
(332, 20, 'Sheopur'),
(333, 20, 'Shivpuri'),
(334, 20, 'Sidhi'),
(335, 20, 'Singrauli'),
(336, 20, 'Tikamgarh'),
(337, 20, 'Ujjain'),
(338, 20, 'Umaria'),
(339, 20, 'Vidisha'),
(340, 21, 'Ahmednagar'),
(341, 21, 'Akola'),
(342, 21, 'Amravati'),
(343, 21, 'Aurangabad'),
(344, 21, 'Beed'),
(345, 21, 'Bhandara'),
(346, 21, 'Buldhana'),
(347, 21, 'Chandrapur'),
(348, 21, 'Dhule'),
(349, 21, 'Gadchiroli'),
(350, 21, 'Gondia'),
(351, 21, 'Hingoli'),
(352, 21, 'Jalgaon'),
(353, 21, 'Jalna'),
(354, 21, 'Kolhapur'),
(355, 21, 'Latur'),
(356, 21, 'Mumbai City'),
(357, 21, 'Mumbai suburban'),
(358, 21, 'Nanded'),
(359, 21, 'Nandurbar'),
(360, 21, 'Nagpur'),
(361, 21, 'Nashik'),
(362, 21, 'Osmanabad'),
(363, 21, 'Parbhani'),
(364, 21, 'Pune'),
(365, 21, 'Raigad'),
(366, 21, 'Ratnagiri'),
(367, 21, 'Sangli'),
(368, 21, 'Satara'),
(369, 21, 'Sindhudurg'),
(370, 21, 'Solapur'),
(371, 21, 'Thane'),
(372, 21, 'Wardha'),
(373, 21, 'Washim'),
(374, 21, 'Yavatmal'),
(375, 22, 'Bishnupur'),
(376, 22, 'Churachandpur'),
(377, 22, 'Chandel'),
(378, 22, 'Imphal East'),
(379, 22, 'Senapati'),
(380, 22, 'Tamenglong'),
(381, 22, 'Thoubal'),
(382, 22, 'Ukhrul'),
(383, 22, 'Imphal West'),
(384, 23, 'East Garo Hills'),
(385, 23, 'East Khasi Hills'),
(386, 23, 'Jaintia Hills'),
(387, 23, 'Ri Bhoi'),
(388, 23, 'South Garo Hills'),
(389, 23, 'West Garo Hills'),
(390, 23, 'West Khasi Hills'),
(391, 24, 'Aizawl'),
(392, 24, 'Champhai'),
(393, 24, 'Kolasib'),
(394, 24, 'Lawngtlai'),
(395, 24, 'Lunglei'),
(396, 24, 'Mamit'),
(397, 24, 'Saiha'),
(398, 24, 'Serchhip'),
(399, 25, 'Dimapur'),
(400, 25, 'Kiphire'),
(401, 25, 'Kohima'),
(402, 25, 'Longleng'),
(403, 25, 'Mokokchung'),
(404, 25, 'Mon'),
(405, 25, 'Peren'),
(406, 25, 'Phek'),
(407, 25, 'Tuensang'),
(408, 25, 'Wokha'),
(409, 25, 'Zunheboto'),
(410, 26, 'Angul'),
(411, 26, 'Boudh (Bauda)'),
(412, 26, 'Bhadrak'),
(413, 26, 'Balangir'),
(414, 26, 'Bargarh (Baragarh)'),
(415, 26, 'Balasore'),
(416, 26, 'Cuttack'),
(417, 26, 'Debagarh (Deogarh)'),
(418, 26, 'Dhenkanal'),
(419, 26, 'Ganjam'),
(420, 26, 'Gajapati'),
(421, 26, 'Jharsuguda'),
(422, 26, 'Jajpur'),
(423, 26, 'Jagatsinghpur'),
(424, 26, 'Khordha'),
(425, 26, 'Kendujhar (Keonjhar)'),
(426, 26, 'Kalahandi'),
(427, 26, 'Kandhamal'),
(428, 26, 'Koraput'),
(429, 26, 'Kendrapara'),
(430, 26, 'Malkangiri'),
(431, 26, 'Mayurbhanj'),
(432, 26, 'Nabarangpur'),
(433, 26, 'Nuapada'),
(434, 26, 'Nayagarh'),
(435, 26, 'Puri'),
(436, 26, 'Rayagada'),
(437, 26, 'Sambalpur'),
(438, 26, 'Subarnapur (Sonepur)'),
(439, 26, 'Sundergarh'),
(440, 27, 'Karaikal'),
(441, 27, 'Mahe'),
(442, 27, 'Pondicherry'),
(443, 27, 'Yanam'),
(444, 28, 'Amritsar'),
(445, 28, 'Barnala'),
(446, 28, 'Bathinda'),
(447, 28, 'Firozpur'),
(448, 28, 'Faridkot'),
(449, 28, 'Fatehgarh Sahib'),
(450, 28, 'Fazilka[6]'),
(451, 28, 'Gurdaspur'),
(452, 28, 'Hoshiarpur'),
(453, 28, 'Jalandhar'),
(454, 28, 'Kapurthala'),
(455, 28, 'Ludhiana'),
(456, 28, 'Mansa'),
(457, 28, 'Moga'),
(458, 28, 'Sri Muktsar Sahib'),
(459, 28, 'Pathankot'),
(460, 28, 'Patiala'),
(461, 28, 'Rupnagar'),
(462, 28, 'Ajitgarh (Mohali)'),
(463, 28, 'Sangrur'),
(464, 28, 'Shahid Bhagat Singh Nagar'),
(465, 28, 'Tarn Taran'),
(466, 29, 'Ajmer'),
(467, 29, 'Alwar'),
(468, 29, 'Bikaner'),
(469, 29, 'Barmer'),
(470, 29, 'Banswara'),
(471, 29, 'Bharatpur'),
(472, 29, 'Baran'),
(473, 29, 'Bundi'),
(474, 29, 'Bhilwara'),
(475, 29, 'Churu'),
(476, 29, 'Chittorgarh'),
(477, 29, 'Dausa'),
(478, 29, 'Dholpur'),
(479, 29, 'Dungapur'),
(480, 29, 'Ganganagar'),
(481, 29, 'Hanumangarh'),
(482, 29, 'Jhunjhunu'),
(483, 29, 'Jalore'),
(484, 29, 'Jodhpur'),
(485, 29, 'Jaipur'),
(486, 29, 'Jaisalmer'),
(487, 29, 'Jhalawar'),
(488, 29, 'Karauli'),
(489, 29, 'Kota'),
(490, 29, 'Nagaur'),
(491, 29, 'Pali'),
(492, 29, 'Pratapgarh'),
(493, 29, 'Rajsamand'),
(494, 29, 'Sikar'),
(495, 29, 'Sawai Madhopur'),
(496, 29, 'Sirohi'),
(497, 29, 'Tonk'),
(498, 29, 'Udaipur'),
(499, 30, 'East Sikkim'),
(500, 30, 'North Sikkim'),
(501, 30, 'South Sikkim'),
(502, 30, 'West Sikkim'),
(503, 31, 'Ariyalur'),
(504, 31, 'Chennai'),
(505, 31, 'Coimbatore'),
(506, 31, 'Cuddalore'),
(507, 31, 'Dharmapuri'),
(508, 31, 'Dindigul'),
(509, 31, 'Erode'),
(510, 31, 'Kanchipuram'),
(511, 31, 'Kanyakumari'),
(512, 31, 'Karur'),
(513, 31, 'Krishnagiri'),
(514, 31, 'Madurai'),
(515, 31, 'Nagapattinam'),
(516, 31, 'Nilgiris'),
(517, 31, 'Namakkal'),
(518, 31, 'Perambalur'),
(519, 31, 'Pudukkottai'),
(520, 31, 'Ramanathapuram'),
(521, 31, 'Salem'),
(522, 31, 'Sivaganga'),
(523, 31, 'Tirupur'),
(524, 31, 'Tiruchirappalli'),
(525, 31, 'Theni'),
(526, 31, 'Tirunelveli'),
(527, 31, 'Thanjavur'),
(528, 31, 'Thoothukudi'),
(529, 31, 'Tiruvallur'),
(530, 31, 'Tiruvarur'),
(531, 31, 'Tiruvannamalai'),
(532, 31, 'Vellore'),
(533, 31, 'Viluppuram'),
(534, 31, 'Virudhunagar'),
(535, 32, 'Dhalai'),
(536, 32, 'North Tripura'),
(537, 32, 'South Tripura'),
(538, 32, 'Khowai[7]'),
(539, 32, 'West Tripura'),
(540, 33, 'Agra'),
(541, 33, 'Aligarh'),
(542, 33, 'Allahabad'),
(543, 33, 'Ambedkar Nagar'),
(544, 33, 'Auraiya'),
(545, 33, 'Azamgarh'),
(546, 33, 'Bagpat'),
(547, 33, 'Bahraich'),
(548, 33, 'Ballia'),
(549, 33, 'Balrampur'),
(550, 33, 'Banda'),
(551, 33, 'Barabanki'),
(552, 33, 'Bareilly'),
(553, 33, 'Basti'),
(554, 33, 'Bijnor'),
(555, 33, 'Budaun'),
(556, 33, 'Bulandshahr'),
(557, 33, 'Chandauli'),
(558, 33, 'Chhatrapati Shahuji Maharaj Nagar[8]'),
(559, 33, 'Chitrakoot'),
(560, 33, 'Deoria'),
(561, 33, 'Etah'),
(562, 33, 'Etawah'),
(563, 33, 'Faizabad'),
(564, 33, 'Farrukhabad'),
(565, 33, 'Fatehpur'),
(566, 33, 'Firozabad'),
(567, 33, 'Gautam Buddh Nagar'),
(568, 33, 'Ghaziabad'),
(569, 33, 'Ghazipur'),
(570, 33, 'Gonda'),
(571, 33, 'Gorakhpur'),
(572, 33, 'Hamirpur'),
(573, 33, 'Hardoi'),
(574, 33, 'Hathras'),
(575, 33, 'Jalaun'),
(576, 33, 'Jaunpur district'),
(577, 33, 'Jhansi'),
(578, 33, 'Jyotiba Phule Nagar'),
(579, 33, 'Kannauj'),
(580, 33, 'Kanpur'),
(581, 33, 'Kanshi Ram Nagar'),
(582, 33, 'Kaushambi'),
(583, 33, 'Kushinagar'),
(584, 33, 'Lakhimpur Kheri'),
(585, 33, 'Lalitpur'),
(586, 33, 'Lucknow'),
(587, 33, 'Maharajganj'),
(588, 33, 'Mahoba'),
(589, 33, 'Mainpuri'),
(590, 33, 'Mathura'),
(591, 33, 'Mau'),
(592, 33, 'Meerut'),
(593, 33, 'Mirzapur'),
(594, 33, 'Moradabad'),
(595, 33, 'Muzaffarnagar'),
(596, 33, 'Panchsheel Nagar district (Hapur)'),
(597, 33, 'Pilibhit'),
(598, 33, 'Pratapgarh'),
(599, 33, 'Raebareli'),
(600, 33, 'Ramabai Nagar (Kanpur Dehat)'),
(601, 33, 'Rampur'),
(602, 33, 'Saharanpur'),
(603, 33, 'Sant Kabir Nagar'),
(604, 33, 'Sant Ravidas Nagar'),
(605, 33, 'Shahjahanpur'),
(606, 33, 'Shamli[9]'),
(607, 33, 'Shravasti'),
(608, 33, 'Siddharthnagar'),
(609, 33, 'Sitapur'),
(610, 33, 'Sonbhadra'),
(611, 33, 'Sultanpur'),
(612, 33, 'Unnao'),
(613, 33, 'Varanasi'),
(614, 34, 'Almora'),
(615, 34, 'Bageshwar'),
(616, 34, 'Chamoli'),
(617, 34, 'Champawat'),
(618, 34, 'Dehradun'),
(619, 34, 'Haridwar'),
(620, 34, 'Nainital'),
(621, 34, 'Pauri Garhwal'),
(622, 34, 'Pithoragarh'),
(623, 34, 'Rudraprayag'),
(624, 34, 'Tehri Garhwal'),
(625, 34, 'Udham Singh Nagar'),
(626, 34, 'Uttarkashi'),
(627, 35, 'Bankura'),
(628, 35, 'Bardhaman'),
(629, 35, 'Birbhum'),
(630, 35, 'Cooch Behar'),
(631, 35, 'Dakshin Dinajpur'),
(632, 35, 'Darjeeling'),
(633, 35, 'Hooghly'),
(634, 35, 'Howrah'),
(635, 35, 'Jalpaiguri'),
(636, 35, 'Kolkata'),
(637, 35, 'Maldah'),
(638, 35, 'Murshidabad'),
(639, 35, 'Nadia'),
(640, 35, 'North 24 Parganas'),
(641, 35, 'Paschim Medinipur'),
(642, 35, 'Purba Medinipur'),
(643, 35, 'Purulia'),
(644, 35, 'South 24 Parganas'),
(645, 35, 'Uttar Dinajpur');

-- --------------------------------------------------------

--
-- Table structure for table `us_duplicator_packages`
--

CREATE TABLE `us_duplicator_packages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `us_email_log`
--

CREATE TABLE `us_email_log` (
  `id` mediumint(9) NOT NULL,
  `to_email` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `attachment_name` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` tinyint(1) DEFAULT NULL,
  `error_message` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_email_log`
--

INSERT INTO `us_email_log` (`id`, `to_email`, `subject`, `message`, `headers`, `attachments`, `sent_date`, `attachment_name`, `ip_address`, `result`, `error_message`) VALUES
(1, 'manishpisharody@gmail.com', 'The subject', 'The email body content', 'Content-Type: text/html; charset=UTF-8', 'false', '2021-04-06 21:13:04', '', '::1', 1, NULL),
(2, 'manishpisharody@gmail.com', 'The subject', 'The email body content', 'Content-Type: text/html; charset=UTF-8', 'false', '2021-04-06 21:14:33', '', '::1', 1, NULL),
(3, 'manish.bharathamitsolutions@gmail.com', '[Upstore] Your Site is Experiencing a Technical Issue', 'Howdy!\n\nSince WordPress 5.2 there is a built-in feature that detects when a plugin or theme causes a fatal error on your site, and notifies you with this automated email.\n\nIn this case, WordPress caught an error with your theme, Upstore.\n\nFirst, visit your website (http://localhost:8080/upstore/) and check for any visible issues. Next, visit the page where the error was caught (http://localhost:8080/upstore/upstore/wp-admin/admin-ajax.php?_fs_blog_admin=true) and check for any visible issues.\n\nPlease contact your host for assistance with investigating this issue further.\n\nIf your site appears broken and you can\'t access your dashboard normally, WordPress now has a special \"recovery mode\". This lets you safely login to your dashboard and investigate further.\n\nhttp://localhost:8080/upstore/wp-login.php?action=enter_recovery_mode&rm_token=xQzDJ4OUfvubzR18LtKKNU&rm_key=0T5Urqx0t1zhYxPsk1vU6d\n\nTo keep your site safe, this link will expire in 1 day. Don\'t worry about that, though: a new link will be emailed to you if the error occurs again after it expires.\n\nWhen seeking help with this issue, you may be asked for some of the following information:\nWordPress version 5.7\r\nCurrent theme: Upstore (version 1.1)\r\nCurrent plugin:  (version )\r\nPHP version 7.2.32\n\n\n\nError Details\n=============\nAn error of type E_PARSE was caused in line 41 of the file C:\\xampp\\htdocs\\upstore\\wp-content\\themes\\upstore\\includes\\email-functions.php. Error message: syntax error, unexpected \'', '', 'false', '2021-04-06 21:21:57', '', '::1', 1, NULL),
(4, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 02:54:57', '', '::1', 0, 'Message body empty'),
(5, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 02:56:22', '', '::1', 0, 'Message body empty'),
(6, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 02:58:45', '', '::1', 0, 'Message body empty'),
(7, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 02:59:31', '', '::1', 0, 'Message body empty'),
(8, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 02:59:43', '', '::1', 0, 'Message body empty'),
(9, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:00:37', '', '::1', 0, 'Message body empty'),
(10, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:01:36', '', '::1', 0, 'Message body empty'),
(11, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:02:07', '', '::1', 0, 'Message body empty'),
(12, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:02:25', '', '::1', 0, 'Message body empty'),
(13, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:03:30', '', '::1', 0, 'Message body empty'),
(14, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:03:42', '', '::1', 0, 'Message body empty'),
(15, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:04:48', '', '::1', 0, 'Message body empty'),
(16, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:05:14', '', '::1', 0, 'Message body empty'),
(17, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:05:54', '', '::1', 0, 'Message body empty'),
(18, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:08:52', '', '::1', 0, 'Message body empty'),
(19, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:09:10', '', '::1', 0, 'Message body empty'),
(20, '', 'Email has been updated', '', 'Content-Type: text/html; charset=UTF-8\nCC: Admin1 <admin1@bharathamitsolutions.com>;\nCC: Admin2 <admin2@bharathamitsolutions.com>;', 'false', '2021-04-07 03:09:22', '', '::1', 0, 'Message body empty'),
(21, 'manish.bharathamitsolutions@gmail.com', '[Upstore] Your site has updated to WordPress 5.7.1', 'Howdy! Your site at http://localhost:8080/upstore has been updated automatically to WordPress 5.7.1.\n\nNo further action is needed on your part. For more on version 5.7.1, see the About WordPress screen:\nhttp://localhost:8080/upstore/wp-admin/about.php\n\nIf you experience any issues or need support, the volunteers in the WordPress.org support forums may be able to help.\nhttps://wordpress.org/support/forums/\n\nYou also have some plugins or themes with updates available. Update them now:\nhttp://localhost:8080/upstore/wp-admin/\n\nThe WordPress Team\n', '', 'false', '2021-04-15 04:44:02', '', '::1', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `us_items`
--

CREATE TABLE `us_items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `item_price` varchar(15) NOT NULL,
  `item_hsncode` varchar(50) NOT NULL,
  `status` varchar(25) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_items`
--

INSERT INTO `us_items` (`item_id`, `item_name`, `item_price`, `item_hsncode`, `status`, `created_on`, `created_by`) VALUES
(452, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:36:53', '1'),
(453, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:37:09', '1'),
(454, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:37:43', '1'),
(455, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:39:23', '1'),
(456, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:40:08', '1'),
(457, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:40:21', '1'),
(458, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:42:07', '1'),
(459, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:44:18', '1'),
(460, 'test_item', 'test_item', 'test_item', '', '2021-04-06 21:45:12', '1'),
(461, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:13:04', '1'),
(462, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:14:33', '1'),
(464, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:24:57', '1'),
(465, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:26:22', '1'),
(466, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:28:45', '1'),
(467, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:29:31', '1'),
(468, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:29:43', '1'),
(469, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:30:37', '1'),
(470, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:31:36', '1'),
(471, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:32:07', '1'),
(472, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:32:25', '1'),
(473, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:33:30', '1'),
(474, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:33:42', '1'),
(475, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:34:48', '1'),
(476, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:35:14', '1'),
(477, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:35:54', '1'),
(478, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:38:52', '1'),
(479, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:39:10', '1'),
(480, 'test_item', 'test_item', 'test_item', '', '2021-04-07 08:39:22', '1');

-- --------------------------------------------------------

--
-- Table structure for table `us_links`
--

CREATE TABLE `us_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `us_options`
--

CREATE TABLE `us_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_options`
--

INSERT INTO `us_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/upstore', 'yes'),
(2, 'home', 'http://localhost/upstore', 'yes'),
(3, 'blogname', 'Upstore', 'yes'),
(4, 'blogdescription', 'Just another WordPress site', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'manish.bharathamitsolutions@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:188:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:7:\"item/?$\";s:24:\"index.php?post_type=item\";s:37:\"item/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=item&feed=$matches[1]\";s:32:\"item/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=item&feed=$matches[1]\";s:24:\"item/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=item&paged=$matches[1]\";s:10:\"service/?$\";s:27:\"index.php?post_type=service\";s:40:\"service/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=service&feed=$matches[1]\";s:35:\"service/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=service&feed=$matches[1]\";s:27:\"service/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=service&paged=$matches[1]\";s:7:\"shop/?$\";s:24:\"index.php?post_type=shop\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=shop&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:41:\"index.php?post_type=shop&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:42:\"index.php?post_type=shop&paged=$matches[1]\";s:49:\"item/tax/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:63:\"index.php?item=$matches[1]&feed=$matches[2]&cpt_onomy_archive=1\";s:44:\"item/tax/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:63:\"index.php?item=$matches[1]&feed=$matches[2]&cpt_onomy_archive=1\";s:37:\"item/tax/([^/]+)/page/?([0-9]{1,})/?$\";s:64:\"index.php?item=$matches[1]&paged=$matches[2]&cpt_onomy_archive=1\";s:19:\"item/tax/([^/]+)/?$\";s:46:\"index.php?item=$matches[1]&cpt_onomy_archive=1\";s:52:\"service/tax/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?service=$matches[1]&feed=$matches[2]&cpt_onomy_archive=1\";s:47:\"service/tax/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:66:\"index.php?service=$matches[1]&feed=$matches[2]&cpt_onomy_archive=1\";s:40:\"service/tax/([^/]+)/page/?([0-9]{1,})/?$\";s:67:\"index.php?service=$matches[1]&paged=$matches[2]&cpt_onomy_archive=1\";s:22:\"service/tax/([^/]+)/?$\";s:49:\"index.php?service=$matches[1]&cpt_onomy_archive=1\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:52:\"custom_status/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?custom_status=$matches[1]&feed=$matches[2]\";s:47:\"custom_status/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?custom_status=$matches[1]&feed=$matches[2]\";s:28:\"custom_status/(.+?)/embed/?$\";s:46:\"index.php?custom_status=$matches[1]&embed=true\";s:40:\"custom_status/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?custom_status=$matches[1]&paged=$matches[2]\";s:22:\"custom_status/(.+?)/?$\";s:35:\"index.php?custom_status=$matches[1]\";s:57:\"service-categories/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?service_categories=$matches[1]&feed=$matches[2]\";s:52:\"service-categories/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:57:\"index.php?service_categories=$matches[1]&feed=$matches[2]\";s:33:\"service-categories/(.+?)/embed/?$\";s:51:\"index.php?service_categories=$matches[1]&embed=true\";s:45:\"service-categories/(.+?)/page/?([0-9]{1,})/?$\";s:58:\"index.php?service_categories=$matches[1]&paged=$matches[2]\";s:27:\"service-categories/(.+?)/?$\";s:40:\"index.php?service_categories=$matches[1]\";s:48:\"districts/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?districts=$matches[1]&feed=$matches[2]\";s:43:\"districts/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:48:\"index.php?districts=$matches[1]&feed=$matches[2]\";s:24:\"districts/(.+?)/embed/?$\";s:42:\"index.php?districts=$matches[1]&embed=true\";s:36:\"districts/(.+?)/page/?([0-9]{1,})/?$\";s:49:\"index.php?districts=$matches[1]&paged=$matches[2]\";s:18:\"districts/(.+?)/?$\";s:31:\"index.php?districts=$matches[1]\";s:54:\"shop-categories/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?shop_categories=$matches[1]&feed=$matches[2]\";s:49:\"shop-categories/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:54:\"index.php?shop_categories=$matches[1]&feed=$matches[2]\";s:30:\"shop-categories/(.+?)/embed/?$\";s:48:\"index.php?shop_categories=$matches[1]&embed=true\";s:42:\"shop-categories/(.+?)/page/?([0-9]{1,})/?$\";s:55:\"index.php?shop_categories=$matches[1]&paged=$matches[2]\";s:24:\"shop-categories/(.+?)/?$\";s:37:\"index.php?shop_categories=$matches[1]\";s:32:\"item/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"item/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"item/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"item/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"item/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"item/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"item/([^/]+)/embed/?$\";s:37:\"index.php?item=$matches[1]&embed=true\";s:25:\"item/([^/]+)/trackback/?$\";s:31:\"index.php?item=$matches[1]&tb=1\";s:45:\"item/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?item=$matches[1]&feed=$matches[2]\";s:40:\"item/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?item=$matches[1]&feed=$matches[2]\";s:33:\"item/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?item=$matches[1]&paged=$matches[2]\";s:40:\"item/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?item=$matches[1]&cpage=$matches[2]\";s:29:\"item/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?item=$matches[1]&page=$matches[2]\";s:21:\"item/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"item/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"item/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"item/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"item/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"item/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:35:\"service/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"service/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"service/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"service/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"service/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"service/([^/]+)/embed/?$\";s:40:\"index.php?service=$matches[1]&embed=true\";s:28:\"service/([^/]+)/trackback/?$\";s:34:\"index.php?service=$matches[1]&tb=1\";s:48:\"service/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?service=$matches[1]&feed=$matches[2]\";s:43:\"service/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?service=$matches[1]&feed=$matches[2]\";s:36:\"service/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?service=$matches[1]&paged=$matches[2]\";s:43:\"service/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?service=$matches[1]&cpage=$matches[2]\";s:32:\"service/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?service=$matches[1]&page=$matches[2]\";s:24:\"service/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"service/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"service/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"service/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"service/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:32:\"shop/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"shop/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"shop/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"shop/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"shop/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"shop/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:21:\"shop/([^/]+)/embed/?$\";s:37:\"index.php?shop=$matches[1]&embed=true\";s:25:\"shop/([^/]+)/trackback/?$\";s:31:\"index.php?shop=$matches[1]&tb=1\";s:45:\"shop/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?shop=$matches[1]&feed=$matches[2]\";s:40:\"shop/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?shop=$matches[1]&feed=$matches[2]\";s:33:\"shop/([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?shop=$matches[1]&paged=$matches[2]\";s:40:\"shop/([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?shop=$matches[1]&cpage=$matches[2]\";s:29:\"shop/([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?shop=$matches[1]&page=$matches[2]\";s:21:\"shop/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:31:\"shop/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:51:\"shop/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"shop/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:46:\"shop/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:27:\"shop/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:27:\"cpt-onomies/cpt-onomies.php\";i:2;s:39:\"custom-post-types/custom-post-types.php\";i:3;s:25:\"duplicator/duplicator.php\";i:4;s:23:\"email-log/email-log.php\";i:5;s:47:\"show-current-template/show-current-template.php\";i:6;s:37:\"user-role-editor/user-role-editor.php\";i:7;s:59:\"user-roles-and-capabilities/user-roles-and-capabilities.php\";i:8;s:33:\"wp-bulk-delete/wp-bulk-delete.php\";i:9;s:29:\"wp-mail-smtp/wp_mail_smtp.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:59:\"C:\\xampp\\htdocs\\upstore/wp-content/themes/upstore/style.css\";i:1;s:0:\"\";}', 'no'),
(40, 'template', 'upstore', 'yes'),
(41, 'stylesheet', 'upstore', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:37:\"user-role-editor/user-role-editor.php\";a:2:{i:0;s:16:\"User_Role_Editor\";i:1;s:9:\"uninstall\";}}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '364', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1630901109', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'us_user_roles', 'a:8:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:84:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:14:\"ure_edit_roles\";b:1;s:16:\"ure_create_roles\";b:1;s:16:\"ure_delete_roles\";b:1;s:23:\"ure_create_capabilities\";b:1;s:23:\"ure_delete_capabilities\";b:1;s:18:\"ure_manage_options\";b:1;s:15:\"ure_reset_roles\";b:1;s:28:\"wprc_manage_all_capabilities\";b:1;s:29:\"wprc_manage_user_capabilities\";b:1;s:17:\"wprc_add_new_role\";b:1;s:16:\"wprc_delete_role\";b:1;s:24:\"wprc_change_default_role\";b:1;s:23:\"wprc_add_new_capability\";b:1;s:22:\"wprc_remove_capability\";b:1;s:16:\"wprc_rename_role\";b:1;s:21:\"wprc_export_role_caps\";b:1;s:21:\"wprc_import_role_caps\";b:1;s:12:\"create_posts\";b:1;s:17:\"install_languages\";b:1;s:14:\"resume_plugins\";b:1;s:13:\"resume_themes\";b:1;s:23:\"view_site_health_checks\";b:1;s:17:\"manage_email_logs\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:4:\"shop\";a:2:{s:4:\"name\";s:4:\"Shop\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:7:\"upadmin\";a:2:{s:4:\"name\";s:13:\"Upstore Admin\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes'),
(101, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'sidebars_widgets', 'a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(107, 'cron', 'a:10:{i:1619845167;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"0d04ed39571b55704c122d726248bbac\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:1:{i:0;s:7:\"WP Cron\";}s:8:\"interval\";i:60;}}}i:1619847547;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1619847784;a:1:{s:46:\"el_trigger_notify_email_when_log_threshold_met\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1619885111;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1619885307;a:1:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1619928310;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1619928317;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1619928324;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1620273910;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:0:{}', 'yes'),
(120, 'theme_mods_twentytwentyone', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1615782944;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}}', 'yes'),
(133, 'can_compress_scripts', '1', 'no'),
(147, 'finished_updating_comment_type', '1', 'yes'),
(149, 'auto_core_update_notified', 'a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:37:\"manish.bharathamitsolutions@gmail.com\";s:7:\"version\";s:5:\"5.7.1\";s:9:\"timestamp\";i:1618481642;}', 'no'),
(151, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(152, 'current_theme', 'Upstore', 'yes'),
(153, 'theme_mods_upstore', 'a:5:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1615782942;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}s:11:\"custom_logo\";i:430;}', 'yes'),
(154, 'theme_switched', '', 'yes'),
(155, 'recently_activated', 'a:1:{s:27:\"wp-mail-log/wp-mail-log.php\";i:1617763256;}', 'yes'),
(156, 'fs_active_plugins', 'O:8:\"stdClass\":3:{s:7:\"plugins\";a:1:{s:20:\"cpt-onomies/freemius\";O:8:\"stdClass\":4:{s:7:\"version\";s:5:\"2.2.4\";s:4:\"type\";s:6:\"plugin\";s:9:\"timestamp\";i:1615351581;s:11:\"plugin_path\";s:27:\"cpt-onomies/cpt-onomies.php\";}}s:7:\"abspath\";s:24:\"C:\\xampp\\htdocs\\upstore/\";s:6:\"newest\";O:8:\"stdClass\":5:{s:11:\"plugin_path\";s:27:\"cpt-onomies/cpt-onomies.php\";s:8:\"sdk_path\";s:20:\"cpt-onomies/freemius\";s:7:\"version\";s:5:\"2.2.4\";s:13:\"in_activation\";b:0;s:9:\"timestamp\";i:1615351581;}}', 'yes'),
(157, 'fs_debug_mode', '', 'yes'),
(158, 'fs_accounts', 'a:5:{s:21:\"id_slug_type_path_map\";a:1:{i:2507;a:3:{s:4:\"slug\";s:11:\"cpt-onomies\";s:4:\"type\";s:6:\"plugin\";s:4:\"path\";s:27:\"cpt-onomies/cpt-onomies.php\";}}s:11:\"plugin_data\";a:1:{s:11:\"cpt-onomies\";a:15:{s:16:\"plugin_main_file\";O:8:\"stdClass\":1:{s:4:\"path\";s:27:\"cpt-onomies/cpt-onomies.php\";}s:17:\"install_timestamp\";i:1615351581;s:16:\"sdk_last_version\";N;s:11:\"sdk_version\";s:5:\"2.2.4\";s:16:\"sdk_upgrade_mode\";b:1;s:18:\"sdk_downgrade_mode\";b:0;s:19:\"plugin_last_version\";N;s:14:\"plugin_version\";s:5:\"1.4.0\";s:19:\"plugin_upgrade_mode\";b:1;s:21:\"plugin_downgrade_mode\";b:0;s:21:\"is_plugin_new_install\";b:1;s:17:\"connectivity_test\";a:6:{s:12:\"is_connected\";b:1;s:4:\"host\";s:14:\"localhost:8080\";s:9:\"server_ip\";s:3:\"::1\";s:9:\"is_active\";b:1;s:9:\"timestamp\";i:1615351581;s:7:\"version\";s:5:\"1.4.0\";}s:17:\"was_plugin_loaded\";b:1;s:15:\"prev_is_premium\";b:0;s:12:\"is_anonymous\";a:3:{s:2:\"is\";b:1;s:9:\"timestamp\";i:1615351586;s:7:\"version\";s:5:\"1.4.0\";}}}s:13:\"file_slug_map\";a:1:{s:27:\"cpt-onomies/cpt-onomies.php\";s:11:\"cpt-onomies\";}s:7:\"plugins\";a:1:{s:11:\"cpt-onomies\";O:9:\"FS_Plugin\":20:{s:16:\"parent_plugin_id\";N;s:5:\"title\";s:52:\"CPT-onomies: Easiest way to create Custom Post Types\";s:4:\"slug\";s:11:\"cpt-onomies\";s:12:\"premium_slug\";s:19:\"cpt-onomies-premium\";s:4:\"type\";s:6:\"plugin\";s:20:\"affiliate_moderation\";b:0;s:19:\"is_wp_org_compliant\";b:1;s:4:\"file\";s:27:\"cpt-onomies/cpt-onomies.php\";s:7:\"version\";s:5:\"1.4.0\";s:11:\"auto_update\";N;s:4:\"info\";N;s:10:\"is_premium\";b:0;s:14:\"premium_suffix\";s:9:\"(Premium)\";s:7:\"is_live\";b:1;s:10:\"public_key\";s:32:\"pk_e209d36dd975fc9defad36a529373\";s:10:\"secret_key\";N;s:2:\"id\";s:4:\"2507\";s:7:\"updated\";N;s:7:\"created\";N;s:22:\"\0FS_Entity\0_is_updated\";b:0;}}s:9:\"unique_id\";s:32:\"aa60fa738c925ec70437a94eb26022cd\";}', 'yes'),
(159, 'fs_api_cache', 'a:0:{}', 'yes'),
(160, 'fs_gdpr', 'a:1:{s:2:\"u1\";a:1:{s:8:\"required\";b:0;}}', 'yes'),
(163, 'widget_cpt_onomy_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(164, 'duplicator_settings', 'a:17:{s:7:\"version\";s:8:\"1.3.40.1\";s:18:\"uninstall_settings\";b:1;s:15:\"uninstall_files\";b:1;s:16:\"uninstall_tables\";b:1;s:13:\"package_debug\";b:0;s:17:\"package_mysqldump\";b:1;s:22:\"package_mysqldump_path\";s:0:\"\";s:24:\"package_phpdump_qrylimit\";s:3:\"100\";s:17:\"package_zip_flush\";b:0;s:19:\"installer_name_mode\";s:6:\"simple\";s:16:\"storage_position\";s:6:\"wpcont\";s:20:\"storage_htaccess_off\";b:0;s:18:\"archive_build_mode\";i:2;s:17:\"skip_archive_scan\";b:0;s:21:\"unhook_third_party_js\";b:0;s:22:\"unhook_third_party_css\";b:0;s:17:\"active_package_id\";i:-1;}', 'yes'),
(165, 'duplicator_lite_inst_hash_notice', '1', 'yes'),
(166, 'duplicator_version_plugin', '1.3.40.1', 'yes'),
(167, 'user_role_editor', 'a:1:{s:11:\"ure_version\";s:6:\"4.58.2\";}', 'yes'),
(168, 'us_backup_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'no'),
(169, 'ure_tasks_queue', 'a:0:{}', 'yes'),
(170, 'solvease_wp_rc_caps', 's:6:\"a:0:{}\";', 'yes'),
(171, 'solvease_wprc_plugin_version', '121', 'no'),
(175, 'theme_mods_twentynineteen', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:6:\"menu-1\";i:2;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1615782985;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(177, 'theme_mods_twentytwenty', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1615351677;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}}}}', 'yes'),
(179, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(191, '_transient_health-check-site-status-result', '{\"good\":13,\"recommended\":7,\"critical\":0}', 'yes'),
(222, 'custom_post_type_onomies_custom_post_types', 'a:3:{s:4:\"item\";a:38:{s:5:\"label\";s:5:\"Items\";s:4:\"name\";s:4:\"item\";s:11:\"description\";s:0:\"\";s:19:\"attach_to_post_type\";a:10:{i:0;s:10:\"attachment\";i:1;s:10:\"custom_css\";i:2;s:19:\"customize_changeset\";i:3;s:10:\"manage_cpt\";i:4;s:16:\"manage_cpt_field\";i:5;s:14:\"manage_cpt_tax\";i:6;s:19:\"manage_cpt_template\";i:7;s:12:\"oembed_cache\";i:8;s:4:\"page\";i:9;s:4:\"shop\";}s:14:\"meta_box_title\";s:0:\"\";s:17:\"show_admin_column\";s:1:\"1\";s:18:\"admin_column_title\";s:0:\"\";s:21:\"has_cpt_onomy_archive\";s:1:\"1\";s:22:\"cpt_onomy_archive_slug\";s:0:\"\";s:26:\"restrict_user_capabilities\";a:3:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";i:2;s:6:\"author\";}s:13:\"singular_name\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:9:\"menu_name\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";s:6:\"public\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"0\";s:8:\"supports\";a:11:{i:0;s:5:\"title\";i:1;s:6:\"editor\";i:2;s:6:\"author\";i:3;s:9:\"thumbnail\";i:4;s:7:\"excerpt\";i:5;s:10:\"trackbacks\";i:6;s:13:\"custom-fields\";i:7;s:8:\"comments\";i:8;s:9:\"revisions\";i:9;s:15:\"page-attributes\";i:10;s:12:\"post-formats\";}s:11:\"has_archive\";s:0:\"\";s:12:\"show_in_menu\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:9:\"menu_icon\";s:0:\"\";s:9:\"query_var\";s:0:\"\";s:20:\"register_meta_box_cb\";s:0:\"\";s:7:\"rewrite\";a:4:{s:14:\"enable_rewrite\";s:1:\"1\";s:4:\"slug\";s:0:\"\";s:10:\"with_front\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";}s:12:\"map_meta_cap\";s:1:\"1\";s:15:\"capability_type\";s:0:\"\";s:12:\"capabilities\";a:14:{s:4:\"read\";s:0:\"\";s:9:\"read_post\";s:0:\"\";s:18:\"read_private_posts\";s:0:\"\";s:9:\"edit_post\";s:0:\"\";s:10:\"edit_posts\";s:0:\"\";s:17:\"edit_others_posts\";s:0:\"\";s:18:\"edit_private_posts\";s:0:\"\";s:20:\"edit_published_posts\";s:0:\"\";s:11:\"delete_post\";s:0:\"\";s:12:\"delete_posts\";s:0:\"\";s:20:\"delete_private_posts\";s:0:\"\";s:19:\"delete_others_posts\";s:0:\"\";s:22:\"delete_published_posts\";s:0:\"\";s:13:\"publish_posts\";s:0:\"\";}s:10:\"can_export\";s:1:\"1\";s:16:\"permalink_epmask\";s:0:\"\";}s:7:\"service\";a:38:{s:5:\"label\";s:8:\"Services\";s:4:\"name\";s:7:\"service\";s:11:\"description\";s:0:\"\";s:19:\"attach_to_post_type\";a:12:{i:0;s:10:\"attachment\";i:1;s:10:\"custom_css\";i:2;s:19:\"customize_changeset\";i:3;s:10:\"manage_cpt\";i:4;s:16:\"manage_cpt_field\";i:5;s:14:\"manage_cpt_tax\";i:6;s:19:\"manage_cpt_template\";i:7;s:12:\"oembed_cache\";i:8;s:4:\"page\";i:9;s:4:\"post\";i:10;s:12:\"user_request\";i:11;s:8:\"wp_block\";}s:14:\"meta_box_title\";s:0:\"\";s:17:\"show_admin_column\";s:1:\"1\";s:18:\"admin_column_title\";s:0:\"\";s:21:\"has_cpt_onomy_archive\";s:1:\"1\";s:22:\"cpt_onomy_archive_slug\";s:0:\"\";s:26:\"restrict_user_capabilities\";a:7:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";i:2;s:6:\"author\";i:3;s:11:\"contributor\";i:4;s:10:\"subscriber\";i:5;s:8:\"customer\";i:6;s:7:\"upadmin\";}s:13:\"singular_name\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:9:\"menu_name\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";s:6:\"public\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"0\";s:8:\"supports\";a:11:{i:0;s:5:\"title\";i:1;s:6:\"editor\";i:2;s:6:\"author\";i:3;s:9:\"thumbnail\";i:4;s:7:\"excerpt\";i:5;s:10:\"trackbacks\";i:6;s:13:\"custom-fields\";i:7;s:8:\"comments\";i:8;s:9:\"revisions\";i:9;s:15:\"page-attributes\";i:10;s:12:\"post-formats\";}s:11:\"has_archive\";s:0:\"\";s:12:\"show_in_menu\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:9:\"menu_icon\";s:0:\"\";s:9:\"query_var\";s:0:\"\";s:20:\"register_meta_box_cb\";s:0:\"\";s:7:\"rewrite\";a:4:{s:14:\"enable_rewrite\";s:1:\"1\";s:4:\"slug\";s:0:\"\";s:10:\"with_front\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";}s:12:\"map_meta_cap\";s:1:\"1\";s:15:\"capability_type\";s:0:\"\";s:12:\"capabilities\";a:14:{s:4:\"read\";s:0:\"\";s:9:\"read_post\";s:0:\"\";s:18:\"read_private_posts\";s:0:\"\";s:9:\"edit_post\";s:0:\"\";s:10:\"edit_posts\";s:0:\"\";s:17:\"edit_others_posts\";s:0:\"\";s:18:\"edit_private_posts\";s:0:\"\";s:20:\"edit_published_posts\";s:0:\"\";s:11:\"delete_post\";s:0:\"\";s:12:\"delete_posts\";s:0:\"\";s:20:\"delete_private_posts\";s:0:\"\";s:19:\"delete_others_posts\";s:0:\"\";s:22:\"delete_published_posts\";s:0:\"\";s:13:\"publish_posts\";s:0:\"\";}s:10:\"can_export\";s:1:\"1\";s:16:\"permalink_epmask\";s:0:\"\";}s:4:\"shop\";a:37:{s:5:\"label\";s:5:\"Shops\";s:4:\"name\";s:4:\"shop\";s:11:\"description\";s:0:\"\";s:14:\"meta_box_title\";s:0:\"\";s:17:\"show_admin_column\";s:1:\"1\";s:18:\"admin_column_title\";s:0:\"\";s:21:\"has_cpt_onomy_archive\";s:1:\"1\";s:22:\"cpt_onomy_archive_slug\";s:0:\"\";s:26:\"restrict_user_capabilities\";a:3:{i:0;s:13:\"administrator\";i:1;s:6:\"editor\";i:2;s:6:\"author\";}s:13:\"singular_name\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:9:\"menu_name\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";s:6:\"public\";s:1:\"1\";s:12:\"hierarchical\";s:1:\"0\";s:8:\"supports\";a:2:{i:0;s:5:\"title\";i:1;s:6:\"editor\";}s:11:\"has_archive\";s:0:\"\";s:12:\"show_in_menu\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:9:\"menu_icon\";s:0:\"\";s:9:\"query_var\";s:0:\"\";s:20:\"register_meta_box_cb\";s:0:\"\";s:7:\"rewrite\";a:4:{s:14:\"enable_rewrite\";s:1:\"1\";s:4:\"slug\";s:0:\"\";s:10:\"with_front\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";}s:12:\"map_meta_cap\";s:1:\"1\";s:15:\"capability_type\";s:0:\"\";s:12:\"capabilities\";a:14:{s:4:\"read\";s:0:\"\";s:9:\"read_post\";s:0:\"\";s:18:\"read_private_posts\";s:0:\"\";s:9:\"edit_post\";s:0:\"\";s:10:\"edit_posts\";s:0:\"\";s:17:\"edit_others_posts\";s:0:\"\";s:18:\"edit_private_posts\";s:0:\"\";s:20:\"edit_published_posts\";s:0:\"\";s:11:\"delete_post\";s:0:\"\";s:12:\"delete_posts\";s:0:\"\";s:20:\"delete_private_posts\";s:0:\"\";s:19:\"delete_others_posts\";s:0:\"\";s:22:\"delete_published_posts\";s:0:\"\";s:13:\"publish_posts\";s:0:\"\";}s:10:\"can_export\";s:1:\"1\";s:16:\"permalink_epmask\";s:0:\"\";}}', 'yes'),
(227, 'custom_post_types_registered_cpt_ids', 'a:4:{i:0;i:13;i:1;i:18;i:2;i:64;i:3;i:86;}', 'yes'),
(291, 'category_children', 'a:0:{}', 'yes'),
(300, 'item_categories_children', 'a:1:{i:17;a:4:{i:0;i:18;i:1;i:19;i:2;i:20;i:3;i:21;}}', 'yes'),
(434, 'service-category_children', 'a:1:{i:26;a:2:{i:0;i:27;i:1;i:28;}}', 'yes'),
(439, 'service_categories_children', 'a:1:{i:29;a:2:{i:0;i:30;i:1;i:31;}}', 'yes'),
(449, 'acf_version', '5.9.5', 'yes'),
(482, 'custom_status_children', 'a:0:{}', 'yes'),
(496, 'districts_children', 'a:1:{i:11;a:7:{i:0;i:12;i:1;i:13;i:2;i:14;i:3;i:15;i:4;i:16;i:5;i:34;i:6;i:36;}}', 'yes'),
(563, 'shop_categories_children', 'a:1:{i:23;a:3:{i:0;i:24;i:1;i:25;i:2;i:37;}}', 'yes'),
(782, 'wml_db_version', '0.3', 'yes'),
(790, 'wp_mail_smtp_initial_version', '2.7.0', 'no'),
(791, 'wp_mail_smtp_version', '2.7.0', 'no');
INSERT INTO `us_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(792, 'wp_mail_smtp', 'a:7:{s:4:\"mail\";a:6:{s:10:\"from_email\";s:37:\"manish.bharathamitsolutions@gmail.com\";s:9:\"from_name\";s:7:\"Upstore\";s:6:\"mailer\";s:4:\"smtp\";s:11:\"return_path\";b:0;s:16:\"from_email_force\";b:1;s:15:\"from_name_force\";b:0;}s:4:\"smtp\";a:7:{s:7:\"autotls\";b:1;s:4:\"auth\";b:1;s:4:\"host\";s:14:\"smtp.gmail.com\";s:10:\"encryption\";s:3:\"tls\";s:4:\"port\";i:587;s:4:\"user\";s:37:\"manish.bharathamitsolutions@gmail.com\";s:4:\"pass\";s:68:\"hmGb6DEL2c7StrkWHiBQfpInaoU30KX5oU9xX5uuztf3HNJAGS24yXjFGKjEMQr1QWk=\";}s:7:\"smtpcom\";a:2:{s:7:\"api_key\";s:0:\"\";s:7:\"channel\";s:0:\"\";}s:10:\"sendinblue\";a:2:{s:7:\"api_key\";s:0:\"\";s:6:\"domain\";s:0:\"\";}s:7:\"mailgun\";a:3:{s:7:\"api_key\";s:0:\"\";s:6:\"domain\";s:0:\"\";s:6:\"region\";s:2:\"US\";}s:8:\"sendgrid\";a:2:{s:7:\"api_key\";s:0:\"\";s:6:\"domain\";s:0:\"\";}s:5:\"gmail\";a:2:{s:9:\"client_id\";s:0:\"\";s:13:\"client_secret\";s:0:\"\";}}', 'no'),
(793, 'wp_mail_smtp_activated_time', '1617724526', 'no'),
(794, 'wp_mail_smtp_activated', 'a:1:{s:4:\"lite\";i:1617724526;}', 'yes'),
(797, 'action_scheduler_hybrid_store_demarkation', '451', 'yes'),
(798, 'schema-ActionScheduler_StoreSchema', '3.0.1617724527', 'yes'),
(799, 'schema-ActionScheduler_LoggerSchema', '2.0.1617724527', 'yes'),
(800, 'wp_mail_smtp_migration_version', '3', 'yes'),
(804, 'wp_mail_smtp_activation_prevent_redirect', '1', 'yes'),
(805, 'action_scheduler_lock_async-request-runner', '1619844290', 'yes'),
(808, 'wp_mail_smtp_review_notice', 'a:2:{s:4:\"time\";i:1617724612;s:9:\"dismissed\";b:0;}', 'yes'),
(810, 'wp_mail_smtp_debug', 'a:0:{}', 'no'),
(811, 'wp_mail_smtp_notifications', 'a:4:{s:6:\"update\";i:1619845145;s:4:\"feed\";a:0:{}s:6:\"events\";a:0:{}s:9:\"dismissed\";a:0:{}}', 'yes'),
(817, 'wp_mail_smtp_mail_key', 'Ne3hh4fALsl6G+ns2s6eG1e29oeE3MVTbhXhoob4Jkg=', 'yes'),
(849, 'email-log-db', '0.3', 'yes'),
(851, 'action_scheduler_migration_status', 'complete', 'yes'),
(946, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.7.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.7.1-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.1\";s:7:\"version\";s:5:\"5.7.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1619844216;s:15:\"version_checked\";s:5:\"5.7.1\";s:12:\"translations\";a:0:{}}', 'no'),
(968, 'nonce_key', 'L5Q1##$=De4T0Ja,-*>cXxR4/|i(eF<7B`:k_0?Eb:W>d]f}KU$ YP~p(fKV.%7O', 'no'),
(969, 'nonce_salt', '~L7IM^~p5Dh}G~(VpJbIF-<I!~)M@U$X/xM2= R8l1ZTw$BzmiF8]F]._B#QyAp=', 'no'),
(972, '_site_transient_timeout_theme_roots', '1619846018', 'no'),
(973, '_site_transient_theme_roots', 'a:4:{s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";s:7:\"upstore\";s:7:\"/themes\";}', 'no'),
(974, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1619844221;s:7:\"checked\";a:4:{s:14:\"twentynineteen\";s:3:\"1.9\";s:12:\"twentytwenty\";s:3:\"1.6\";s:15:\"twentytwentyone\";s:3:\"1.1\";s:7:\"upstore\";s:3:\"1.1\";}s:8:\"response\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.0.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.7.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.3.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:9:\"no_update\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(975, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1619844225;s:7:\"checked\";a:24:{s:63:\"add-tags-and-category-to-page/add-tags-and-category-to-page.php\";s:3:\"2.2\";s:30:\"advanced-custom-fields/acf.php\";s:5:\"5.9.5\";s:27:\"advanced-settings/index.php\";s:5:\"2.3.4\";s:19:\"akismet/akismet.php\";s:5:\"4.1.8\";s:27:\"cpt-onomies/cpt-onomies.php\";s:5:\"1.4.0\";s:39:\"custom-post-types/custom-post-types.php\";s:6:\"2.1.19\";s:25:\"debugpress/debugpress.php\";s:3:\"1.6\";s:74:\"duplicate-post-page-menu-custom-post-type/duplicate-post-page-menu-cpt.php\";s:5:\"1.6.0\";s:25:\"duplicator/duplicator.php\";s:8:\"1.3.40.1\";s:23:\"email-log/email-log.php\";s:5:\"2.4.4\";s:38:\"sql-chart-builder/guaven_sqlcharts.php\";s:5:\"2.2.0\";s:9:\"hello.php\";s:5:\"1.7.2\";s:26:\"post-smtp/postman-smtp.php\";s:6:\"2.0.22\";s:41:\"post-type-switcher/post-type-switcher.php\";s:5:\"3.2.0\";s:25:\"profile-builder/index.php\";s:5:\"3.3.7\";s:47:\"show-current-template/show-current-template.php\";s:5:\"0.4.3\";s:27:\"sample-data/sample-data.php\";s:5:\"1.1.2\";s:25:\"user-menus/user-menus.php\";s:5:\"1.2.5\";s:37:\"user-role-editor/user-role-editor.php\";s:6:\"4.58.2\";s:59:\"user-roles-and-capabilities/user-roles-and-capabilities.php\";s:5:\"1.2.4\";s:33:\"user-switching/user-switching.php\";s:5:\"1.5.6\";s:27:\"woocommerce/woocommerce.php\";s:5:\"5.1.0\";s:33:\"wp-bulk-delete/wp-bulk-delete.php\";s:5:\"1.2.1\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:5:\"2.7.0\";}s:8:\"response\";a:10:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"debugpress/debugpress.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:24:\"w.org/plugins/debugpress\";s:4:\"slug\";s:10:\"debugpress\";s:6:\"plugin\";s:25:\"debugpress/debugpress.php\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/debugpress/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/debugpress.1.7.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:63:\"https://ps.w.org/debugpress/assets/icon-256x256.png?rev=2383803\";s:2:\"1x\";s:55:\"https://ps.w.org/debugpress/assets/icon.svg?rev=2419902\";s:3:\"svg\";s:55:\"https://ps.w.org/debugpress/assets/icon.svg?rev=2419902\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/debugpress/assets/banner-772x250.png?rev=2383803\";}s:11:\"banners_rtl\";a:0:{}s:14:\"upgrade_notice\";s:53:\"<p>Plugins Panel. Few improvements and bug fixes.</p>\";s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"duplicator/duplicator.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:24:\"w.org/plugins/duplicator\";s:4:\"slug\";s:10:\"duplicator\";s:6:\"plugin\";s:25:\"duplicator/duplicator.php\";s:11:\"new_version\";s:5:\"1.4.0\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/duplicator/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/duplicator.1.4.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/duplicator/assets/icon-256x256.png?rev=2083921\";s:2:\"1x\";s:63:\"https://ps.w.org/duplicator/assets/icon-128x128.png?rev=2083921\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/duplicator/assets/banner-772x250.png?rev=2085472\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:5:\"5.3.8\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:23:\"email-log/email-log.php\";O:8:\"stdClass\":13:{s:2:\"id\";s:23:\"w.org/plugins/email-log\";s:4:\"slug\";s:9:\"email-log\";s:6:\"plugin\";s:23:\"email-log/email-log.php\";s:11:\"new_version\";s:5:\"2.4.5\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/email-log/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/email-log.2.4.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/email-log/assets/icon-256x256.png?rev=1710920\";s:2:\"1x\";s:62:\"https://ps.w.org/email-log/assets/icon-128x128.png?rev=1710920\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/email-log/assets/banner-1544x500.png?rev=1708230\";s:2:\"1x\";s:64:\"https://ps.w.org/email-log/assets/banner-772x250.png?rev=1708230\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/email-log/assets/banner-1544x500-rtl.png?rev=1708230\";s:2:\"1x\";s:68:\"https://ps.w.org/email-log/assets/banner-772x250-rtl.png?rev=1708230\";}s:14:\"upgrade_notice\";s:60:\"<p>Improved admin performance and reduced network calls.</p>\";s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:26:\"post-smtp/postman-smtp.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:23:\"w.org/plugins/post-smtp\";s:4:\"slug\";s:9:\"post-smtp\";s:6:\"plugin\";s:26:\"post-smtp/postman-smtp.php\";s:11:\"new_version\";s:6:\"2.0.23\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/post-smtp/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/post-smtp.2.0.23.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/post-smtp/assets/icon-128x128.gif?rev=2474996\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/post-smtp/assets/banner-772x250.png?rev=2088289\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:25:\"profile-builder/index.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:29:\"w.org/plugins/profile-builder\";s:4:\"slug\";s:15:\"profile-builder\";s:6:\"plugin\";s:25:\"profile-builder/index.php\";s:11:\"new_version\";s:5:\"3.4.3\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/profile-builder/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/profile-builder.3.4.3.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-256x256.png?rev=2257592\";s:2:\"1x\";s:68:\"https://ps.w.org/profile-builder/assets/icon-128x128.png?rev=2257592\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/profile-builder/assets/banner-1544x500.png?rev=2257594\";s:2:\"1x\";s:70:\"https://ps.w.org/profile-builder/assets/banner-772x250.png?rev=2257592\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:47:\"show-current-template/show-current-template.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:35:\"w.org/plugins/show-current-template\";s:4:\"slug\";s:21:\"show-current-template\";s:6:\"plugin\";s:47:\"show-current-template/show-current-template.php\";s:11:\"new_version\";s:5:\"0.4.6\";s:3:\"url\";s:52:\"https://wordpress.org/plugins/show-current-template/\";s:7:\"package\";s:70:\"https://downloads.wordpress.org/plugin/show-current-template.0.4.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:73:\"https://ps.w.org/show-current-template/assets/icon-256x256.png?rev=976031\";s:2:\"1x\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";s:3:\"svg\";s:65:\"https://ps.w.org/show-current-template/assets/icon.svg?rev=976031\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:37:\"user-role-editor/user-role-editor.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:30:\"w.org/plugins/user-role-editor\";s:4:\"slug\";s:16:\"user-role-editor\";s:6:\"plugin\";s:37:\"user-role-editor/user-role-editor.php\";s:11:\"new_version\";s:4:\"4.59\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/user-role-editor/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/user-role-editor.4.59.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-256x256.jpg?rev=1020390\";s:2:\"1x\";s:69:\"https://ps.w.org/user-role-editor/assets/icon-128x128.jpg?rev=1020390\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:71:\"https://ps.w.org/user-role-editor/assets/banner-772x250.png?rev=1263116\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:3:\"5.6\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"5.2.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.5.2.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2366418\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2366418\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2366418\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2366418\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:3:\"7.0\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}s:33:\"wp-bulk-delete/wp-bulk-delete.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:28:\"w.org/plugins/wp-bulk-delete\";s:4:\"slug\";s:14:\"wp-bulk-delete\";s:6:\"plugin\";s:33:\"wp-bulk-delete/wp-bulk-delete.php\";s:11:\"new_version\";s:5:\"1.2.2\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/wp-bulk-delete/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wp-bulk-delete.1.2.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/wp-bulk-delete/assets/icon-256x256.png?rev=2516653\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-bulk-delete/assets/icon-128x128.png?rev=2516653\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/wp-bulk-delete/assets/banner-1544x500.png?rev=2516653\";s:2:\"1x\";s:69:\"https://ps.w.org/wp-bulk-delete/assets/banner-772x250.png?rev=2516653\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.7.1\";s:12:\"requires_php\";s:3:\"5.3\";s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:14:{s:63:\"add-tags-and-category-to-page/add-tags-and-category-to-page.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:43:\"w.org/plugins/add-tags-and-category-to-page\";s:4:\"slug\";s:29:\"add-tags-and-category-to-page\";s:6:\"plugin\";s:63:\"add-tags-and-category-to-page/add-tags-and-category-to-page.php\";s:11:\"new_version\";s:3:\"2.2\";s:3:\"url\";s:60:\"https://wordpress.org/plugins/add-tags-and-category-to-page/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/add-tags-and-category-to-page.2.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:82:\"https://ps.w.org/add-tags-and-category-to-page/assets/icon-128x128.png?rev=1445862\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:83:\"https://ps.w.org/add-tags-and-category-to-page/assets/banner-772x250.png?rev=762741\";}s:11:\"banners_rtl\";a:0:{}}s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:5:\"5.9.5\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.9.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"advanced-settings/index.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/advanced-settings\";s:4:\"slug\";s:17:\"advanced-settings\";s:6:\"plugin\";s:27:\"advanced-settings/index.php\";s:11:\"new_version\";s:5:\"2.3.4\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/advanced-settings/\";s:7:\"package\";s:66:\"https://downloads.wordpress.org/plugin/advanced-settings.2.3.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/advanced-settings/assets/icon-256x256.png?rev=2430335\";s:2:\"1x\";s:70:\"https://ps.w.org/advanced-settings/assets/icon-256x256.png?rev=2430335\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/advanced-settings/assets/banner-772x250.png?rev=2430335\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"cpt-onomies/cpt-onomies.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/cpt-onomies\";s:4:\"slug\";s:11:\"cpt-onomies\";s:6:\"plugin\";s:27:\"cpt-onomies/cpt-onomies.php\";s:11:\"new_version\";s:5:\"1.4.0\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/cpt-onomies/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cpt-onomies.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/cpt-onomies/assets/icon-256x256.png?rev=1115453\";s:2:\"1x\";s:64:\"https://ps.w.org/cpt-onomies/assets/icon-128x128.png?rev=1116576\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:65:\"https://ps.w.org/cpt-onomies/assets/banner-772x250.png?rev=879507\";}s:11:\"banners_rtl\";a:0:{}}s:39:\"custom-post-types/custom-post-types.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/custom-post-types\";s:4:\"slug\";s:17:\"custom-post-types\";s:6:\"plugin\";s:39:\"custom-post-types/custom-post-types.php\";s:11:\"new_version\";s:6:\"2.1.19\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/custom-post-types/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/custom-post-types.2.1.19.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:70:\"https://ps.w.org/custom-post-types/assets/icon-256x256.png?rev=2288459\";s:2:\"1x\";s:62:\"https://ps.w.org/custom-post-types/assets/icon.svg?rev=2288490\";s:3:\"svg\";s:62:\"https://ps.w.org/custom-post-types/assets/icon.svg?rev=2288490\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:72:\"https://ps.w.org/custom-post-types/assets/banner-772x250.png?rev=2288459\";}s:11:\"banners_rtl\";a:0:{}}s:74:\"duplicate-post-page-menu-custom-post-type/duplicate-post-page-menu-cpt.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:55:\"w.org/plugins/duplicate-post-page-menu-custom-post-type\";s:4:\"slug\";s:41:\"duplicate-post-page-menu-custom-post-type\";s:6:\"plugin\";s:74:\"duplicate-post-page-menu-custom-post-type/duplicate-post-page-menu-cpt.php\";s:11:\"new_version\";s:5:\"1.6.0\";s:3:\"url\";s:72:\"https://wordpress.org/plugins/duplicate-post-page-menu-custom-post-type/\";s:7:\"package\";s:84:\"https://downloads.wordpress.org/plugin/duplicate-post-page-menu-custom-post-type.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:94:\"https://ps.w.org/duplicate-post-page-menu-custom-post-type/assets/icon-128x128.png?rev=2203095\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:96:\"https://ps.w.org/duplicate-post-page-menu-custom-post-type/assets/banner-772x250.jpg?rev=2203095\";}s:11:\"banners_rtl\";a:0:{}}s:38:\"sql-chart-builder/guaven_sqlcharts.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:31:\"w.org/plugins/sql-chart-builder\";s:4:\"slug\";s:17:\"sql-chart-builder\";s:6:\"plugin\";s:38:\"sql-chart-builder/guaven_sqlcharts.php\";s:11:\"new_version\";s:5:\"2.2.0\";s:3:\"url\";s:48:\"https://wordpress.org/plugins/sql-chart-builder/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/sql-chart-builder.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/sql-chart-builder/assets/icon-256x256.png?rev=2343690\";s:2:\"1x\";s:70:\"https://ps.w.org/sql-chart-builder/assets/icon-128x128.png?rev=2343690\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/sql-chart-builder/assets/banner-1544x500.png?rev=2343690\";s:2:\"1x\";s:72:\"https://ps.w.org/sql-chart-builder/assets/banner-772x250.png?rev=2343690\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:41:\"post-type-switcher/post-type-switcher.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:32:\"w.org/plugins/post-type-switcher\";s:4:\"slug\";s:18:\"post-type-switcher\";s:6:\"plugin\";s:41:\"post-type-switcher/post-type-switcher.php\";s:11:\"new_version\";s:5:\"3.2.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/post-type-switcher/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/post-type-switcher.3.2.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/post-type-switcher/assets/icon-256x256.jpg?rev=1823578\";s:2:\"1x\";s:71:\"https://ps.w.org/post-type-switcher/assets/icon-128x128.jpg?rev=1823578\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:74:\"https://ps.w.org/post-type-switcher/assets/banner-1544x500.jpg?rev=1823571\";s:2:\"1x\";s:73:\"https://ps.w.org/post-type-switcher/assets/banner-772x250.jpg?rev=1823571\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"sample-data/sample-data.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/sample-data\";s:4:\"slug\";s:11:\"sample-data\";s:6:\"plugin\";s:27:\"sample-data/sample-data.php\";s:11:\"new_version\";s:5:\"1.1.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/sample-data/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/sample-data.1.1.2.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:64:\"https://ps.w.org/sample-data/assets/icon-128x128.jpg?rev=1923678\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/sample-data/assets/banner-772x250.jpg?rev=1923678\";}s:11:\"banners_rtl\";a:0:{}}s:25:\"user-menus/user-menus.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:24:\"w.org/plugins/user-menus\";s:4:\"slug\";s:10:\"user-menus\";s:6:\"plugin\";s:25:\"user-menus/user-menus.php\";s:11:\"new_version\";s:5:\"1.2.5\";s:3:\"url\";s:41:\"https://wordpress.org/plugins/user-menus/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/user-menus.1.2.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:63:\"https://ps.w.org/user-menus/assets/icon-256x256.png?rev=1507838\";s:2:\"1x\";s:63:\"https://ps.w.org/user-menus/assets/icon-128x128.png?rev=1507838\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/user-menus/assets/banner-1544x500.png?rev=1507838\";s:2:\"1x\";s:65:\"https://ps.w.org/user-menus/assets/banner-772x250.png?rev=1507838\";}s:11:\"banners_rtl\";a:0:{}}s:59:\"user-roles-and-capabilities/user-roles-and-capabilities.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:41:\"w.org/plugins/user-roles-and-capabilities\";s:4:\"slug\";s:27:\"user-roles-and-capabilities\";s:6:\"plugin\";s:59:\"user-roles-and-capabilities/user-roles-and-capabilities.php\";s:11:\"new_version\";s:5:\"1.2.4\";s:3:\"url\";s:58:\"https://wordpress.org/plugins/user-roles-and-capabilities/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/user-roles-and-capabilities.1.2.4.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:78:\"https://s.w.org/plugins/geopattern-icon/user-roles-and-capabilities_4583c6.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:82:\"https://ps.w.org/user-roles-and-capabilities/assets/banner-772x250.jpg?rev=1081433\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"user-switching/user-switching.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/user-switching\";s:4:\"slug\";s:14:\"user-switching\";s:6:\"plugin\";s:33:\"user-switching/user-switching.php\";s:11:\"new_version\";s:5:\"1.5.6\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/user-switching/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/user-switching.1.5.6.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:67:\"https://ps.w.org/user-switching/assets/icon-256x256.png?rev=2204931\";s:2:\"1x\";s:59:\"https://ps.w.org/user-switching/assets/icon.svg?rev=2032062\";s:3:\"svg\";s:59:\"https://ps.w.org/user-switching/assets/icon.svg?rev=2032062\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/user-switching/assets/banner-1544x500.png?rev=2204929\";s:2:\"1x\";s:69:\"https://ps.w.org/user-switching/assets/banner-772x250.png?rev=2204929\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"wp-mail-smtp/wp_mail_smtp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/wp-mail-smtp\";s:4:\"slug\";s:12:\"wp-mail-smtp\";s:6:\"plugin\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:11:\"new_version\";s:5:\"2.7.0\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wp-mail-smtp/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-mail-smtp.2.7.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-256x256.png?rev=1755440\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-128x128.png?rev=1755440\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wp-mail-smtp/assets/banner-1544x500.png?rev=2468655\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-mail-smtp/assets/banner-772x250.png?rev=2468655\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(976, '_site_transient_timeout_php_check_6a93f292d9a273c004fc36e1f86d97b3', '1620449030', 'no'),
(977, '_site_transient_php_check_6a93f292d9a273c004fc36e1f86d97b3', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(978, 'secure_auth_key', 'w=;nc::%og>JoJ O$T+p8}gMA=;soEUHP0B+0`~=&aGyRTc>mU~7y3OF3H|z%8Y>', 'no'),
(979, 'secure_auth_salt', ':kO.jlS o=Pg0a.x^!!wAIk|t.R(2}*ckg_3f4)oo57hL%q6gi*w!rTgrZaW-<:<', 'no'),
(980, 'logged_in_key', 'Q?$Q7B$vdvoYp_&J:6f.S`T?<Yr5(W8;+,1mggZ}d1Q}y:z8,-=iH@i7Uahe<w`m', 'no'),
(981, 'logged_in_salt', 'De-Tt?G$3{=23gGch9pCMok)6zf*Ms^$ay>>WfLf8HhV^:5.,qkm3NmIY ,3 gj5', 'no'),
(982, 'auth_key', 'By)U.M$4X=&Nh,.d>Fmxn4a0Jc)f)PqlRsv^Yxr2khzCm)n{^qJQZ;BuY4qS{gq0', 'no'),
(983, 'auth_salt', 'EfP P*b{yOW2QS:JKN&PV0|&ahfRzx wpV5z+0xW_=>KS+bs>:E7M1ci2|o?kok&', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `us_postmeta`
--

CREATE TABLE `us_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_postmeta`
--

INSERT INTO `us_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_menu_item_type', 'post_type'),
(4, 5, '_menu_item_menu_item_parent', '0'),
(5, 5, '_menu_item_object_id', '1'),
(6, 5, '_menu_item_object', 'post'),
(7, 5, '_menu_item_target', ''),
(8, 5, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(9, 5, '_menu_item_xfn', ''),
(10, 5, '_menu_item_url', ''),
(11, 5, '_menu_item_orphaned', '1615351762'),
(12, 6, '_edit_lock', '1615883355:1'),
(23, 10, '_menu_item_type', 'custom'),
(24, 10, '_menu_item_menu_item_parent', '0'),
(25, 10, '_menu_item_object_id', '10'),
(26, 10, '_menu_item_object', 'custom'),
(27, 10, '_menu_item_target', ''),
(28, 10, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(29, 10, '_menu_item_xfn', ''),
(30, 10, '_menu_item_url', '#'),
(41, 13, '_edit_last', '1'),
(42, 13, '_edit_lock', '1616568555:1'),
(43, 13, '_tax_settings_meta', 'a:15:{s:6:\"tax_id\";s:15:\"shop_categories\";s:17:\"tax_singular_name\";s:13:\"shop Category\";s:16:\"tax_search_items\";s:0:\"\";s:13:\"tax_all_items\";s:0:\"\";s:15:\"tax_parent_item\";s:0:\"\";s:21:\"tax_parent_item_colon\";s:0:\"\";s:13:\"tax_edit_item\";s:0:\"\";s:15:\"tax_update_item\";s:0:\"\";s:16:\"tax_add_new_item\";s:0:\"\";s:17:\"tax_new_item_name\";s:0:\"\";s:13:\"tax_menu_name\";s:0:\"\";s:16:\"tax_hierarchical\";s:1:\"1\";s:10:\"tax_public\";s:1:\"1\";s:14:\"tax_post_types\";a:1:{i:0;s:7:\"service\";}s:8:\"tax_role\";s:1:\"1\";}'),
(44, 6, '_wp_page_template', 'page-templates/page-login.php'),
(45, 6, '_edit_last', '1'),
(49, 16, '_edit_lock', '1616994199:1'),
(50, 16, '_wp_page_template', 'page-templates/page-registration.php'),
(51, 16, '_edit_last', '1'),
(52, 18, '_edit_last', '1'),
(53, 18, '_edit_lock', '1616568522:1'),
(54, 18, '_tax_settings_meta', 'a:15:{s:6:\"tax_id\";s:9:\"districts\";s:17:\"tax_singular_name\";s:8:\"District\";s:16:\"tax_search_items\";s:0:\"\";s:13:\"tax_all_items\";s:0:\"\";s:15:\"tax_parent_item\";s:0:\"\";s:21:\"tax_parent_item_colon\";s:0:\"\";s:13:\"tax_edit_item\";s:0:\"\";s:15:\"tax_update_item\";s:0:\"\";s:16:\"tax_add_new_item\";s:0:\"\";s:17:\"tax_new_item_name\";s:0:\"\";s:13:\"tax_menu_name\";s:0:\"\";s:16:\"tax_hierarchical\";s:1:\"1\";s:10:\"tax_public\";s:1:\"1\";s:14:\"tax_post_types\";a:2:{i:0;s:7:\"service\";i:1;s:4:\"shop\";}s:8:\"tax_role\";s:1:\"1\";}'),
(55, 20, '_menu_item_type', 'post_type'),
(56, 20, '_menu_item_menu_item_parent', '0'),
(57, 20, '_menu_item_object_id', '16'),
(58, 20, '_menu_item_object', 'page'),
(59, 20, '_menu_item_target', ''),
(60, 20, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(61, 20, '_menu_item_xfn', ''),
(62, 20, '_menu_item_url', ''),
(64, 10, '_wp_old_date', '2021-03-15'),
(71, 21, '_edit_lock', '1616254912:1'),
(72, 21, '_edit_last', '1'),
(73, 21, '_wp_page_template', 'page-templates/page-addshop.php'),
(75, 25, '_menu_item_type', 'post_type'),
(76, 25, '_menu_item_menu_item_parent', '0'),
(77, 25, '_menu_item_object_id', '21'),
(78, 25, '_menu_item_object', 'page'),
(79, 25, '_menu_item_target', ''),
(80, 25, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(81, 25, '_menu_item_xfn', ''),
(82, 25, '_menu_item_url', ''),
(84, 10, '_wp_old_date', '2021-03-16'),
(85, 20, '_wp_old_date', '2021-03-16'),
(89, 35, '_edit_lock', '1616255753:1'),
(90, 35, '_wp_page_template', 'page-templates/page-user-dashboard.php'),
(91, 35, '_edit_last', '1'),
(92, 38, '_menu_item_type', 'post_type'),
(93, 38, '_menu_item_menu_item_parent', '0'),
(94, 38, '_menu_item_object_id', '35'),
(95, 38, '_menu_item_object', 'page'),
(96, 38, '_menu_item_target', ''),
(97, 38, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(98, 38, '_menu_item_xfn', ''),
(99, 38, '_menu_item_url', ''),
(101, 10, '_wp_old_date', '2021-03-20'),
(102, 20, '_wp_old_date', '2021-03-20'),
(103, 25, '_wp_old_date', '2021-03-20'),
(128, 28, '_edit_lock', '1616406879:1'),
(132, 47, '_edit_lock', '1616410225:1'),
(133, 47, '_wp_page_template', 'page-templates/page-additem.php'),
(134, 47, '_edit_last', '1'),
(136, 57, '_menu_item_type', 'post_type'),
(137, 57, '_menu_item_menu_item_parent', '0'),
(138, 57, '_menu_item_object_id', '47'),
(139, 57, '_menu_item_object', 'page'),
(140, 57, '_menu_item_target', ''),
(141, 57, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(142, 57, '_menu_item_xfn', ''),
(143, 57, '_menu_item_url', ''),
(145, 10, '_wp_old_date', '2021-03-21'),
(146, 20, '_wp_old_date', '2021-03-21'),
(147, 25, '_wp_old_date', '2021-03-21'),
(148, 38, '_wp_old_date', '2021-03-21'),
(149, 59, '_edit_lock', '1616476190:1'),
(150, 59, '_edit_last', '1'),
(156, 64, '_edit_lock', '1616574817:1'),
(157, 64, '_edit_last', '1'),
(158, 64, '_tax_settings_meta', 'a:15:{s:6:\"tax_id\";s:18:\"service_categories\";s:17:\"tax_singular_name\";s:16:\"service category\";s:16:\"tax_search_items\";s:0:\"\";s:13:\"tax_all_items\";s:0:\"\";s:15:\"tax_parent_item\";s:0:\"\";s:21:\"tax_parent_item_colon\";s:0:\"\";s:13:\"tax_edit_item\";s:0:\"\";s:15:\"tax_update_item\";s:0:\"\";s:16:\"tax_add_new_item\";s:0:\"\";s:17:\"tax_new_item_name\";s:0:\"\";s:13:\"tax_menu_name\";s:0:\"\";s:16:\"tax_hierarchical\";s:1:\"1\";s:10:\"tax_public\";s:1:\"1\";s:14:\"tax_post_types\";a:1:{i:0;s:7:\"service\";}s:8:\"tax_role\";s:1:\"1\";}'),
(168, 10, '_wp_old_date', '2021-03-22'),
(169, 20, '_wp_old_date', '2021-03-22'),
(170, 25, '_wp_old_date', '2021-03-22'),
(171, 38, '_wp_old_date', '2021-03-22'),
(172, 57, '_wp_old_date', '2021-03-22'),
(192, 71, '_edit_lock', '1616497025:1'),
(193, 71, '_wp_page_template', 'page-templates/page-add-service.php'),
(194, 71, '_edit_last', '1'),
(195, 73, '_menu_item_type', 'post_type'),
(196, 73, '_menu_item_menu_item_parent', '0'),
(197, 73, '_menu_item_object_id', '71'),
(198, 73, '_menu_item_object', 'page'),
(199, 73, '_menu_item_target', ''),
(200, 73, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(201, 73, '_menu_item_xfn', ''),
(202, 73, '_menu_item_url', ''),
(205, 81, '_edit_lock', '1616487543:1'),
(206, 81, '_edit_last', '1'),
(207, 83, '_wp_attached_file', '2021/03/fancy.jpg'),
(208, 83, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:550;s:6:\"height\";i:423;s:4:\"file\";s:17:\"2021/03/fancy.jpg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"fancy-300x231.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:231;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"fancy-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(209, 84, '_edit_lock', '1616486264:1'),
(210, 84, '_wp_page_template', 'page-templates/page-customer-home.php'),
(211, 84, '_edit_last', '1'),
(212, 86, '_edit_lock', '1616571289:1'),
(213, 86, '_edit_last', '1'),
(214, 86, '_tax_settings_meta', 'a:15:{s:6:\"tax_id\";s:13:\"custom_status\";s:17:\"tax_singular_name\";s:13:\"custom_status\";s:16:\"tax_search_items\";s:0:\"\";s:13:\"tax_all_items\";s:0:\"\";s:15:\"tax_parent_item\";s:0:\"\";s:21:\"tax_parent_item_colon\";s:0:\"\";s:13:\"tax_edit_item\";s:0:\"\";s:15:\"tax_update_item\";s:0:\"\";s:16:\"tax_add_new_item\";s:0:\"\";s:17:\"tax_new_item_name\";s:0:\"\";s:13:\"tax_menu_name\";s:0:\"\";s:16:\"tax_hierarchical\";s:1:\"1\";s:10:\"tax_public\";s:1:\"1\";s:14:\"tax_post_types\";a:1:{i:0;s:7:\"service\";}s:8:\"tax_role\";s:1:\"1\";}'),
(215, 87, '_edit_lock', '1616548969:1'),
(216, 87, '_wp_page_template', 'page-templates/page-users.php'),
(217, 87, '_edit_last', '1'),
(221, 90, '_menu_item_type', 'post_type'),
(222, 90, '_menu_item_menu_item_parent', '0'),
(223, 90, '_menu_item_object_id', '87'),
(224, 90, '_menu_item_object', 'page'),
(225, 90, '_menu_item_target', ''),
(226, 90, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(227, 90, '_menu_item_xfn', ''),
(228, 90, '_menu_item_url', ''),
(229, 90, '_menu_item_orphaned', '1616560078'),
(230, 91, '_wp_attached_file', '2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg'),
(231, 91, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:52:\"2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:52:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(232, 92, '_wp_attached_file', '2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg'),
(233, 92, '_wp_attachment_context', 'custom-logo'),
(234, 92, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:296;s:6:\"height\";i:162;s:4:\"file\";s:60:\"2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:60:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(237, 94, '_edit_lock', '1616662867:1'),
(238, 94, '_wp_page_template', 'page-templates/page-add-purchase.php'),
(239, 94, '_edit_last', '1'),
(240, 253, '_wp_attached_file', '2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg'),
(241, 253, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:54:\"2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:54:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:54:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(242, 255, '_menu_item_type', 'post_type'),
(243, 255, '_menu_item_menu_item_parent', '0'),
(244, 255, '_menu_item_object_id', '6'),
(245, 255, '_menu_item_object', 'page'),
(246, 255, '_menu_item_target', ''),
(247, 255, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(248, 255, '_menu_item_xfn', ''),
(249, 255, '_menu_item_url', ''),
(251, 10, '_wp_old_date', '2021-03-23'),
(252, 20, '_wp_old_date', '2021-03-23'),
(253, 25, '_wp_old_date', '2021-03-23'),
(254, 38, '_wp_old_date', '2021-03-23'),
(255, 57, '_wp_old_date', '2021-03-23'),
(256, 73, '_wp_old_date', '2021-03-23'),
(257, 256, '_menu_item_type', 'post_type'),
(258, 256, '_menu_item_menu_item_parent', '0'),
(259, 256, '_menu_item_object_id', '87'),
(260, 256, '_menu_item_object', 'page'),
(261, 256, '_menu_item_target', ''),
(262, 256, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(263, 256, '_menu_item_xfn', ''),
(264, 256, '_menu_item_url', ''),
(266, 260, '_wp_attached_file', '2021/03/specials-5.png'),
(267, 260, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:800;s:6:\"height\";i:822;s:4:\"file\";s:22:\"2021/03/specials-5.png\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"specials-5-292x300.png\";s:5:\"width\";i:292;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"specials-5-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"specials-5-768x789.png\";s:5:\"width\";i:768;s:6:\"height\";i:789;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(268, 265, '_wp_attached_file', '2021/03/download.jpg'),
(269, 265, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:168;s:4:\"file\";s:20:\"2021/03/download.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"download-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(280, 271, '_wp_attached_file', '2021/03/download-6.jpg'),
(281, 271, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:168;s:4:\"file\";s:22:\"2021/03/download-6.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"download-6-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(282, 274, '_wp_attached_file', '2021/03/download-7.jpg'),
(283, 274, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:300;s:6:\"height\";i:168;s:4:\"file\";s:22:\"2021/03/download-7.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"download-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(284, 275, '_wp_attached_file', '2021/03/istockphoto-1212364562-1024x1024-1.jpg'),
(285, 275, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:782;s:6:\"height\";i:1024;s:4:\"file\";s:46:\"2021/03/istockphoto-1212364562-1024x1024-1.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-1-229x300.jpg\";s:5:\"width\";i:229;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:47:\"istockphoto-1212364562-1024x1024-1-768x1006.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1006;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:24:\"Getty Images/iStockphoto\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:100:\"1 year old cute baby girl in a pink dress is playing with teddy bear on the bed in Bangkok Thailand.\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(286, 276, '_wp_attached_file', '2021/03/istockphoto-1212364562-1024x1024-2.jpg'),
(287, 276, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:782;s:6:\"height\";i:1024;s:4:\"file\";s:46:\"2021/03/istockphoto-1212364562-1024x1024-2.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-2-229x300.jpg\";s:5:\"width\";i:229;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:47:\"istockphoto-1212364562-1024x1024-2-768x1006.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1006;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:24:\"Getty Images/iStockphoto\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:100:\"1 year old cute baby girl in a pink dress is playing with teddy bear on the bed in Bangkok Thailand.\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(296, 281, '_wp_attached_file', '2021/03/istockphoto-1212364562-1024x1024-7.jpg'),
(297, 281, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:782;s:6:\"height\";i:1024;s:4:\"file\";s:46:\"2021/03/istockphoto-1212364562-1024x1024-7.jpg\";s:5:\"sizes\";a:3:{s:6:\"medium\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-7-229x300.jpg\";s:5:\"width\";i:229;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:46:\"istockphoto-1212364562-1024x1024-7-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:47:\"istockphoto-1212364562-1024x1024-7-768x1006.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1006;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:24:\"Getty Images/iStockphoto\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:100:\"1 year old cute baby girl in a pink dress is playing with teddy bear on the bed in Bangkok Thailand.\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(390, 334, '_wp_attached_file', '2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg'),
(391, 334, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:55:\"2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:55:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:55:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(392, 335, '_wp_attached_file', '2021/03/WIN_20200622_16_54_20_Pro.jpg'),
(393, 335, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:37:\"2021/03/WIN_20200622_16_54_20_Pro.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:37:\"WIN_20200622_16_54_20_Pro-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:38:\"WIN_20200622_16_54_20_Pro-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:37:\"WIN_20200622_16_54_20_Pro-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"WIN_20200622_16_54_20_Pro-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(394, 336, '_wp_attached_file', '2021/03/WIN_20200622_16_54_20_Pro-1.jpg'),
(395, 336, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:39:\"2021/03/WIN_20200622_16_54_20_Pro-1.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-1-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"WIN_20200622_16_54_20_Pro-1-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-1-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(396, 337, '_wp_attached_file', '2021/03/WIN_20200622_16_54_20_Pro-2.jpg'),
(397, 337, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:39:\"2021/03/WIN_20200622_16_54_20_Pro-2.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-2-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"WIN_20200622_16_54_20_Pro-2-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-2-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(398, 338, '_wp_attached_file', '2021/03/WIN_20200622_16_54_20_Pro-3.jpg'),
(399, 338, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1280;s:6:\"height\";i:720;s:4:\"file\";s:39:\"2021/03/WIN_20200622_16_54_20_Pro-3.jpg\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-3-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:40:\"WIN_20200622_16_54_20_Pro-3-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:39:\"WIN_20200622_16_54_20_Pro-3-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(400, 361, '_wp_attached_file', '2021/04/wp2365076-scaled.jpg'),
(401, 361, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1600;s:4:\"file\";s:28:\"2021/04/wp2365076-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"wp2365076-300x188.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:188;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:22:\"wp2365076-1024x640.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:640;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"wp2365076-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"wp2365076-768x480.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:480;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:22:\"wp2365076-1536x960.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:960;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:23:\"wp2365076-2048x1280.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1280;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:13:\"wp2365076.jpg\";}'),
(402, 362, '_wp_attached_file', '2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg'),
(403, 362, '_wp_attachment_context', 'site-icon'),
(404, 362, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:63:\"2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:63:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:63:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:63:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-270x270.jpeg\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:63:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-192x192.jpeg\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:63:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-180x180.jpeg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:61:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36-32x32.jpeg\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(405, 363, '_wp_trash_meta_status', 'publish'),
(406, 363, '_wp_trash_meta_time', '1617274823'),
(407, 364, '_wp_attached_file', '2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg'),
(408, 364, '_wp_attachment_context', 'site-icon'),
(409, 364, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:62:\"2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-270x270.jpeg\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-192x192.jpeg\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-180x180.jpeg\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:60:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-32x32.jpeg\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(410, 365, '_wp_trash_meta_status', 'publish'),
(411, 365, '_wp_trash_meta_time', '1617274903'),
(412, 366, '_wp_attached_file', '2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg'),
(413, 366, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:52:\"2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:52:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:52:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(414, 367, '_wp_attached_file', '2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg'),
(415, 367, '_wp_attachment_context', 'custom-logo'),
(416, 367, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:166;s:4:\"file\";s:60:\"2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:60:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-300x100.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:60:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(417, 368, '_wp_trash_meta_status', 'publish'),
(418, 368, '_wp_trash_meta_time', '1617275160'),
(419, 369, '_wp_attached_file', '2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg'),
(420, 369, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:500;s:4:\"file\";s:54:\"2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:54:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-300x300.jpeg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:54:\"WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-150x150.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(421, 370, '_edit_lock', '1617275201:1'),
(422, 371, '_wp_attached_file', '2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg'),
(423, 371, '_wp_attachment_context', 'custom-logo'),
(424, 371, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:219;s:6:\"height\";i:146;s:4:\"file\";s:62:\"2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:62:\"cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1-150x146.jpeg\";s:5:\"width\";i:150;s:6:\"height\";i:146;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(425, 370, '_wp_trash_meta_status', 'publish'),
(426, 370, '_wp_trash_meta_time', '1617275218'),
(427, 372, '_edit_lock', '1617277799:1'),
(428, 372, '_wp_page_template', 'page-templates/page-shops.php'),
(429, 372, '_edit_last', '1'),
(430, 376, '_edit_lock', '1617277497:1'),
(431, 376, '_edit_last', '1'),
(432, 372, '_wp_trash_meta_status', 'publish'),
(433, 372, '_wp_trash_meta_time', '1617277944'),
(434, 372, '_wp_desired_post_slug', 'shop-list'),
(435, 430, '_wp_attached_file', '2021/04/up-store-logo.png'),
(436, 430, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2100;s:6:\"height\";i:1500;s:4:\"file\";s:25:\"2021/04/up-store-logo.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"up-store-logo-300x214.png\";s:5:\"width\";i:300;s:6:\"height\";i:214;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"up-store-logo-1024x731.png\";s:5:\"width\";i:1024;s:6:\"height\";i:731;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"up-store-logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"up-store-logo-768x549.png\";s:5:\"width\";i:768;s:6:\"height\";i:549;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:27:\"up-store-logo-1536x1097.png\";s:5:\"width\";i:1536;s:6:\"height\";i:1097;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:27:\"up-store-logo-2048x1463.png\";s:5:\"width\";i:2048;s:6:\"height\";i:1463;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(437, 431, '_edit_lock', '1617605421:1'),
(438, 431, '_wp_trash_meta_status', 'publish'),
(439, 431, '_wp_trash_meta_time', '1617605441'),
(440, 441, '_wp_attached_file', '2021/04/callia-beauty-care-3-2-scaled.jpg'),
(441, 441, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1810;s:6:\"height\";i:2560;s:4:\"file\";s:41:\"2021/04/callia-beauty-care-3-2-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:34:\"callia-beauty-care-3-2-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:35:\"callia-beauty-care-3-2-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:34:\"callia-beauty-care-3-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"callia-beauty-care-3-2-768x1086.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-1086x1536.jpg\";s:5:\"width\";i:1086;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-1448x2048.jpg\";s:5:\"width\";i:1448;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:11:\"tulips unni\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:8:\"Graphic1\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:26:\"callia-beauty-care-3-2.jpg\";}'),
(442, 442, '_wp_attached_file', '2021/04/callia-beauty-care-3-2-1-scaled.jpg'),
(443, 442, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1810;s:6:\"height\";i:2560;s:4:\"file\";s:43:\"2021/04/callia-beauty-care-3-2-1-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-1-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-1-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-1-768x1086.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-1-1086x1536.jpg\";s:5:\"width\";i:1086;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-1-1448x2048.jpg\";s:5:\"width\";i:1448;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:11:\"tulips unni\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:8:\"Graphic1\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"callia-beauty-care-3-2-1.jpg\";}'),
(444, 443, '_wp_attached_file', '2021/04/callia-beauty-care-3-2-2-scaled.jpg'),
(445, 443, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1810;s:6:\"height\";i:2560;s:4:\"file\";s:43:\"2021/04/callia-beauty-care-3-2-2-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-2-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-2-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-2-768x1086.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-2-1086x1536.jpg\";s:5:\"width\";i:1086;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-2-1448x2048.jpg\";s:5:\"width\";i:1448;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:11:\"tulips unni\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:8:\"Graphic1\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"callia-beauty-care-3-2-2.jpg\";}'),
(446, 444, '_wp_attached_file', '2021/04/callia-beauty-care-3-2-3-scaled.jpg'),
(447, 444, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1810;s:6:\"height\";i:2560;s:4:\"file\";s:43:\"2021/04/callia-beauty-care-3-2-3-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-3-212x300.jpg\";s:5:\"width\";i:212;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-3-724x1024.jpg\";s:5:\"width\";i:724;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:36:\"callia-beauty-care-3-2-3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:37:\"callia-beauty-care-3-2-3-768x1086.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-3-1086x1536.jpg\";s:5:\"width\";i:1086;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:38:\"callia-beauty-care-3-2-3-1448x2048.jpg\";s:5:\"width\";i:1448;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:11:\"tulips unni\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:8:\"Graphic1\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:28:\"callia-beauty-care-3-2-3.jpg\";}');

-- --------------------------------------------------------

--
-- Table structure for table `us_posts`
--

CREATE TABLE `us_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_posts`
--

INSERT INTO `us_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-03-10 04:05:09', '2021-03-10 04:05:09', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2021-03-10 04:05:09', '2021-03-10 04:05:09', '', 0, 'http://localhost:8080/upstore/?p=1', 0, 'post', '', 1),
(2, 1, '2021-03-10 04:05:09', '2021-03-10 04:05:09', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost:8080/upstore/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2021-03-10 04:05:09', '2021-03-10 04:05:09', '', 0, 'http://localhost:8080/upstore/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-03-10 04:05:09', '2021-03-10 04:05:09', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://localhost:8080/upstore.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-03-10 04:05:09', '2021-03-10 04:05:09', '', 0, 'http://localhost:8080/upstore/?page_id=3', 0, 'page', '', 0),
(5, 1, '2021-03-10 04:49:22', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-03-10 04:49:22', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=5', 1, 'nav_menu_item', '', 0),
(6, 1, '2021-03-15 04:36:43', '2021-03-15 04:36:43', '', 'Login', '', 'publish', 'closed', 'closed', '', 'login', '', '', '2021-03-15 06:21:23', '2021-03-15 06:21:23', '', 0, 'http://localhost:8080/upstore/?page_id=6', 0, 'page', '', 0),
(7, 1, '2021-03-15 04:36:43', '2021-03-15 04:36:43', '', 'Login', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2021-03-15 04:36:43', '2021-03-15 04:36:43', '', 6, 'http://localhost:8080/upstore/?p=7', 0, 'revision', '', 0),
(10, 1, '2021-03-29 06:06:53', '2021-03-15 04:57:52', '', 'details', '', 'publish', 'closed', 'closed', '', 'details', '', '', '2021-03-29 06:06:53', '2021-03-29 06:06:53', '', 0, 'http://localhost:8080/upstore/?p=10', 1, 'nav_menu_item', '', 0),
(13, 1, '2021-03-15 06:15:52', '2021-03-15 06:15:52', '', 'Shop Categories', '', 'publish', 'closed', 'closed', '', 'categories', '', '', '2021-03-24 06:51:35', '2021-03-24 06:51:35', '', 0, 'http://localhost:8080/upstore/?post_type=manage_cpt_tax&#038;p=13', 0, 'manage_cpt_tax', '', 0),
(16, 1, '2021-03-15 07:49:23', '2021-03-15 07:49:23', '', 'Registration', '', 'publish', 'closed', 'closed', '', 'registration', '', '', '2021-03-29 05:03:19', '2021-03-29 05:03:19', '', 0, 'http://localhost:8080/upstore/?page_id=16', 0, 'page', '', 0),
(17, 1, '2021-03-15 07:49:23', '2021-03-15 07:49:23', '', 'Registration', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2021-03-15 07:49:23', '2021-03-15 07:49:23', '', 16, 'http://localhost:8080/upstore/?p=17', 0, 'revision', '', 0),
(18, 1, '2021-03-16 02:01:12', '2021-03-16 02:01:12', '', 'Districts', '', 'publish', 'closed', 'closed', '', 'districts', '', '', '2021-03-23 05:37:57', '2021-03-23 05:37:57', '', 0, 'http://localhost:8080/upstore/?post_type=manage_cpt_tax&#038;p=18', 0, 'manage_cpt_tax', '', 0),
(20, 1, '2021-03-29 06:06:53', '2021-03-16 02:10:48', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2021-03-29 06:06:53', '2021-03-29 06:06:53', '', 0, 'http://localhost:8080/upstore/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2021-03-16 08:32:01', '2021-03-16 08:32:01', '', 'Add-Shop', '', 'publish', 'closed', 'closed', '', 'add-shop', '', '', '2021-03-20 15:41:52', '2021-03-20 15:41:52', '', 0, 'http://localhost:8080/upstore/?page_id=21', 0, 'page', '', 0),
(22, 1, '2021-03-16 08:32:01', '2021-03-16 08:32:01', '', 'Add-Shop', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2021-03-16 08:32:01', '2021-03-16 08:32:01', '', 21, 'http://localhost:8080/upstore/?p=22', 0, 'revision', '', 0),
(25, 1, '2021-03-29 06:06:53', '2021-03-20 15:32:34', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2021-03-29 06:06:53', '2021-03-29 06:06:53', '', 0, 'http://localhost:8080/upstore/?p=25', 3, 'nav_menu_item', '', 0),
(28, 1, '2021-03-20 15:36:42', '2021-03-20 15:36:42', '', 'test_item', '', 'publish', 'closed', 'closed', '', 'test_item', '', '', '2021-03-20 15:36:42', '2021-03-20 15:36:42', '', 0, 'http://localhost:8080/upstore/?p=28', 0, 'item', '', 0),
(34, 1, '2021-03-20 15:51:42', '2021-03-20 15:51:42', '', 'test', '', 'publish', 'open', 'open', '', 'test', '', '', '2021-03-20 15:51:42', '2021-03-20 15:51:42', '', 0, 'http://localhost:8080/upstore/shop/test/', 0, 'shop', '', 0),
(35, 1, '2021-03-20 15:55:52', '2021-03-20 15:55:52', '', 'Dashboard', '', 'publish', 'closed', 'closed', '', 'dashboard', '', '', '2021-03-20 15:55:53', '2021-03-20 15:55:53', '', 0, 'http://localhost:8080/upstore/?page_id=35', 0, 'page', '', 0),
(36, 1, '2021-03-20 15:55:52', '2021-03-20 15:55:52', '', 'Dashboard', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2021-03-20 15:55:52', '2021-03-20 15:55:52', '', 35, 'http://localhost:8080/upstore/?p=36', 0, 'revision', '', 0),
(38, 1, '2021-03-29 06:06:53', '2021-03-21 13:08:00', ' ', '', '', 'publish', 'closed', 'closed', '', '38', '', '', '2021-03-29 06:06:53', '2021-03-29 06:06:53', '', 0, 'http://localhost:8080/upstore/?p=38', 4, 'nav_menu_item', '', 0),
(45, 1, '2021-03-22 10:46:43', '2021-03-22 10:46:43', '', 'test1234', '', 'publish', 'open', 'open', '', 'test1234', '', '', '2021-03-22 10:46:43', '2021-03-22 10:46:43', '', 0, 'http://localhost/upstore/shop/test1234/', 0, 'shop', '', 0),
(46, 1, '2021-03-22 10:48:05', '2021-03-22 10:48:05', '', 'test111111', '', 'publish', 'open', 'open', '', 'test111111', '', '', '2021-03-22 10:48:05', '2021-03-22 10:48:05', '', 0, 'http://localhost/upstore/shop/test111111/', 0, 'shop', '', 0),
(47, 1, '2021-03-22 10:50:24', '2021-03-22 10:50:24', '', 'Add Items', '', 'publish', 'closed', 'closed', '', 'add-items', '', '', '2021-03-22 10:50:25', '2021-03-22 10:50:25', '', 0, 'http://localhost/upstore/?page_id=47', 0, 'page', '', 0),
(48, 1, '2021-03-22 10:50:24', '2021-03-22 10:50:24', '', 'Add Items', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2021-03-22 10:50:24', '2021-03-22 10:50:24', '', 47, 'http://localhost/upstore/?p=48', 0, 'revision', '', 0),
(49, 1, '2021-03-22 10:50:31', '2021-03-22 10:50:31', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-2', '', '', '2021-03-22 10:50:31', '2021-03-22 10:50:31', '', 0, 'http://localhost/upstore/item/test_item-2/', 0, 'item', '', 0),
(50, 1, '2021-03-22 10:51:22', '2021-03-22 10:51:22', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-3', '', '', '2021-03-22 10:51:22', '2021-03-22 10:51:22', '', 0, 'http://localhost/upstore/item/test_item-3/', 0, 'item', '', 0),
(51, 1, '2021-03-22 10:51:45', '2021-03-22 10:51:45', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-4', '', '', '2021-03-22 10:51:45', '2021-03-22 10:51:45', '', 0, 'http://localhost/upstore/item/test_item-4/', 0, 'item', '', 0),
(52, 1, '2021-03-22 10:52:15', '2021-03-22 10:52:15', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-5', '', '', '2021-03-22 10:52:15', '2021-03-22 10:52:15', '', 0, 'http://localhost/upstore/item/test_item-5/', 0, 'item', '', 0),
(53, 1, '2021-03-22 10:52:38', '2021-03-22 10:52:38', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-6', '', '', '2021-03-22 10:52:38', '2021-03-22 10:52:38', '', 0, 'http://localhost/upstore/item/test_item-6/', 0, 'item', '', 0),
(54, 1, '2021-03-22 10:52:57', '2021-03-22 10:52:57', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-7', '', '', '2021-03-22 10:52:57', '2021-03-22 10:52:57', '', 0, 'http://localhost/upstore/item/test_item-7/', 0, 'item', '', 0),
(55, 1, '2021-03-22 11:00:57', '2021-03-22 11:00:57', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-8', '', '', '2021-03-22 11:00:57', '2021-03-22 11:00:57', '', 0, 'http://localhost/upstore/item/test_item-8/', 0, 'item', '', 0),
(57, 1, '2021-03-29 06:06:54', '2021-03-22 11:23:33', ' ', '', '', 'publish', 'closed', 'closed', '', '57', '', '', '2021-03-29 06:06:54', '2021-03-29 06:06:54', '', 0, 'http://localhost/upstore/?p=57', 5, 'nav_menu_item', '', 0),
(58, 1, '2021-03-22 12:32:38', '2021-03-22 12:32:38', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-9', '', '', '2021-03-22 12:32:38', '2021-03-22 12:32:38', '', 0, 'http://localhost/upstore/item/test_item-9/', 0, 'item', '', 0),
(59, 1, '2021-03-23 05:09:50', '0000-00-00 00:00:00', '', 'service', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-23 05:09:50', '2021-03-23 05:09:50', '', 0, 'http://localhost/upstore/?post_type=service&#038;p=59', 0, 'service', '', 0),
(64, 1, '2021-03-23 05:52:59', '2021-03-23 05:52:59', '', 'Service Categories', '', 'publish', 'closed', 'closed', '', 'service-categories', '', '', '2021-03-23 06:04:53', '2021-03-23 06:04:53', '', 0, 'http://localhost/upstore/?post_type=manage_cpt_tax&#038;p=64', 0, 'manage_cpt_tax', '', 0),
(69, 1, '2021-03-23 06:12:16', '2021-03-23 06:12:16', '', 'test', '', 'publish', 'open', 'open', '', 'test-2', '', '', '2021-03-23 06:12:16', '2021-03-23 06:12:16', '', 0, 'http://localhost/upstore/shop/test-2/', 0, 'shop', '', 0),
(71, 1, '2021-03-23 06:20:44', '2021-03-23 06:20:44', '', 'Add Service', '', 'publish', 'closed', 'closed', '', 'add-service', '', '', '2021-03-23 07:38:39', '2021-03-23 07:38:39', '', 0, 'http://localhost/upstore/?page_id=71', 0, 'page', '', 0),
(72, 1, '2021-03-23 06:20:44', '2021-03-23 06:20:44', '', 'Add Service', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2021-03-23 06:20:44', '2021-03-23 06:20:44', '', 71, 'http://localhost/upstore/?p=72', 0, 'revision', '', 0),
(73, 1, '2021-03-29 06:06:54', '2021-03-23 06:21:31', ' ', '', '', 'publish', 'closed', 'closed', '', '73', '', '', '2021-03-29 06:06:54', '2021-03-29 06:06:54', '', 0, 'http://localhost/upstore/?p=73', 6, 'nav_menu_item', '', 0),
(75, 1, '2021-03-23 06:40:29', '2021-03-23 06:40:29', '', 'test_service', '', 'publish', 'open', 'open', '', 'test_service', '', '', '2021-03-23 06:40:29', '2021-03-23 06:40:29', '', 0, 'http://localhost/upstore/service/test_service/', 0, 'service', '', 0),
(76, 1, '2021-03-23 06:40:55', '2021-03-23 06:40:55', '', 'test_service', '', 'publish', 'open', 'open', '', 'test_service-2', '', '', '2021-03-23 06:40:55', '2021-03-23 06:40:55', '', 0, 'http://localhost/upstore/service/test_service-2/', 0, 'service', '', 0),
(77, 1, '2021-03-23 07:27:54', '2021-03-23 07:27:54', '', 'test', '', 'publish', 'open', 'open', '', 'test-3', '', '', '2021-03-23 07:27:54', '2021-03-23 07:27:54', '', 0, 'http://localhost:8080/upstore/shop/test-3/', 0, 'shop', '', 0),
(79, 1, '2021-03-23 07:38:42', '2021-03-23 07:38:42', '', 'Add Service', '', 'inherit', 'closed', 'closed', '', '71-autosave-v1', '', '', '2021-03-23 07:38:42', '2021-03-23 07:38:42', '', 71, 'http://localhost:8080/upstore/?p=79', 0, 'revision', '', 0),
(80, 1, '2021-03-23 07:39:13', '2021-03-23 07:39:13', '', 'test_service', '', 'publish', 'open', 'open', '', 'test_service-3', '', '', '2021-03-23 07:39:13', '2021-03-23 07:39:13', '', 0, 'http://localhost:8080/upstore/service/test_service-3/', 0, 'service', '', 0),
(81, 1, '2021-03-23 07:46:21', '2021-03-23 07:46:21', 'a:7:{s:8:\"location\";a:2:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:8:\"taxonomy\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:15:\"shop_categories\";}}i:1;a:1:{i:0;a:3:{s:5:\"param\";s:8:\"taxonomy\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:18:\"service_categories\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:3:\"top\";s:21:\"instruction_placement\";s:5:\"label\";s:14:\"hide_on_screen\";s:0:\"\";s:11:\"description\";s:0:\"\";}', 'Category Image', 'category-image', 'publish', 'closed', 'closed', '', 'group_60599ca0b3e2a', '', '', '2021-03-23 07:56:16', '2021-03-23 07:56:16', '', 0, 'http://localhost:8080/upstore/?post_type=acf-field-group&#038;p=81', 0, 'acf-field-group', '', 0),
(82, 1, '2021-03-23 07:46:21', '2021-03-23 07:46:21', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'category_image', 'category_image', 'publish', 'closed', 'closed', '', 'field_60599ca7a807b', '', '', '2021-03-23 07:46:21', '2021-03-23 07:46:21', '', 81, 'http://localhost:8080/upstore/?post_type=acf-field&p=82', 0, 'acf-field', '', 0),
(83, 1, '2021-03-23 07:50:44', '2021-03-23 07:50:44', '', 'fancy', '', 'inherit', 'open', 'closed', '', 'fancy', '', '', '2021-03-23 07:50:44', '2021-03-23 07:50:44', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/03/fancy.jpg', 0, 'attachment', 'image/jpeg', 0),
(84, 1, '2021-03-23 07:57:41', '2021-03-23 07:57:41', '', 'Customer Home', '', 'publish', 'closed', 'closed', '', 'customer-home', '', '', '2021-03-23 07:57:42', '2021-03-23 07:57:42', '', 0, 'http://localhost:8080/upstore/?page_id=84', 0, 'page', '', 0),
(85, 1, '2021-03-23 07:57:41', '2021-03-23 07:57:41', '', 'Customer Home', '', 'inherit', 'closed', 'closed', '', '84-revision-v1', '', '', '2021-03-23 07:57:41', '2021-03-23 07:57:41', '', 84, 'http://localhost:8080/upstore/?p=85', 0, 'revision', '', 0),
(86, 1, '2021-03-24 01:13:11', '2021-03-24 01:13:11', '', 'Custom_Status', '', 'publish', 'closed', 'closed', '', 'status', '', '', '2021-03-24 01:16:34', '2021-03-24 01:16:34', '', 0, 'http://localhost:8080/upstore/?post_type=manage_cpt_tax&#038;p=86', 0, 'manage_cpt_tax', '', 0),
(87, 1, '2021-03-24 01:22:47', '2021-03-24 01:22:47', '', 'Users', '', 'publish', 'closed', 'closed', '', 'users', '', '', '2021-03-24 01:22:48', '2021-03-24 01:22:48', '', 0, 'http://localhost:8080/upstore/?page_id=87', 0, 'page', '', 0),
(88, 1, '2021-03-24 01:22:47', '2021-03-24 01:22:47', '', 'Users', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2021-03-24 01:22:47', '2021-03-24 01:22:47', '', 87, 'http://localhost:8080/upstore/?p=88', 0, 'revision', '', 0),
(90, 1, '2021-03-24 04:27:58', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-03-24 04:27:58', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=90', 1, 'nav_menu_item', '', 0),
(91, 1, '2021-03-25 07:14:04', '2021-03-25 07:14:04', '', 'WhatsApp Image 2021-03-25 at 7.24.56 AM', '', 'inherit', 'open', 'closed', '', 'whatsapp-image-2021-03-25-at-7-24-56-am', '', '', '2021-03-25 07:14:04', '2021-03-25 07:14:04', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/03/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 0, 'attachment', 'image/jpeg', 0),
(92, 1, '2021-03-25 07:14:24', '2021-03-25 07:14:24', 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 'cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-whatsapp-image-2021-03-25-at-7-24-56-am-jpeg', '', '', '2021-03-25 07:14:24', '2021-03-25 07:14:24', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2021-03-25 09:01:06', '2021-03-25 09:01:06', '', 'Add Purchase', '', 'publish', 'closed', 'closed', '', 'add-purchase', '', '', '2021-03-25 09:01:07', '2021-03-25 09:01:07', '', 0, 'http://localhost:8080/upstore/?page_id=94', 0, 'page', '', 0),
(95, 1, '2021-03-25 09:01:06', '2021-03-25 09:01:06', '', 'Add Purchase', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2021-03-25 09:01:06', '2021-03-25 09:01:06', '', 94, 'http://localhost:8080/upstore/?p=95', 0, 'revision', '', 0),
(98, 1, '2021-03-25 09:13:36', '2021-03-25 09:13:36', '', 'ORDR16166636167187213720', '', 'publish', 'closed', 'closed', '', 'ordr16166636167187213720', '', '', '2021-03-25 09:13:36', '2021-03-25 09:13:36', '', 0, 'http://localhost:8080/upstore/?p=98', 0, 'purchase', '', 0),
(103, 1, '2021-03-25 11:57:42', '2021-03-25 11:57:42', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-4', '', '', '2021-03-25 11:57:42', '2021-03-25 11:57:42', '', 0, 'http://localhost:8080/upstore/?p=103', 0, 'shop', '', 0),
(104, 1, '2021-03-25 11:58:05', '2021-03-25 11:58:05', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-5', '', '', '2021-03-25 11:58:05', '2021-03-25 11:58:05', '', 0, 'http://localhost:8080/upstore/?p=104', 0, 'shop', '', 0),
(105, 1, '2021-03-25 12:01:16', '2021-03-25 12:01:16', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-6', '', '', '2021-03-25 12:01:16', '2021-03-25 12:01:16', '', 0, 'http://localhost:8080/upstore/?p=105', 0, 'shop', '', 0),
(107, 1, '2021-03-25 12:02:06', '2021-03-25 12:02:06', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-7', '', '', '2021-03-25 12:02:06', '2021-03-25 12:02:06', '', 0, 'http://localhost:8080/upstore/?p=107', 0, 'shop', '', 0),
(108, 1, '2021-03-25 12:03:11', '2021-03-25 12:03:11', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-8', '', '', '2021-03-25 12:03:11', '2021-03-25 12:03:11', '', 0, 'http://localhost:8080/upstore/?p=108', 0, 'shop', '', 0),
(109, 1, '2021-03-25 12:05:50', '2021-03-25 12:05:50', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-9', '', '', '2021-03-25 12:05:50', '2021-03-25 12:05:50', '', 0, 'http://localhost:8080/upstore/?p=109', 0, 'shop', '', 0),
(110, 1, '2021-03-25 13:35:18', '2021-03-25 13:35:18', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-10', '', '', '2021-03-25 13:35:18', '2021-03-25 13:35:18', '', 0, 'http://localhost:8080/upstore/?p=110', 0, 'shop', '', 0),
(111, 1, '2021-03-25 13:36:10', '2021-03-25 13:36:10', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-11', '', '', '2021-03-25 13:36:10', '2021-03-25 13:36:10', '', 0, 'http://localhost:8080/upstore/?p=111', 0, 'shop', '', 0),
(112, 1, '2021-03-25 13:37:08', '2021-03-25 13:37:08', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-12', '', '', '2021-03-25 13:37:08', '2021-03-25 13:37:08', '', 0, 'http://localhost:8080/upstore/?p=112', 0, 'shop', '', 0),
(113, 1, '2021-03-25 13:37:40', '2021-03-25 13:37:40', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-13', '', '', '2021-03-25 13:37:40', '2021-03-25 13:37:40', '', 0, 'http://localhost:8080/upstore/?p=113', 0, 'shop', '', 0),
(114, 1, '2021-03-25 13:38:47', '2021-03-25 13:38:47', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-14', '', '', '2021-03-25 13:38:47', '2021-03-25 13:38:47', '', 0, 'http://localhost:8080/upstore/?p=114', 0, 'shop', '', 0),
(115, 1, '2021-03-25 13:39:03', '2021-03-25 13:39:03', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-15', '', '', '2021-03-25 13:39:03', '2021-03-25 13:39:03', '', 0, 'http://localhost:8080/upstore/?p=115', 0, 'shop', '', 0),
(116, 1, '2021-03-25 13:40:36', '2021-03-25 13:40:36', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-16', '', '', '2021-03-25 13:40:36', '2021-03-25 13:40:36', '', 0, 'http://localhost:8080/upstore/?p=116', 0, 'shop', '', 0),
(117, 1, '2021-03-25 13:42:51', '2021-03-25 13:42:51', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-17', '', '', '2021-03-25 13:42:51', '2021-03-25 13:42:51', '', 0, 'http://localhost:8080/upstore/?p=117', 0, 'shop', '', 0),
(118, 1, '2021-03-25 13:43:52', '2021-03-25 13:43:52', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-18', '', '', '2021-03-25 13:43:52', '2021-03-25 13:43:52', '', 0, 'http://localhost:8080/upstore/?p=118', 0, 'shop', '', 0),
(119, 1, '2021-03-26 01:37:28', '2021-03-26 01:37:28', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-19', '', '', '2021-03-26 01:37:28', '2021-03-26 01:37:28', '', 0, 'http://localhost:8080/upstore/?p=119', 0, 'shop', '', 0),
(120, 1, '2021-03-26 01:48:07', '2021-03-26 01:48:07', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-20', '', '', '2021-03-26 01:48:07', '2021-03-26 01:48:07', '', 0, 'http://localhost:8080/upstore/?p=120', 0, 'shop', '', 0),
(121, 1, '2021-03-26 01:49:28', '2021-03-26 01:49:28', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-21', '', '', '2021-03-26 01:49:28', '2021-03-26 01:49:28', '', 0, 'http://localhost:8080/upstore/?p=121', 0, 'shop', '', 0),
(122, 1, '2021-03-26 01:49:38', '2021-03-26 01:49:38', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-22', '', '', '2021-03-26 01:49:38', '2021-03-26 01:49:38', '', 0, 'http://localhost:8080/upstore/?p=122', 0, 'shop', '', 0),
(123, 1, '2021-03-26 01:50:43', '2021-03-26 01:50:43', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-23', '', '', '2021-03-26 01:50:43', '2021-03-26 01:50:43', '', 0, 'http://localhost:8080/upstore/?p=123', 0, 'shop', '', 0),
(124, 1, '2021-03-26 01:51:14', '2021-03-26 01:51:14', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-24', '', '', '2021-03-26 01:51:14', '2021-03-26 01:51:14', '', 0, 'http://localhost:8080/upstore/?p=124', 0, 'shop', '', 0),
(125, 1, '2021-03-26 01:53:15', '2021-03-26 01:53:15', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-25', '', '', '2021-03-26 01:53:15', '2021-03-26 01:53:15', '', 0, 'http://localhost:8080/upstore/?p=125', 0, 'shop', '', 0),
(126, 1, '2021-03-26 01:54:10', '2021-03-26 01:54:10', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-26', '', '', '2021-03-26 01:54:10', '2021-03-26 01:54:10', '', 0, 'http://localhost:8080/upstore/?p=126', 0, 'shop', '', 0),
(127, 1, '2021-03-26 01:54:35', '2021-03-26 01:54:35', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-27', '', '', '2021-03-26 01:54:35', '2021-03-26 01:54:35', '', 0, 'http://localhost:8080/upstore/?p=127', 0, 'shop', '', 0),
(128, 1, '2021-03-26 01:59:39', '2021-03-26 01:59:39', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-28', '', '', '2021-03-26 01:59:39', '2021-03-26 01:59:39', '', 0, 'http://localhost:8080/upstore/?p=128', 0, 'shop', '', 0),
(129, 1, '2021-03-26 02:00:10', '2021-03-26 02:00:10', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-29', '', '', '2021-03-26 02:00:10', '2021-03-26 02:00:10', '', 0, 'http://localhost:8080/upstore/?p=129', 0, 'shop', '', 0),
(130, 1, '2021-03-26 02:01:51', '2021-03-26 02:01:51', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-30', '', '', '2021-03-26 02:01:51', '2021-03-26 02:01:51', '', 0, 'http://localhost:8080/upstore/?p=130', 0, 'shop', '', 0),
(131, 1, '2021-03-26 02:02:47', '2021-03-26 02:02:47', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-31', '', '', '2021-03-26 02:02:47', '2021-03-26 02:02:47', '', 0, 'http://localhost:8080/upstore/?p=131', 0, 'shop', '', 0),
(199, 0, '2021-03-26 06:06:22', '0000-00-00 00:00:00', '', 'ORDR16167387822168121957', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:06:22', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=199', 0, 'post', '', 0),
(200, 0, '2021-03-26 06:10:11', '0000-00-00 00:00:00', '', 'ORDR16167390118835735838', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:10:11', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=200', 0, 'post', '', 0),
(201, 0, '2021-03-26 06:19:56', '0000-00-00 00:00:00', '', 'ORDR16167395968145664024', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:19:56', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=201', 0, 'post', '', 0),
(202, 0, '2021-03-26 06:40:19', '0000-00-00 00:00:00', '', 'ORDR16167408196044786244', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:40:19', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=202', 0, 'post', '', 0),
(203, 0, '2021-03-26 06:42:31', '0000-00-00 00:00:00', '', 'ORDR16167409513083674067', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:42:31', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=203', 0, 'post', '', 0),
(204, 0, '2021-03-26 06:44:13', '0000-00-00 00:00:00', '', 'ORDR16167410532861882056', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:44:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=204', 0, 'post', '', 0),
(205, 0, '2021-03-26 06:46:46', '0000-00-00 00:00:00', '', 'ORDR16167412069270716167', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:46:46', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=205', 0, 'post', '', 0),
(206, 0, '2021-03-26 06:46:51', '0000-00-00 00:00:00', '', 'ORDR16167412117819962270', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:46:51', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=206', 0, 'post', '', 0),
(207, 0, '2021-03-26 06:47:33', '0000-00-00 00:00:00', '', 'ORDR16167412534545890679', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 06:47:33', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=207', 0, 'post', '', 0),
(208, 1, '2021-03-26 07:52:14', '2021-03-26 07:52:14', '', 'Manish Supermarket', '', 'publish', 'closed', 'closed', '', 'manish-supermarket', '', '', '2021-03-26 07:52:14', '2021-03-26 07:52:14', '', 0, 'http://localhost:8080/upstore/?p=208', 0, 'shop', '', 0),
(209, 1, '2021-03-26 07:54:17', '2021-03-26 07:54:17', '', 'Manish Supermarket', '', 'publish', 'closed', 'closed', '', 'manish-supermarket-2', '', '', '2021-03-26 07:54:17', '2021-03-26 07:54:17', '', 0, 'http://localhost:8080/upstore/shop/manish-supermarket-2/', 0, 'shop', '', 0),
(210, 1, '2021-03-26 07:56:05', '2021-03-26 07:56:05', '', 'Manish Supermarket', '', 'publish', 'closed', 'closed', '', 'manish-supermarket-3', '', '', '2021-03-26 07:56:05', '2021-03-26 07:56:05', '', 0, 'http://localhost:8080/upstore/shop/manish-supermarket-3/', 0, 'shop', '', 0),
(211, 1, '2021-03-26 07:57:05', '2021-03-26 07:57:05', '', 'Manish Supermarket', '', 'publish', 'closed', 'closed', '', 'manish-supermarket-4', '', '', '2021-03-26 07:57:05', '2021-03-26 07:57:05', '', 0, 'http://localhost:8080/upstore/shop/manish-supermarket-4/', 0, 'shop', '', 0),
(212, 1, '2021-03-26 07:59:10', '2021-03-26 07:59:10', '', 'Manish Supermarket', '', 'publish', 'closed', 'closed', '', 'manish-supermarket-5', '', '', '2021-03-26 07:59:10', '2021-03-26 07:59:10', '', 0, 'http://localhost:8080/upstore/shop/manish-supermarket-5/', 0, 'shop', '', 0),
(213, 0, '2021-03-26 08:00:34', '0000-00-00 00:00:00', '', 'ORDR16167456341279552232', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 08:00:34', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=213', 0, 'post', '', 0),
(215, 0, '2021-03-26 08:10:30', '0000-00-00 00:00:00', '', 'ORDR16167462306809203705', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 08:10:30', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=215', 0, 'post', '', 0),
(216, 0, '2021-03-26 08:37:21', '0000-00-00 00:00:00', '', 'ORDR16167478417192961195', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 08:37:21', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=216', 0, 'post', '', 0),
(218, 0, '2021-03-26 11:15:50', '0000-00-00 00:00:00', '', 'ORDR16167573502582400705', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:15:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=218', 0, 'post', '', 0),
(219, 0, '2021-03-26 11:16:50', '0000-00-00 00:00:00', '', 'ORDR16167574100821200105', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:16:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=219', 0, 'post', '', 0),
(220, 0, '2021-03-26 11:20:39', '0000-00-00 00:00:00', '', 'ORDR16167576396081648592', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:20:39', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=220', 0, 'post', '', 0),
(221, 0, '2021-03-26 11:20:54', '0000-00-00 00:00:00', '', 'ORDR16167576544824160230', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:20:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=221', 0, 'post', '', 0),
(222, 0, '2021-03-26 11:21:24', '0000-00-00 00:00:00', '', 'ORDR16167576843001912813', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:21:24', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=222', 0, 'post', '', 0),
(223, 0, '2021-03-26 11:23:12', '0000-00-00 00:00:00', '', 'ORDR16167577926883435250', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:23:12', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=223', 0, 'post', '', 0),
(224, 0, '2021-03-26 11:23:40', '0000-00-00 00:00:00', '', 'ORDR16167578205193239430', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 11:23:40', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=224', 0, 'post', '', 0),
(226, 0, '2021-03-26 12:08:48', '0000-00-00 00:00:00', '', 'ORDR16167605288686937213', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:08:48', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=226', 0, 'post', '', 0),
(227, 0, '2021-03-26 12:14:20', '0000-00-00 00:00:00', '', 'ORDR16167608605735965065', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:14:20', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=227', 0, 'post', '', 0),
(228, 0, '2021-03-26 12:14:34', '0000-00-00 00:00:00', '', 'ORDR16167608746085651713', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:14:34', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=228', 0, 'post', '', 0),
(229, 0, '2021-03-26 12:15:21', '0000-00-00 00:00:00', '', 'ORDR16167609217702465944', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:15:21', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=229', 0, 'post', '', 0),
(230, 0, '2021-03-26 12:16:05', '0000-00-00 00:00:00', '', 'ORDR16167609652178479545', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:16:05', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=230', 0, 'post', '', 0),
(231, 0, '2021-03-26 12:16:20', '0000-00-00 00:00:00', '', 'ORDR16167609800453039527', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:16:20', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=231', 0, 'post', '', 0),
(232, 0, '2021-03-26 12:16:31', '0000-00-00 00:00:00', '', 'ORDR16167609915189641988', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:16:31', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=232', 0, 'post', '', 0),
(233, 0, '2021-03-26 12:17:00', '0000-00-00 00:00:00', '', 'ORDR16167610201265634611', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:17:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=233', 0, 'post', '', 0),
(234, 0, '2021-03-26 12:17:31', '0000-00-00 00:00:00', '', 'ORDR16167610517766478062', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:17:31', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=234', 0, 'post', '', 0),
(235, 0, '2021-03-26 12:18:43', '0000-00-00 00:00:00', '', 'ORDR16167611237920612007', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:18:43', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=235', 0, 'post', '', 0),
(236, 0, '2021-03-26 12:19:04', '0000-00-00 00:00:00', '', 'ORDR16167611448735605325', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:19:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=236', 0, 'post', '', 0),
(237, 0, '2021-03-26 12:21:14', '0000-00-00 00:00:00', '', 'ORDR16167612749065095904', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:21:14', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=237', 0, 'post', '', 0),
(238, 0, '2021-03-26 12:21:49', '0000-00-00 00:00:00', '', 'ORDR16167613092102325020', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:21:49', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=238', 0, 'post', '', 0),
(239, 0, '2021-03-26 12:23:25', '0000-00-00 00:00:00', '', 'ORDR16167614049490498756', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:23:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=239', 0, 'post', '', 0),
(240, 0, '2021-03-26 12:24:46', '0000-00-00 00:00:00', '', 'ORDR16167614863615890800', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:24:46', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=240', 0, 'post', '', 0),
(241, 0, '2021-03-26 12:26:43', '0000-00-00 00:00:00', '', 'ORDR16167616035800752773', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:26:43', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=241', 0, 'post', '', 0),
(242, 0, '2021-03-26 12:27:30', '0000-00-00 00:00:00', '', 'ORDR16167616504369218396', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:27:30', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=242', 0, 'post', '', 0),
(243, 0, '2021-03-26 12:34:45', '0000-00-00 00:00:00', '', 'ORDR16167620859974452394', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:34:45', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=243', 0, 'post', '', 0),
(244, 0, '2021-03-26 12:35:29', '0000-00-00 00:00:00', '', 'ORDR16167621293340081728', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-26 12:35:29', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=244', 0, 'post', '', 0),
(247, 0, '2021-03-29 05:40:48', '2021-03-29 05:40:48', '', '', '', 'inherit', 'open', 'closed', '', '247', '', '', '2021-03-29 05:40:48', '2021-03-29 05:40:48', '', 0, 'http://localhost:8080/upstore/247/', 0, 'attachment', '', 0),
(251, 1, '2021-03-29 05:48:44', '2021-03-29 05:48:44', '', '', '', 'inherit', 'open', 'closed', '', '251', '', '', '2021-03-29 05:48:44', '2021-03-29 05:48:44', '', 0, 'http://localhost:8080/upstore/251/', 0, 'attachment', '', 0),
(253, 1, '2021-03-29 05:53:21', '2021-03-29 05:53:21', '', 'Cxampphtdocsupstorewp-contentuploads202103WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103whatsapp-image-2021-03-25-at-7-24-56-am-1-jpeg', '', '', '2021-03-29 05:53:21', '2021-03-29 05:53:21', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103whatsapp-image-2021-03-25-at-7-24-56-am-1-jpeg/', 0, 'attachment', 'image/jpeg', 0),
(254, 0, '2021-03-29 06:01:09', '2021-03-29 06:01:09', '', '', '', 'inherit', 'open', 'closed', '', '254', '', '', '2021-03-29 06:01:09', '2021-03-29 06:01:09', '', 0, 'http://localhost:8080/upstore/254/', 0, 'attachment', '', 0),
(255, 1, '2021-03-29 06:06:54', '2021-03-29 06:06:08', ' ', '', '', 'publish', 'closed', 'closed', '', '255', '', '', '2021-03-29 06:06:54', '2021-03-29 06:06:54', '', 0, 'http://localhost:8080/upstore/?p=255', 7, 'nav_menu_item', '', 0),
(256, 1, '2021-03-29 06:06:54', '2021-03-29 06:06:54', ' ', '', '', 'publish', 'closed', 'closed', '', '256', '', '', '2021-03-29 06:06:54', '2021-03-29 06:06:54', '', 0, 'http://localhost:8080/upstore/?p=256', 8, 'nav_menu_item', '', 0),
(257, 1, '2021-03-29 06:18:59', '2021-03-29 06:18:59', '', '', '', 'inherit', 'open', 'closed', '', '257', '', '', '2021-03-29 06:18:59', '2021-03-29 06:18:59', '', 0, 'http://localhost:8080/upstore/257/', 0, 'attachment', '', 0),
(258, 0, '2021-03-29 06:57:27', '2021-03-29 06:57:27', '', '', '', 'inherit', 'open', 'closed', '', '258', '', '', '2021-03-29 06:57:27', '2021-03-29 06:57:27', '', 0, 'http://localhost:8080/upstore/258/', 0, 'attachment', '', 0),
(259, 0, '2021-03-29 07:05:04', '2021-03-29 07:05:04', '', '', '', 'inherit', 'open', 'closed', '', '259', '', '', '2021-03-29 07:05:04', '2021-03-29 07:05:04', '', 0, 'http://localhost:8080/upstore/259/', 0, 'attachment', '', 0),
(260, 0, '2021-03-29 07:09:46', '2021-03-29 07:09:46', '', 'Cxampphtdocsupstorewp-contentuploads202103specials-5.png', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103specials-5-png', '', '', '2021-03-29 07:09:46', '2021-03-29 07:09:46', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103specials-5-png/', 0, 'attachment', 'image/png', 0),
(261, 0, '2021-03-29 12:34:57', '0000-00-00 00:00:00', '', 'ORDR16170212976322826291', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-29 12:34:57', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=261', 0, 'post', '', 0),
(262, 0, '2021-03-29 12:38:13', '0000-00-00 00:00:00', '', 'ORDR16170214930322240961', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-29 12:38:13', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=262', 0, 'post', '', 0),
(263, 0, '2021-03-29 12:46:16', '0000-00-00 00:00:00', '', 'ORDR16170219763566668466', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-29 12:46:16', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=263', 0, 'post', '', 0),
(264, 0, '2021-03-29 13:18:53', '0000-00-00 00:00:00', '', 'ORDR16170239335778529390', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-29 13:18:53', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=264', 0, 'post', '', 0),
(265, 1, '2021-03-30 06:14:18', '2021-03-30 06:14:18', '', 'Cxampphtdocsupstorewp-contentuploads202103download.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103download-jpg', '', '', '2021-03-30 06:14:18', '2021-03-30 06:14:18', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103download-jpg/', 0, 'attachment', 'image/jpeg', 0),
(271, 0, '2021-03-30 07:52:53', '2021-03-30 07:52:53', '', 'Cxampphtdocsupstorewp-contentuploads202103download-6.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103download-6-jpg', '', '', '2021-03-30 07:52:53', '2021-03-30 07:52:53', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103download-6-jpg/', 0, 'attachment', 'image/jpeg', 0),
(272, 0, '2021-03-30 08:01:40', '2021-03-30 08:01:40', '', '', '', 'inherit', 'open', 'closed', '', '272', '', '', '2021-03-30 08:01:40', '2021-03-30 08:01:40', '', 0, 'http://localhost:8080/upstore/272/', 0, 'attachment', '', 0),
(273, 0, '2021-03-30 08:08:18', '2021-03-30 08:08:18', '', '', '', 'inherit', 'open', 'closed', '', '273', '', '', '2021-03-30 08:08:18', '2021-03-30 08:08:18', '', 0, 'http://localhost:8080/upstore/273/', 0, 'attachment', '', 0),
(274, 0, '2021-03-30 08:10:12', '2021-03-30 08:10:12', '', 'Cxampphtdocsupstorewp-contentuploads202103download-7.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103download-7-jpg', '', '', '2021-03-30 08:10:12', '2021-03-30 08:10:12', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103download-7-jpg/', 0, 'attachment', 'image/jpeg', 0),
(275, 0, '2021-03-31 05:55:59', '2021-03-31 05:55:59', '', 'Cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-1.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-1-jpg', '', '', '2021-03-31 05:55:59', '2021-03-31 05:55:59', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(276, 0, '2021-03-31 05:57:55', '2021-03-31 05:57:55', '', 'Cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-2.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-2-jpg', '', '', '2021-03-31 05:57:55', '2021-03-31 05:57:55', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(281, 0, '2021-03-31 06:09:05', '2021-03-31 06:09:05', '', 'Cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-7.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-7-jpg', '', '', '2021-03-31 06:09:05', '2021-03-31 06:09:05', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103istockphoto-1212364562-1024x1024-7-jpg/', 0, 'attachment', 'image/jpeg', 0),
(282, 0, '2021-03-31 06:14:33', '0000-00-00 00:00:00', '', 'ORDR16171712733455461692', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:14:33', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=282', 0, 'post', '', 0),
(283, 0, '2021-03-31 06:31:29', '0000-00-00 00:00:00', '', 'ORDR16171722897146837363', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:31:29', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=283', 0, 'post', '', 0),
(284, 0, '2021-03-31 06:33:39', '0000-00-00 00:00:00', '', 'ORDR16171724196069647958', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:33:39', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=284', 0, 'post', '', 0),
(285, 0, '2021-03-31 06:35:07', '0000-00-00 00:00:00', '', 'ORDR16171725078451609728', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:35:07', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=285', 0, 'post', '', 0),
(286, 0, '2021-03-31 06:37:00', '0000-00-00 00:00:00', '', 'ORDR16171726203543837757', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:37:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=286', 0, 'post', '', 0),
(287, 0, '2021-03-31 06:41:04', '0000-00-00 00:00:00', '', 'ORDR16171728649512227740', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 06:41:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=287', 0, 'post', '', 0),
(334, 1, '2021-03-31 09:50:13', '2021-03-31 09:50:13', '', 'Cxampphtdocsupstorewp-contentuploads202103WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103whatsapp-image-2021-03-25-at-7-24-56-am-36-jpeg', '', '', '2021-03-31 09:50:13', '2021-03-31 09:50:13', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103whatsapp-image-2021-03-25-at-7-24-56-am-36-jpeg/', 0, 'attachment', 'image/jpeg', 0),
(335, 1, '2021-03-31 09:53:00', '2021-03-31 09:53:00', '', 'Cxampphtdocsupstorewp-contentuploads202103WIN_20200622_16_54_20_Pro.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-jpg', '', '', '2021-03-31 09:53:00', '2021-03-31 09:53:00', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-jpg/', 0, 'attachment', 'image/jpeg', 0);
INSERT INTO `us_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(336, 1, '2021-03-31 09:54:52', '2021-03-31 09:54:52', '', 'Cxampphtdocsupstorewp-contentuploads202103WIN_20200622_16_54_20_Pro-1.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-1-jpg', '', '', '2021-03-31 09:54:52', '2021-03-31 09:54:52', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(337, 1, '2021-03-31 09:55:50', '2021-03-31 09:55:50', '', 'Cxampphtdocsupstorewp-contentuploads202103WIN_20200622_16_54_20_Pro-2.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-2-jpg', '', '', '2021-03-31 09:55:50', '2021-03-31 09:55:50', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(338, 1, '2021-03-31 09:56:50', '2021-03-31 09:56:50', '', 'Cxampphtdocsupstorewp-contentuploads202103WIN_20200622_16_54_20_Pro-3.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-3-jpg', '', '', '2021-03-31 09:56:50', '2021-03-31 09:56:50', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202103win_20200622_16_54_20_pro-3-jpg/', 0, 'attachment', 'image/jpeg', 0),
(339, 1, '2021-03-31 10:06:47', '2021-03-31 10:06:47', '', '', '', 'inherit', 'open', 'closed', '', '339', '', '', '2021-03-31 10:06:47', '2021-03-31 10:06:47', '', 0, 'http://192.168.1.2:8080/upstore/339/', 0, 'attachment', '', 0),
(340, 1, '2021-03-31 10:09:13', '2021-03-31 10:09:13', '', '', '', 'inherit', 'open', 'closed', '', '340', '', '', '2021-03-31 10:09:13', '2021-03-31 10:09:13', '', 0, 'http://192.168.1.2:8080/upstore/340/', 0, 'attachment', '', 0),
(341, 1, '2021-03-31 10:10:38', '2021-03-31 10:10:38', '', '', '', 'inherit', 'open', 'closed', '', '341', '', '', '2021-03-31 10:10:38', '2021-03-31 10:10:38', '', 0, 'http://192.168.1.2:8080/upstore/341/', 0, 'attachment', '', 0),
(342, 1, '2021-03-31 10:12:05', '2021-03-31 10:12:05', '', '', '', 'inherit', 'open', 'closed', '', '342', '', '', '2021-03-31 10:12:05', '2021-03-31 10:12:05', '', 0, 'http://192.168.1.2:8080/upstore/342/', 0, 'attachment', '', 0),
(343, 1, '2021-03-31 10:13:36', '2021-03-31 10:13:36', '', '', '', 'inherit', 'open', 'closed', '', '343', '', '', '2021-03-31 10:13:36', '2021-03-31 10:13:36', '', 0, 'http://192.168.1.2:8080/upstore/343/', 0, 'attachment', '', 0),
(344, 0, '2021-03-31 11:41:39', '0000-00-00 00:00:00', '', 'ORDR16171908997573111822', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 11:41:39', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=344', 0, 'post', '', 0),
(345, 0, '2021-03-31 11:44:14', '0000-00-00 00:00:00', '', 'ORDR16171910543786839477', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 11:44:14', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=345', 0, 'post', '', 0),
(346, 0, '2021-03-31 11:50:30', '0000-00-00 00:00:00', '', 'ORDR16171914304977328171', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 11:50:30', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=346', 0, 'post', '', 0),
(347, 0, '2021-03-31 11:51:42', '0000-00-00 00:00:00', '', 'ORDR16171915024887977314', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 11:51:42', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=347', 0, 'post', '', 0),
(348, 0, '2021-03-31 11:55:54', '0000-00-00 00:00:00', '', 'ORDR16171917542026748979', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 11:55:54', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=348', 0, 'post', '', 0),
(349, 0, '2021-03-31 12:00:00', '0000-00-00 00:00:00', '', 'ORDR16171920008667270748', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:00:00', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=349', 0, 'post', '', 0),
(350, 0, '2021-03-31 12:02:32', '0000-00-00 00:00:00', '', 'ORDR16171921522507676225', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:02:32', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=350', 0, 'post', '', 0),
(351, 0, '2021-03-31 12:03:53', '0000-00-00 00:00:00', '', 'ORDR16171922335850884278', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:03:53', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=351', 0, 'post', '', 0),
(352, 0, '2021-03-31 12:04:55', '0000-00-00 00:00:00', '', 'ORDR16171922957315600618', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:04:55', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=352', 0, 'post', '', 0),
(353, 0, '2021-03-31 12:07:52', '0000-00-00 00:00:00', '', 'ORDR16171924728468742409', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:07:52', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=353', 0, 'post', '', 0),
(354, 0, '2021-03-31 12:08:50', '0000-00-00 00:00:00', '', 'ORDR16171925307356123591', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:08:50', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=354', 0, 'post', '', 0),
(355, 0, '2021-03-31 12:09:18', '0000-00-00 00:00:00', '', 'ORDR16171925580121816388', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:09:18', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=355', 0, 'post', '', 0),
(356, 0, '2021-03-31 12:10:16', '0000-00-00 00:00:00', '', 'ORDR16171926169687299405', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:10:16', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=356', 0, 'post', '', 0),
(357, 0, '2021-03-31 12:12:06', '0000-00-00 00:00:00', '', 'ORDR16171927262944424402', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:12:06', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=357', 0, 'post', '', 0),
(358, 0, '2021-03-31 12:13:52', '0000-00-00 00:00:00', '', 'ORDR16171928322065377652', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:13:52', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=358', 0, 'post', '', 0),
(359, 0, '2021-03-31 12:14:51', '0000-00-00 00:00:00', '', 'ORDR16171928913192631334', '', 'draft', 'open', 'open', '', '', '', '', '2021-03-31 12:14:51', '0000-00-00 00:00:00', '', 0, 'http://192.168.1.2:8080/upstore/?p=359', 0, 'post', '', 0),
(360, 1, '2021-04-01 06:51:35', '2021-04-01 06:51:35', '', 'Akkara Textiles', '', 'publish', 'closed', 'closed', '', 'akkara-textiles', '', '', '2021-04-01 06:51:35', '2021-04-01 06:51:35', '', 0, 'http://localhost:8080/upstore/shop/akkara-textiles/', 0, 'shop', '', 0),
(361, 0, '2021-04-01 07:01:09', '2021-04-01 07:01:09', '', 'Cxampphtdocsupstorewp-contentuploads202104wp2365076.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202104wp2365076-jpg', '', '', '2021-04-01 07:01:09', '2021-04-01 07:01:09', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202104wp2365076-jpg/', 0, 'attachment', 'image/jpeg', 0),
(362, 1, '2021-04-01 11:00:21', '2021-04-01 11:00:21', 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg', 'cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-whatsapp-image-2021-03-25-at-7-24-56-am-36-jpeg', '', '', '2021-04-01 11:00:21', '2021-04-01 11:00:21', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-36.jpeg', 0, 'attachment', 'image/jpeg', 0),
(363, 1, '2021-04-01 11:00:23', '2021-04-01 11:00:23', '{\n    \"site_icon\": {\n        \"value\": 362,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-04-01 11:00:23\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '146f4207-7c5f-4258-9970-229b3e9ff38f', '', '', '2021-04-01 11:00:23', '2021-04-01 11:00:23', '', 0, 'http://localhost:8080/upstore/146f4207-7c5f-4258-9970-229b3e9ff38f/', 0, 'customize_changeset', '', 0),
(364, 1, '2021-04-01 11:01:41', '2021-04-01 11:01:41', 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', 'cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-whatsapp-image-2021-03-25-at-7-24-56-am-1-jpeg', '', '', '2021-04-01 11:01:41', '2021-04-01 11:01:41', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/03/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(365, 1, '2021-04-01 11:01:43', '2021-04-01 11:01:43', '{\n    \"site_icon\": {\n        \"value\": 364,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-04-01 11:01:43\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'c315d75c-faef-4765-8737-e1e926183730', '', '', '2021-04-01 11:01:43', '2021-04-01 11:01:43', '', 0, 'http://localhost:8080/upstore/c315d75c-faef-4765-8737-e1e926183730/', 0, 'customize_changeset', '', 0),
(366, 1, '2021-04-01 11:05:52', '2021-04-01 11:05:52', '', 'WhatsApp Image 2021-03-25 at 7.24.56 AM', '', 'inherit', 'open', 'closed', '', 'whatsapp-image-2021-03-25-at-7-24-56-am-2', '', '', '2021-04-01 11:05:52', '2021-04-01 11:05:52', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 0, 'attachment', 'image/jpeg', 0),
(367, 1, '2021-04-01 11:05:58', '2021-04-01 11:05:58', 'http://localhost:8080/upstore/wp-content/uploads/2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 'cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-whatsapp-image-2021-03-25-at-7-24-56-am-jpeg-2', '', '', '2021-04-01 11:05:58', '2021-04-01 11:05:58', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM.jpeg', 0, 'attachment', 'image/jpeg', 0),
(368, 1, '2021-04-01 11:06:00', '2021-04-01 11:06:00', '{\n    \"upstore::custom_logo\": {\n        \"value\": 367,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-04-01 11:06:00\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'bcc9c211-9a7b-470d-b0e1-e254fb221809', '', '', '2021-04-01 11:06:00', '2021-04-01 11:06:00', '', 0, 'http://localhost:8080/upstore/bcc9c211-9a7b-470d-b0e1-e254fb221809/', 0, 'customize_changeset', '', 0),
(369, 1, '2021-04-01 11:06:34', '2021-04-01 11:06:34', '', 'WhatsApp Image 2021-03-25 at 7.24.56 AM', '', 'inherit', 'open', 'closed', '', 'whatsapp-image-2021-03-25-at-7-24-56-am-3', '', '', '2021-04-01 11:06:34', '2021-04-01 11:06:34', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/04/WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(370, 1, '2021-04-01 11:06:58', '2021-04-01 11:06:58', '{\n    \"upstore::custom_logo\": {\n        \"value\": 371,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-04-01 11:06:58\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '3f49c90f-9bba-40de-9b60-58c6954a3d39', '', '', '2021-04-01 11:06:58', '2021-04-01 11:06:58', '', 0, 'http://localhost:8080/upstore/?p=370', 0, 'customize_changeset', '', 0),
(371, 1, '2021-04-01 11:06:55', '2021-04-01 11:06:55', 'http://localhost:8080/upstore/wp-content/uploads/2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', 'cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', '', 'inherit', 'open', 'closed', '', 'cropped-whatsapp-image-2021-03-25-at-7-24-56-am-1-jpeg-2', '', '', '2021-04-01 11:06:55', '2021-04-01 11:06:55', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/04/cropped-WhatsApp-Image-2021-03-25-at-7.24.56-AM-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(372, 1, '2021-04-01 11:35:51', '2021-04-01 11:35:51', '', 'Shop-List', '', 'trash', 'closed', 'closed', '', 'shop-list__trashed', '', '', '2021-04-01 11:52:24', '2021-04-01 11:52:24', '', 0, 'http://localhost:8080/upstore/?page_id=372', 0, 'page', '', 0),
(373, 1, '2021-04-01 11:35:51', '2021-04-01 11:35:51', '', 'Shops', '', 'inherit', 'closed', 'closed', '', '372-revision-v1', '', '', '2021-04-01 11:35:51', '2021-04-01 11:35:51', '', 372, 'http://localhost:8080/upstore/?p=373', 0, 'revision', '', 0),
(375, 1, '2021-04-01 11:41:04', '2021-04-01 11:41:04', '', 'Shop-List', '', 'inherit', 'closed', 'closed', '', '372-revision-v1', '', '', '2021-04-01 11:41:04', '2021-04-01 11:41:04', '', 372, 'http://localhost:8080/upstore/?p=375', 0, 'revision', '', 0),
(376, 1, '2021-04-01 11:44:56', '2021-04-01 11:44:56', '', 'Shops', '', 'publish', 'closed', 'closed', '', 'shops', '', '', '2021-04-01 11:44:57', '2021-04-01 11:44:57', '', 0, 'http://localhost:8080/upstore/?page_id=376', 0, 'page', '', 0),
(377, 1, '2021-04-01 11:44:56', '2021-04-01 11:44:56', '', 'Shops', '', 'inherit', 'closed', 'closed', '', '376-revision-v1', '', '', '2021-04-01 11:44:56', '2021-04-01 11:44:56', '', 376, 'http://localhost:8080/upstore/?p=377', 0, 'revision', '', 0),
(378, 1, '2021-04-01 12:02:19', '2021-04-01 12:02:19', '', 'Kalyan Silks', '', 'publish', 'closed', 'closed', '', 'kalyan-silks', '', '', '2021-04-01 12:02:19', '2021-04-01 12:02:19', '', 0, 'http://localhost:8080/upstore/shop/kalyan-silks/', 0, 'shop', '', 0),
(379, 1, '2021-04-01 12:04:32', '2021-04-01 12:04:32', '', 'Kalyan Silks', '', 'publish', 'closed', 'closed', '', 'kalyan-silks-2', '', '', '2021-04-01 12:04:32', '2021-04-01 12:04:32', '', 0, 'http://localhost:8080/upstore/shop/kalyan-silks-2/', 0, 'shop', '', 0),
(380, 1, '2021-04-01 12:05:05', '2021-04-01 12:05:05', '', 'Kalyan Silks', '', 'publish', 'closed', 'closed', '', 'kalyan-silks-3', '', '', '2021-04-01 12:05:05', '2021-04-01 12:05:05', '', 0, 'http://localhost:8080/upstore/shop/kalyan-silks-3/', 0, 'shop', '', 0),
(381, 1, '2021-04-01 12:41:26', '0000-00-00 00:00:00', '', 'ORDR16172808869074170873', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-01 12:41:26', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=381', 0, 'post', '', 0),
(382, 1, '2021-04-01 12:41:28', '0000-00-00 00:00:00', '', 'ORDR16172808882926658996', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-01 12:41:28', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=382', 0, 'post', '', 0),
(383, 1, '2021-04-01 12:41:41', '0000-00-00 00:00:00', '', 'ORDR16172809014623888910', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-01 12:41:41', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=383', 0, 'post', '', 0),
(384, 126, '2021-04-03 09:50:33', '0000-00-00 00:00:00', '', 'ORDR16174434333685253976', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-03 09:50:33', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=384', 0, 'post', '', 0),
(385, 126, '2021-04-03 09:52:26', '0000-00-00 00:00:00', '', 'ORDR16174435463979199996', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-03 09:52:26', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=385', 0, 'post', '', 0),
(386, 1, '2021-04-03 10:18:11', '0000-00-00 00:00:00', '', 'ORDR16174450912889973786', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-03 10:18:11', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=386', 0, 'post', '', 0),
(387, 1, '2021-04-05 04:58:25', '0000-00-00 00:00:00', '', 'ORDR16175987057965135270', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 04:58:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=387', 0, 'post', '', 0),
(388, 1, '2021-04-05 05:00:23', '0000-00-00 00:00:00', '', 'ORDR16175988239253412970', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:00:23', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=388', 0, 'post', '', 0),
(389, 126, '2021-04-05 05:01:48', '0000-00-00 00:00:00', '', 'ORDR16175989085082835447', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:01:48', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=389', 0, 'post', '', 0),
(390, 126, '2021-04-05 05:08:16', '0000-00-00 00:00:00', '', 'ORDR16175992964812668050', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:08:16', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=390', 0, 'post', '', 0),
(391, 126, '2021-04-05 05:08:22', '0000-00-00 00:00:00', '', 'ORDR16175993021606946356', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:08:22', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=391', 0, 'post', '', 0),
(392, 126, '2021-04-05 05:08:33', '0000-00-00 00:00:00', '', 'ORDR16175993134293470265', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:08:33', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=392', 0, 'post', '', 0),
(393, 126, '2021-04-05 05:08:35', '0000-00-00 00:00:00', '', 'ORDR16175993157291873396', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:08:35', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=393', 0, 'post', '', 0),
(394, 126, '2021-04-05 05:08:44', '0000-00-00 00:00:00', '', 'ORDR16175993243452789039', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:08:44', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=394', 0, 'post', '', 0),
(395, 126, '2021-04-05 05:09:00', '0000-00-00 00:00:00', '', 'ORDR16175993404381426504', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:09:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=395', 0, 'post', '', 0),
(396, 126, '2021-04-05 05:09:08', '0000-00-00 00:00:00', '', 'ORDR16175993481154821194', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:09:08', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=396', 0, 'post', '', 0),
(397, 126, '2021-04-05 05:09:10', '0000-00-00 00:00:00', '', 'ORDR16175993506397325195', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:09:10', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=397', 0, 'post', '', 0),
(398, 126, '2021-04-05 05:17:37', '0000-00-00 00:00:00', '', 'ORDR16175998577740995277', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:17:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=398', 0, 'post', '', 0),
(405, 126, '2021-04-05 05:30:53', '0000-00-00 00:00:00', '', 'ORDR16176006538148130433', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:30:53', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=405', 0, 'post', '', 0),
(406, 126, '2021-04-05 05:46:55', '0000-00-00 00:00:00', '', 'ORDR16176016156944264708', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:46:55', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=406', 0, 'post', '', 0),
(407, 126, '2021-04-05 05:47:38', '0000-00-00 00:00:00', '', 'ORDR16176016585207637413', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:47:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=407', 0, 'post', '', 0),
(408, 126, '2021-04-05 05:48:36', '0000-00-00 00:00:00', '', 'ORDR16176017161476230864', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:48:36', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=408', 0, 'post', '', 0),
(409, 126, '2021-04-05 05:48:57', '0000-00-00 00:00:00', '', 'ORDR16176017379361665429', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:48:57', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=409', 0, 'post', '', 0),
(410, 126, '2021-04-05 05:52:32', '0000-00-00 00:00:00', '', 'ORDR16176019524257694421', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 05:52:32', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=410', 0, 'post', '', 0),
(412, 1, '2021-04-05 06:26:41', '2021-04-05 06:26:41', '', 'test', '', 'publish', 'closed', 'closed', '', 'test-32', '', '', '2021-04-05 06:26:41', '2021-04-05 06:26:41', '', 0, 'http://localhost:8080/upstore/shop/test-32/', 0, 'shop', '', 0),
(413, 126, '2021-04-05 06:36:15', '0000-00-00 00:00:00', '', 'ORDR16176045757938037223', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:15', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=413', 0, 'post', '', 0),
(414, 126, '2021-04-05 06:36:35', '0000-00-00 00:00:00', '', 'ORDR16176045958623833647', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:35', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=414', 0, 'post', '', 0),
(415, 126, '2021-04-05 06:36:36', '0000-00-00 00:00:00', '', 'ORDR16176045962052018396', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:36', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=415', 0, 'post', '', 0),
(416, 126, '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 'ORDR16176045973102327453', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=416', 0, 'post', '', 0),
(417, 126, '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 'ORDR16176045979532045584', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=417', 0, 'post', '', 0),
(418, 126, '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 'ORDR16176045979158187023', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=418', 0, 'post', '', 0),
(419, 126, '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 'ORDR16176045970021991318', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:37', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=419', 0, 'post', '', 0),
(420, 126, '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 'ORDR16176045982115240887', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=420', 0, 'post', '', 0),
(421, 126, '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 'ORDR16176045987613400830', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=421', 0, 'post', '', 0),
(422, 126, '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 'ORDR16176045989904579459', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=422', 0, 'post', '', 0),
(423, 126, '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 'ORDR16176045984215530905', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:38', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=423', 0, 'post', '', 0),
(424, 126, '2021-04-05 06:36:39', '0000-00-00 00:00:00', '', 'ORDR16176045996227122474', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:39', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=424', 0, 'post', '', 0),
(425, 126, '2021-04-05 06:36:41', '0000-00-00 00:00:00', '', 'ORDR16176046010697997275', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:41', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=425', 0, 'post', '', 0),
(426, 126, '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 'ORDR16176046026862639894', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=426', 0, 'post', '', 0),
(427, 126, '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 'ORDR16176046022823613460', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=427', 0, 'post', '', 0),
(428, 126, '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 'ORDR16176046023576631623', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:36:42', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=428', 0, 'post', '', 0),
(429, 126, '2021-04-05 06:37:25', '0000-00-00 00:00:00', '', 'ORDR16176046457193274344', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:37:25', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=429', 0, 'post', '', 0),
(430, 1, '2021-04-05 06:40:57', '2021-04-05 06:40:57', '', 'up store logo', '', 'inherit', 'open', 'closed', '', 'up-store-logo', '', '', '2021-04-05 06:40:57', '2021-04-05 06:40:57', '', 0, 'http://localhost:8080/upstore/wp-content/uploads/2021/04/up-store-logo.png', 0, 'attachment', 'image/png', 0),
(431, 1, '2021-04-05 06:50:41', '2021-04-05 06:50:41', '{\n    \"upstore::custom_logo\": {\n        \"value\": 430,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-04-05 06:50:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '91a9b7b7-5677-4f90-b10f-1d86689587dc', '', '', '2021-04-05 06:50:41', '2021-04-05 06:50:41', '', 0, 'http://localhost:8080/upstore/?p=431', 0, 'customize_changeset', '', 0),
(432, 126, '2021-04-05 06:56:40', '0000-00-00 00:00:00', '', 'ORDR16176058005925332385', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 06:56:40', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=432', 0, 'post', '', 0),
(433, 1, '2021-04-05 08:27:59', '0000-00-00 00:00:00', '', 'ORDR16176112796478451181', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:27:59', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=433', 0, 'post', '', 0),
(434, 1, '2021-04-05 08:30:40', '0000-00-00 00:00:00', '', 'ORDR16176114403649168792', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:30:40', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=434', 0, 'post', '', 0),
(435, 1, '2021-04-05 08:31:54', '0000-00-00 00:00:00', '', 'ORDR16176115141291527438', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:31:54', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=435', 0, 'post', '', 0),
(436, 1, '2021-04-05 08:31:57', '0000-00-00 00:00:00', '', 'ORDR16176115173759990764', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:31:57', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=436', 0, 'post', '', 0),
(437, 1, '2021-04-05 08:31:58', '0000-00-00 00:00:00', '', 'ORDR16176115184681271758', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:31:58', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=437', 0, 'post', '', 0),
(438, 126, '2021-04-05 08:33:51', '0000-00-00 00:00:00', '', 'ORDR16176116315236372877', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:33:51', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=438', 0, 'post', '', 0),
(439, 126, '2021-04-05 08:34:19', '0000-00-00 00:00:00', '', 'ORDR16176116594075678989', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:34:19', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=439', 0, 'post', '', 0),
(440, 121, '2021-04-05 08:35:01', '0000-00-00 00:00:00', '', 'ORDR16176117017802757205', '', 'draft', 'open', 'open', '', '', '', '', '2021-04-05 08:35:01', '0000-00-00 00:00:00', '', 0, 'http://localhost:8080/upstore/?p=440', 0, 'post', '', 0),
(441, 0, '2021-04-06 15:16:34', '2021-04-06 15:16:34', '', 'Cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-jpg', '', '', '2021-04-06 15:16:34', '2021-04-06 15:16:34', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(442, 0, '2021-04-06 15:17:43', '2021-04-06 15:17:43', '', 'Cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-1.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-1-jpg', '', '', '2021-04-06 15:17:43', '2021-04-06 15:17:43', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-1-jpg/', 0, 'attachment', 'image/jpeg', 0),
(443, 0, '2021-04-06 15:19:04', '2021-04-06 15:19:04', '', 'Cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-2.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-2-jpg', '', '', '2021-04-06 15:19:04', '2021-04-06 15:19:04', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-2-jpg/', 0, 'attachment', 'image/jpeg', 0),
(444, 0, '2021-04-06 15:19:59', '2021-04-06 15:19:59', '', 'Cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-3.jpg', '', 'inherit', 'open', 'closed', '', 'cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-3-jpg', '', '', '2021-04-06 15:19:59', '2021-04-06 15:19:59', '', 0, 'http://localhost:8080/upstore/cxampphtdocsupstorewp-contentuploads202104callia-beauty-care-3-2-3-jpg/', 0, 'attachment', 'image/jpeg', 0),
(445, 0, '2021-04-06 15:21:54', '2021-04-06 15:21:54', '', '', '', 'inherit', 'open', 'closed', '', '445', '', '', '2021-04-06 15:21:54', '2021-04-06 15:21:54', '', 0, 'http://localhost:8080/upstore/445/', 0, 'attachment', '', 0),
(446, 0, '2021-04-06 15:23:50', '2021-04-06 15:23:50', '', '', '', 'inherit', 'open', 'closed', '', '446', '', '', '2021-04-06 15:23:50', '2021-04-06 15:23:50', '', 0, 'http://localhost:8080/upstore/446/', 0, 'attachment', '', 0),
(447, 1, '2021-04-06 15:38:58', '2021-04-06 15:38:58', '', '', '', 'inherit', 'open', 'closed', '', '447', '', '', '2021-04-06 15:38:58', '2021-04-06 15:38:58', '', 0, 'http://localhost:8080/upstore/447/', 0, 'attachment', '', 0),
(448, 1, '2021-04-06 15:40:24', '2021-04-06 15:40:24', '', '', '', 'inherit', 'open', 'closed', '', '448', '', '', '2021-04-06 15:40:24', '2021-04-06 15:40:24', '', 0, 'http://localhost:8080/upstore/448/', 0, 'attachment', '', 0),
(449, 1, '2021-04-06 15:42:22', '2021-04-06 15:42:22', '', '', '', 'inherit', 'open', 'closed', '', '449', '', '', '2021-04-06 15:42:22', '2021-04-06 15:42:22', '', 0, 'http://localhost:8080/upstore/449/', 0, 'attachment', '', 0),
(450, 1, '2021-04-06 15:45:05', '2021-04-06 15:45:05', '', '', '', 'inherit', 'open', 'closed', '', '450', '', '', '2021-04-06 15:45:05', '2021-04-06 15:45:05', '', 0, 'http://localhost:8080/upstore/450/', 0, 'attachment', '', 0),
(451, 1, '2021-04-06 15:57:54', '2021-04-06 15:57:54', '', '', '', 'inherit', 'open', 'closed', '', '451', '', '', '2021-04-06 15:57:54', '2021-04-06 15:57:54', '', 0, 'http://localhost:8080/upstore/451/', 0, 'attachment', '', 0),
(452, 1, '2021-04-06 16:06:53', '2021-04-06 16:06:53', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-10', '', '', '2021-04-06 16:06:53', '2021-04-06 16:06:53', '', 0, 'http://localhost:8080/upstore/item/test_item-10/', 0, 'item', '', 0),
(453, 1, '2021-04-06 16:07:09', '2021-04-06 16:07:09', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-11', '', '', '2021-04-06 16:07:09', '2021-04-06 16:07:09', '', 0, 'http://localhost:8080/upstore/item/test_item-11/', 0, 'item', '', 0),
(454, 1, '2021-04-06 16:07:43', '2021-04-06 16:07:43', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-12', '', '', '2021-04-06 16:07:43', '2021-04-06 16:07:43', '', 0, 'http://localhost:8080/upstore/item/test_item-12/', 0, 'item', '', 0),
(455, 1, '2021-04-06 16:09:23', '2021-04-06 16:09:23', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-13', '', '', '2021-04-06 16:09:23', '2021-04-06 16:09:23', '', 0, 'http://localhost:8080/upstore/item/test_item-13/', 0, 'item', '', 0),
(456, 1, '2021-04-06 16:10:08', '2021-04-06 16:10:08', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-14', '', '', '2021-04-06 16:10:08', '2021-04-06 16:10:08', '', 0, 'http://localhost:8080/upstore/item/test_item-14/', 0, 'item', '', 0),
(457, 1, '2021-04-06 16:10:21', '2021-04-06 16:10:21', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-15', '', '', '2021-04-06 16:10:21', '2021-04-06 16:10:21', '', 0, 'http://localhost:8080/upstore/item/test_item-15/', 0, 'item', '', 0),
(458, 1, '2021-04-06 16:12:07', '2021-04-06 16:12:07', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-16', '', '', '2021-04-06 16:12:07', '2021-04-06 16:12:07', '', 0, 'http://localhost:8080/upstore/item/test_item-16/', 0, 'item', '', 0),
(459, 1, '2021-04-06 16:14:18', '2021-04-06 16:14:18', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-17', '', '', '2021-04-06 16:14:18', '2021-04-06 16:14:18', '', 0, 'http://localhost:8080/upstore/item/test_item-17/', 0, 'item', '', 0),
(460, 1, '2021-04-06 16:15:12', '2021-04-06 16:15:12', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-18', '', '', '2021-04-06 16:15:12', '2021-04-06 16:15:12', '', 0, 'http://localhost:8080/upstore/item/test_item-18/', 0, 'item', '', 0),
(461, 1, '2021-04-07 02:43:04', '2021-04-07 02:43:04', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-19', '', '', '2021-04-07 02:43:04', '2021-04-07 02:43:04', '', 0, 'http://localhost:8080/upstore/item/test_item-19/', 0, 'item', '', 0),
(462, 1, '2021-04-07 02:44:33', '2021-04-07 02:44:33', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-20', '', '', '2021-04-07 02:44:33', '2021-04-07 02:44:33', '', 0, 'http://localhost:8080/upstore/item/test_item-20/', 0, 'item', '', 0),
(464, 1, '2021-04-07 02:54:57', '2021-04-07 02:54:57', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-21', '', '', '2021-04-07 02:54:57', '2021-04-07 02:54:57', '', 0, 'http://localhost:8080/upstore/item/test_item-21/', 0, 'item', '', 0),
(465, 1, '2021-04-07 02:56:22', '2021-04-07 02:56:22', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-22', '', '', '2021-04-07 02:56:22', '2021-04-07 02:56:22', '', 0, 'http://localhost:8080/upstore/item/test_item-22/', 0, 'item', '', 0),
(466, 1, '2021-04-07 02:58:45', '2021-04-07 02:58:45', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-23', '', '', '2021-04-07 02:58:45', '2021-04-07 02:58:45', '', 0, 'http://localhost:8080/upstore/item/test_item-23/', 0, 'item', '', 0),
(467, 1, '2021-04-07 02:59:31', '2021-04-07 02:59:31', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-24', '', '', '2021-04-07 02:59:31', '2021-04-07 02:59:31', '', 0, 'http://localhost:8080/upstore/item/test_item-24/', 0, 'item', '', 0),
(468, 1, '2021-04-07 02:59:43', '2021-04-07 02:59:43', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-25', '', '', '2021-04-07 02:59:43', '2021-04-07 02:59:43', '', 0, 'http://localhost:8080/upstore/item/test_item-25/', 0, 'item', '', 0),
(469, 1, '2021-04-07 03:00:37', '2021-04-07 03:00:37', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-26', '', '', '2021-04-07 03:00:37', '2021-04-07 03:00:37', '', 0, 'http://localhost:8080/upstore/item/test_item-26/', 0, 'item', '', 0),
(470, 1, '2021-04-07 03:01:36', '2021-04-07 03:01:36', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-27', '', '', '2021-04-07 03:01:36', '2021-04-07 03:01:36', '', 0, 'http://localhost:8080/upstore/item/test_item-27/', 0, 'item', '', 0),
(471, 1, '2021-04-07 03:02:07', '2021-04-07 03:02:07', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-28', '', '', '2021-04-07 03:02:07', '2021-04-07 03:02:07', '', 0, 'http://localhost:8080/upstore/item/test_item-28/', 0, 'item', '', 0),
(472, 1, '2021-04-07 03:02:25', '2021-04-07 03:02:25', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-29', '', '', '2021-04-07 03:02:25', '2021-04-07 03:02:25', '', 0, 'http://localhost:8080/upstore/item/test_item-29/', 0, 'item', '', 0),
(473, 1, '2021-04-07 03:03:30', '2021-04-07 03:03:30', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-30', '', '', '2021-04-07 03:03:30', '2021-04-07 03:03:30', '', 0, 'http://localhost:8080/upstore/item/test_item-30/', 0, 'item', '', 0),
(474, 1, '2021-04-07 03:03:42', '2021-04-07 03:03:42', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-31', '', '', '2021-04-07 03:03:42', '2021-04-07 03:03:42', '', 0, 'http://localhost:8080/upstore/item/test_item-31/', 0, 'item', '', 0),
(475, 1, '2021-04-07 03:04:48', '2021-04-07 03:04:48', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-32', '', '', '2021-04-07 03:04:48', '2021-04-07 03:04:48', '', 0, 'http://localhost:8080/upstore/item/test_item-32/', 0, 'item', '', 0),
(476, 1, '2021-04-07 03:05:14', '2021-04-07 03:05:14', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-33', '', '', '2021-04-07 03:05:14', '2021-04-07 03:05:14', '', 0, 'http://localhost:8080/upstore/item/test_item-33/', 0, 'item', '', 0),
(477, 1, '2021-04-07 03:05:54', '2021-04-07 03:05:54', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-34', '', '', '2021-04-07 03:05:54', '2021-04-07 03:05:54', '', 0, 'http://localhost:8080/upstore/item/test_item-34/', 0, 'item', '', 0),
(478, 1, '2021-04-07 03:08:52', '2021-04-07 03:08:52', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-35', '', '', '2021-04-07 03:08:52', '2021-04-07 03:08:52', '', 0, 'http://localhost:8080/upstore/item/test_item-35/', 0, 'item', '', 0),
(479, 1, '2021-04-07 03:09:10', '2021-04-07 03:09:10', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-36', '', '', '2021-04-07 03:09:10', '2021-04-07 03:09:10', '', 0, 'http://localhost:8080/upstore/item/test_item-36/', 0, 'item', '', 0),
(480, 1, '2021-04-07 03:09:22', '2021-04-07 03:09:22', '', 'test_item', '', 'publish', 'open', 'open', '', 'test_item-37', '', '', '2021-04-07 03:09:22', '2021-04-07 03:09:22', '', 0, 'http://localhost:8080/upstore/item/test_item-37/', 0, 'item', '', 0),
(483, 1, '2021-04-19 06:18:17', '2021-04-19 06:18:17', '', 'testprin', '', 'publish', 'closed', 'closed', '', 'testprin', '', '', '2021-04-19 06:18:17', '2021-04-19 06:18:17', '', 0, 'http://localhost/upstore/shop/testprin/', 0, 'shop', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_purchase`
--

CREATE TABLE `us_purchase` (
  `id` int(11) NOT NULL,
  `order_no` varchar(50) NOT NULL,
  `shop_id` int(11) NOT NULL,
  `category_amount` text NOT NULL,
  `category_percent` text NOT NULL,
  `discount_amount` varchar(100) NOT NULL,
  `cash_back` varchar(100) NOT NULL,
  `ppv` varchar(100) NOT NULL,
  `pay_amount` varchar(20) NOT NULL,
  `distribution_amount` varchar(100) NOT NULL,
  `company_share` varchar(100) NOT NULL,
  `company_dpv` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_purchase`
--

INSERT INTO `us_purchase` (`id`, `order_no`, `shop_id`, `category_amount`, `category_percent`, `discount_amount`, `cash_back`, `ppv`, `pay_amount`, `distribution_amount`, `company_share`, `company_dpv`, `created_by`, `created_on`, `updated_on`, `status`) VALUES
(389, 'ORDR16175989085082835447', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:31:48', '2021-04-05 10:31:48', ''),
(390, 'ORDR16175992964812668050', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:38:16', '2021-04-05 10:38:16', ''),
(391, 'ORDR16175993021606946356', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:38:22', '2021-04-05 10:38:22', ''),
(392, 'ORDR16175993134293470265', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:38:33', '2021-04-05 10:38:33', ''),
(393, 'ORDR16175993157291873396', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:38:36', '2021-04-05 10:38:36', ''),
(394, 'ORDR16175993243452789039', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:38:44', '2021-04-05 10:38:44', ''),
(395, 'ORDR16175993404381426504', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:39:00', '2021-04-05 10:39:00', ''),
(396, 'ORDR16175993481154821194', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:39:08', '2021-04-05 10:39:08', ''),
(397, 'ORDR16175993506397325195', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '', '', 126, '2021-04-05 10:39:10', '2021-04-05 10:39:10', ''),
(398, 'ORDR16175998577740995277', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '', 126, '2021-04-05 10:47:37', '2021-04-05 10:47:37', ''),
(405, 'ORDR16176006538148130433', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:00:54', '2021-04-05 11:00:54', ''),
(406, 'ORDR16176016156944264708', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:16:55', '2021-04-05 11:16:55', ''),
(407, 'ORDR16176016585207637413', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:17:38', '2021-04-05 11:17:38', ''),
(408, 'ORDR16176017161476230864', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:18:36', '2021-04-05 11:18:36', ''),
(409, 'ORDR16176017379361665429', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:18:57', '2021-04-05 11:18:57', ''),
(410, 'ORDR16176019524257694421', 128, '{\"24\":\"98\",\"pay_amount\":232}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.882', '0.3528', '0.03528', '232', '0.5292', '0.1764', '0.3528', 126, '2021-04-05 11:22:32', '2021-04-05 11:22:32', ''),
(413, 'ORDR16176045757938037223', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:15', '2021-04-05 12:06:15', ''),
(414, 'ORDR16176045958623833647', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:36', '2021-04-05 12:06:36', ''),
(415, 'ORDR16176045962052018396', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:36', '2021-04-05 12:06:36', ''),
(416, 'ORDR16176045973102327453', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:37', '2021-04-05 12:06:37', ''),
(417, 'ORDR16176045979532045584', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:37', '2021-04-05 12:06:37', ''),
(418, 'ORDR16176045979158187023', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:37', '2021-04-05 12:06:37', ''),
(419, 'ORDR16176045970021991318', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:37', '2021-04-05 12:06:37', ''),
(420, 'ORDR16176045982115240887', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:38', '2021-04-05 12:06:38', ''),
(421, 'ORDR16176045987613400830', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:38', '2021-04-05 12:06:38', ''),
(422, 'ORDR16176045989904579459', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:38', '2021-04-05 12:06:38', ''),
(423, 'ORDR16176045984215530905', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:38', '2021-04-05 12:06:38', ''),
(424, 'ORDR16176045996227122474', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:39', '2021-04-05 12:06:39', ''),
(425, 'ORDR16176046010697997275', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:41', '2021-04-05 12:06:41', ''),
(426, 'ORDR16176046026862639894', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:42', '2021-04-05 12:06:42', ''),
(427, 'ORDR16176046022823613460', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:42', '2021-04-05 12:06:42', ''),
(428, 'ORDR16176046023576631623', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:06:42', '2021-04-05 12:06:42', ''),
(429, 'ORDR16176046457193274344', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:07:25', '2021-04-05 12:07:25', ''),
(432, 'ORDR16176058005925332385', 128, '{\"24\":\"100\",\"pay_amount\":100}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '0.9', '0.36', '0.036', '100', '0.54', '0.18', '0.36', 126, '2021-04-05 12:26:40', '2021-04-05 12:26:40', ''),
(433, 'ORDR16176112796478451181', 128, '{\"25\":\"100\",\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '2.5', '1', '0.1', '300', '1.5', '0.5', '1.5', 1, '2021-04-05 13:57:59', '2021-04-05 13:57:59', ''),
(434, 'ORDR16176114403649168792', 128, '{\"25\":\"100\",\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '2.5', '1', '0.1', '300', '1.5', '0.5', '1.5', 1, '2021-04-05 14:00:40', '2021-04-05 14:00:40', ''),
(435, 'ORDR16176115141291527438', 128, '{\"25\":\"100\",\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '2.5', '1', '0.1', '300', '1.5', '0.5', '1.5', 1, '2021-04-05 14:01:54', '2021-04-05 14:01:54', ''),
(436, 'ORDR16176115173759990764', 128, '{\"25\":\"100\",\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '2.5', '1', '0.1', '300', '1.5', '0.5', '1.5', 1, '2021-04-05 14:01:57', '2021-04-05 14:01:57', ''),
(437, 'ORDR16176115184681271758', 128, '{\"25\":\"100\",\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '2.5', '1', '0.1', '300', '1.5', '0.5', '1.5', 1, '2021-04-05 14:01:58', '2021-04-05 14:01:58', ''),
(438, 'ORDR16176116315236372877', 128, '{\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '1.8', '0.72', '0.072', '300', '1.08', '0.36', '0.72', 126, '2021-04-05 14:03:51', '2021-04-05 14:03:51', ''),
(439, 'ORDR16176116594075678989', 128, '{\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '1.8', '0.72', '0.072', '300', '1.08', '0.36', '0.72', 126, '2021-04-05 14:04:19', '2021-04-05 14:04:19', ''),
(440, 'ORDR16176117017802757205', 128, '{\"24\":\"200\",\"pay_amount\":300}', '{\"25\":\"0.7\",\"24\":\"0.9\"}', '1.8', '0.72', '0.072', '300', '1.08', '0.36', '1.08', 121, '2021-04-05 14:05:01', '2021-04-05 14:05:01', '');

-- --------------------------------------------------------

--
-- Table structure for table `us_services`
--

CREATE TABLE `us_services` (
  `service_id` int(11) NOT NULL,
  `service_category_id` int(11) NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `service_email` varchar(50) NOT NULL,
  `service_mobile` varchar(15) NOT NULL,
  `service_alt_mobile` varchar(15) NOT NULL,
  `address` varchar(200) NOT NULL,
  `town_name` varchar(50) NOT NULL,
  `pincode` varchar(15) NOT NULL,
  `district_id` varchar(30) NOT NULL,
  `street_name` varchar(50) NOT NULL,
  `landmark` varchar(150) NOT NULL,
  `status` varchar(15) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(35) NOT NULL,
  `updated_on` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `us_shops`
--

CREATE TABLE `us_shops` (
  `shop_id` int(11) NOT NULL,
  `shop_code` varchar(100) NOT NULL,
  `shop_name` varchar(30) NOT NULL,
  `shop_mobile` varchar(15) NOT NULL,
  `shop_alt_mobile` varchar(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `town_name` varchar(100) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `district_id` varchar(30) NOT NULL,
  `street_name` varchar(50) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `status` varchar(10) DEFAULT NULL,
  `shop_offer` varchar(600) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(30) NOT NULL,
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_shops`
--

INSERT INTO `us_shops` (`shop_id`, `shop_code`, `shop_name`, `shop_mobile`, `shop_alt_mobile`, `address`, `town_name`, `pincode`, `district_id`, `street_name`, `landmark`, `status`, `shop_offer`, `owner_id`, `created_on`, `created_by`, `updated_on`) VALUES
(103, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, '', 0, '2021-03-25 17:27:42', '1', '2021-03-25 17:27:42'),
(104, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, '', 0, '2021-03-25 17:28:05', '1', '2021-03-25 17:28:05'),
(105, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, '', 0, '2021-03-25 17:31:16', '1', '2021-03-25 17:31:16'),
(107, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, '', 0, '2021-03-25 17:32:06', '1', '2021-03-25 17:32:06'),
(108, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, 'a:2:{s:12:\"\\\'category\\\'\";a:3:{i:0;s:2:\"25\";i:1;s:2:\"25\";i:2;s:2:\"24\";}s:14:\"\\\'percentage\\\'\";a:3:{i:0;s:4:\"10.4\";i:1;s:3:\"0.3\";i:2;s:4:\"1.90\";}}', 0, '2021-03-25 17:33:11', '1', '2021-03-25 17:33:11'),
(109, '', 'test', 'test', 'test', 'asd', 'asd', '680712', '12', 'test', 'test', NULL, '{\"\\\\\'category\\\\\'\":{\"0\":\"25\",\"1\":\"25\",\"2\":\"24\"},\"\\\\\'percentage\\\\\'\":{\"0\":\"10.4\",\"1\":\"0.3\",\"2\":\"1.90\"}}', 0, '2021-03-25 17:35:50', '1', '2021-03-25 17:35:50'),
(110, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:05:19', '1', '2021-03-25 19:05:19'),
(111, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:06:10', '1', '2021-03-25 19:06:10'),
(112, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:07:09', '1', '2021-03-25 19:07:09'),
(113, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:07:40', '1', '2021-03-25 19:07:40'),
(114, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:08:47', '1', '2021-03-25 19:08:47'),
(115, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:09:03', '1', '2021-03-25 19:09:03'),
(116, '', 'test', 'test', 'test@gmail.com', 'location', 'location', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:10:37', '1', '2021-03-25 19:10:37'),
(117, '', 'test', 'test', 'test', 'location', 'asdasd', '680712', '12', 'test', 'test', NULL, '{}', 0, '2021-03-25 19:12:51', '1', '2021-03-25 19:12:51'),
(118, '', 'test', 'test', 'test', 'location', 'asdasd', '680712', '12', 'test', 'test', NULL, '{\"25\":\"0.1\"}', 0, '2021-03-25 19:13:52', '1', '2021-03-25 19:13:52'),
(119, '', 'test', 'test', 'test', 'Address Location Thrissur', 'Irinjalalakuda', '680712', '12', 'test', 'test', NULL, '{\"25\":\"0.6\",\"24\":\"7.8\"}', 0, '2021-03-26 07:07:28', '1', '2021-03-26 07:07:28'),
(120, '', 'test', 'test', 'test', 'location', 'thrissu', '1234', '15', 'test123', 'test123', NULL, '{\"Select Category\":\"0.6\",\"25\":\"12.5\"}', 0, '2021-03-26 07:18:07', '1', '2021-03-26 07:18:07'),
(121, '', 'test', 'test', 'test', 'location', 'thrissu', '1234', '15', 'test123', 'test123', NULL, '{\"Select Category\":\"0.6\",\"25\":\"12.5\"}', 0, '2021-03-26 07:19:28', '1', '2021-03-26 07:19:28'),
(122, '', 'test', 'test', 'test', 'location', 'thrissu', '1234', '15', 'test123', 'test123', NULL, '{\"25\":\"12.5\"}', 0, '2021-03-26 07:19:38', '1', '2021-03-26 07:19:38'),
(123, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"25\":\"0.7\",\"24\":\"0.9\"}', 0, '2021-03-26 07:20:43', '1', '2021-03-26 07:20:43'),
(124, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"25\":\"0.7\",\"24\":\"0.9\"}', 0, '2021-03-26 07:21:14', '1', '2021-03-26 07:21:14'),
(125, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"25\":\"0.7\",\"24\":\"0.9\"}', 0, '2021-03-26 07:23:15', '1', '2021-03-26 07:23:15'),
(126, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"0\":null,\"1\":null,\"2\":null}', 0, '2021-03-26 07:24:10', '1', '2021-03-26 07:24:10'),
(127, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"25\":\"0.7\",\"24\":\"0.9\"}', 0, '2021-03-26 07:24:36', '1', '2021-03-26 07:24:36'),
(128, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"25\":\"0.7\",\"24\":\"0.9\"}', 0, '2021-03-26 07:29:39', '1', '2021-03-26 07:29:39'),
(129, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"24\":\"0.9\",\"25\":\"0.7\"}', 0, '2021-03-26 07:30:10', '1', '2021-03-26 07:30:10'),
(130, '', 'test', 'test', 'test', 'asdas', 'location', '680712', '12', 'Thrissur', 'Thrissur', NULL, '{\"24\":\"0.9\",\"25\":\"0.7\"}', 0, '2021-03-26 07:31:51', '1', '2021-03-26 07:31:51'),
(131, '', 'test', 'test', 'test', 'address', 'address', '680712', '12', 'test', 'test', NULL, '{\"37\":\"0.6\",\"25\":\"0.1\",\"24\":\"0.1\"}', 0, '2021-03-26 07:32:47', '1', '2021-03-26 07:32:47'),
(208, '', 'Manish Supermarket', '9947374784', '8147374784', 'puthan pisharam', 'Mapranam', '680712', '12', 'kallada road', 'Near Temple', NULL, '{\"25\":\"5\",\"24\":\"10\",\"37\":\"20\"}', 0, '2021-03-26 13:22:15', '1', '2021-03-26 13:22:15'),
(209, '', 'Manish Supermarket', '9947374784', '8147374784', 'puthan pisharam', 'Mapranam', '680712', '12', 'kallada road', 'Near Temple', NULL, '{\"25\":\"5\",\"24\":\"10\",\"37\":\"20\"}', 0, '2021-03-26 13:24:17', '1', '2021-03-26 13:24:17'),
(210, '', 'Manish Supermarket', '9947374784', '8147374784', 'puthan pisharam', 'Mapranam', '680712', '12', 'kallada road', 'Near Temple', NULL, '{\"25\":\"5\",\"24\":\"10\",\"37\":\"20\"}', 0, '2021-03-26 13:26:05', '1', '2021-03-26 13:26:05'),
(211, '', 'Manish Supermarket', '9947374784', '8147374784', 'puthan pisharam', 'Mapranam', '680712', '12', 'kallada road', 'Near Temple', NULL, '{\"25\":\"5\",\"24\":\"10\",\"37\":\"20\"}', 0, '2021-03-26 13:27:05', '1', '2021-03-26 13:27:05'),
(212, '', 'Manish Supermarket', '9947374784', '8147374784', 'puthan pisharam', 'Mapranam', '680712', '12', 'kallada road', 'Near Temple', NULL, '{\"25\":\"5\",\"24\":\"10\",\"37\":\"20\"}', 0, '2021-03-26 13:29:10', '1', '2021-03-26 13:29:10'),
(360, '', 'Akkara Textiles', '9947374784', '8147374784', 'THRISSUR', 'THRISSUR', '680712', '12', 'LOCATION', 'LOCATION', NULL, '{\"25\":\"20\"}', 0, '2021-04-01 12:21:35', '1', '2021-04-01 12:21:35'),
(378, '', 'Kalyan Silks', 'location', 'thrissur', 'thrissur', 'Thrissur', '680712', '12', 'Thrissur', '680712', NULL, '{\"24\":\"10\"}', 0, '2021-04-01 17:32:19', '1', '2021-04-01 17:32:19'),
(379, '', 'Kalyan Silks', 'location', 'thrissur', 'thrissur', 'Thrissur', '680712', '12', 'Thrissur', '680712', NULL, '{\"24\":\"10\"}', 0, '2021-04-01 17:34:32', '1', '2021-04-01 17:34:32'),
(380, '', 'Kalyan Silks', 'location', 'thrissur', 'thrissur', 'Thrissur', '680712', '12', 'Thrissur', '680712', NULL, '{\"24\":\"10\"}', 0, '2021-04-01 17:35:06', '1', '2021-04-01 17:35:06'),
(412, 'SHOPP4NL6DPCLA', 'test', 'test', 'test', 'location', 'thrissur', '680712', '12', 'test', 'test', NULL, '{\"25\":\"\",\"24\":\"\"}', 0, '2021-04-05 11:56:41', '1', '2021-04-05 11:56:41'),
(483, 'SHOPM6JK32I9L8', 'testprin', 'test', 'test', 'wewewew', 'ewewerwe', '680712', '12', 'test', 'test', NULL, '{\"25\":\"5\",\"37\":\"3\"}', 0, '2021-04-19 11:48:17', '1', '2021-04-19 11:48:17');

-- --------------------------------------------------------

--
-- Table structure for table `us_states`
--

CREATE TABLE `us_states` (
  `id` int(8) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `us_states`
--

INSERT INTO `us_states` (`id`, `name`) VALUES
(1, 'Andaman and Nicobar (AN)'),
(2, 'Andhra Pradesh (AP)'),
(3, 'Arunachal Pradesh (AR)'),
(4, 'Assam (AS)'),
(5, 'Bihar (BR)'),
(6, 'Chandigarh (CH)'),
(7, 'Chhattisgarh (CG)'),
(8, 'Dadra and Nagar Haveli (DN)'),
(9, 'Daman and Diu (DD)'),
(10, 'Delhi (DL)'),
(11, 'Goa (GA)'),
(12, 'Gujarat (GJ)'),
(13, 'Haryana (HR)'),
(14, 'Himachal Pradesh (HP)'),
(15, 'Jammu and Kashmir (JK)'),
(16, 'Jharkhand (JH)'),
(17, 'Karnataka (KA)'),
(18, 'Kerala (KL)'),
(19, 'Lakshdweep (LD)'),
(20, 'Madhya Pradesh (MP)'),
(21, 'Maharashtra (MH)'),
(22, 'Manipur (MN)'),
(23, 'Meghalaya (ML)'),
(24, 'Mizoram (MZ)'),
(25, 'Nagaland (NL)'),
(26, 'Odisha (OD)'),
(27, 'Puducherry (PY)'),
(28, 'Punjab (PB)'),
(29, 'Rajasthan (RJ)'),
(30, 'Sikkim (SK)'),
(31, 'Tamil Nadu (TN)'),
(32, 'Tripura (TR)'),
(33, 'Uttar Pradesh (UP)'),
(34, 'Uttarakhand (UK)'),
(35, 'West Bengal (WB)');

-- --------------------------------------------------------

--
-- Table structure for table `us_termmeta`
--

CREATE TABLE `us_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_termmeta`
--

INSERT INTO `us_termmeta` (`meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 25, 'category_image', '83'),
(2, 25, '_category_image', 'field_60599ca7a807b'),
(3, 37, 'category_image', ''),
(4, 37, '_category_image', 'field_60599ca7a807b');

-- --------------------------------------------------------

--
-- Table structure for table `us_terms`
--

CREATE TABLE `us_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_terms`
--

INSERT INTO `us_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Top Menu', 'top-menu', 0),
(11, 'Kerala', 'kerala', 0),
(12, 'Thrissur', 'thrissur', 0),
(13, 'Palakkad', 'palakkad', 0),
(14, 'Thriuvananthapuram', 'thriuvananthapuram', 0),
(15, 'Malappuram', 'malappuram', 0),
(16, 'Kozhikode', 'calicut', 0),
(17, 'Item Categories', 'item-categories', 0),
(18, 'Grocerry', 'grocerry', 0),
(19, 'Kids', 'kids', 0),
(20, 'Electricals', 'electricals', 0),
(21, 'Electrononics', 'electrononics', 0),
(23, 'Shop Categories', 'shop-categories', 0),
(24, 'Grocery', 'grocery', 0),
(25, 'Fancy', 'fancy', 0),
(26, 'Service Categories', 'service-categories', 0),
(27, 'Doctor', 'doctor', 0),
(28, 'Electrician', 'electrician', 0),
(29, 'Service Categories', 'service-categories', 0),
(30, 'Doctor', 'doctor', 0),
(31, 'Electrician', 'electrician', 0),
(32, 'active', 'active', 0),
(33, 'inactive', 'inactive', 0),
(34, 'Ernakulam', 'ernakulam', 0),
(36, 'Pathanamthitta', 'pathanamthitta', 0),
(37, 'Kids', 'kids', 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_term_relationships`
--

CREATE TABLE `us_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_term_relationships`
--

INSERT INTO `us_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(10, 2, 0),
(20, 2, 0),
(25, 2, 0),
(38, 2, 0),
(57, 2, 0),
(73, 2, 0),
(77, 16, 0),
(77, 25, 0),
(103, 12, 0),
(104, 12, 0),
(105, 12, 0),
(107, 12, 0),
(108, 12, 0),
(109, 12, 0),
(110, 12, 0),
(111, 12, 0),
(112, 12, 0),
(113, 12, 0),
(114, 12, 0),
(115, 12, 0),
(116, 12, 0),
(117, 12, 0),
(118, 12, 0),
(119, 12, 0),
(120, 15, 0),
(121, 15, 0),
(122, 15, 0),
(123, 12, 0),
(124, 12, 0),
(125, 12, 0),
(126, 12, 0),
(127, 12, 0),
(128, 12, 0),
(129, 12, 0),
(130, 12, 0),
(131, 12, 0),
(199, 1, 0),
(200, 1, 0),
(201, 1, 0),
(202, 1, 0),
(203, 1, 0),
(204, 1, 0),
(205, 1, 0),
(206, 1, 0),
(207, 1, 0),
(208, 12, 0),
(209, 12, 0),
(210, 12, 0),
(211, 12, 0),
(212, 12, 0),
(213, 1, 0),
(215, 1, 0),
(216, 1, 0),
(218, 1, 0),
(219, 1, 0),
(220, 1, 0),
(221, 1, 0),
(222, 1, 0),
(223, 1, 0),
(224, 1, 0),
(226, 1, 0),
(227, 1, 0),
(228, 1, 0),
(229, 1, 0),
(230, 1, 0),
(231, 1, 0),
(232, 1, 0),
(233, 1, 0),
(234, 1, 0),
(235, 1, 0),
(236, 1, 0),
(237, 1, 0),
(238, 1, 0),
(239, 1, 0),
(240, 1, 0),
(241, 1, 0),
(242, 1, 0),
(243, 1, 0),
(244, 1, 0),
(255, 2, 0),
(256, 2, 0),
(261, 1, 0),
(262, 1, 0),
(263, 1, 0),
(264, 1, 0),
(282, 1, 0),
(283, 1, 0),
(284, 1, 0),
(285, 1, 0),
(286, 1, 0),
(287, 1, 0),
(344, 1, 0),
(345, 1, 0),
(346, 1, 0),
(347, 1, 0),
(348, 1, 0),
(349, 1, 0),
(350, 1, 0),
(351, 1, 0),
(352, 1, 0),
(353, 1, 0),
(354, 1, 0),
(355, 1, 0),
(356, 1, 0),
(357, 1, 0),
(358, 1, 0),
(359, 1, 0),
(360, 12, 0),
(378, 12, 0),
(379, 12, 0),
(380, 12, 0),
(381, 1, 0),
(382, 1, 0),
(383, 1, 0),
(384, 1, 0),
(385, 1, 0),
(386, 1, 0),
(387, 1, 0),
(388, 1, 0),
(389, 1, 0),
(390, 1, 0),
(391, 1, 0),
(392, 1, 0),
(393, 1, 0),
(394, 1, 0),
(395, 1, 0),
(396, 1, 0),
(397, 1, 0),
(398, 1, 0),
(405, 1, 0),
(406, 1, 0),
(407, 1, 0),
(408, 1, 0),
(409, 1, 0),
(410, 1, 0),
(412, 12, 0),
(413, 1, 0),
(414, 1, 0),
(415, 1, 0),
(416, 1, 0),
(417, 1, 0),
(418, 1, 0),
(419, 1, 0),
(420, 1, 0),
(421, 1, 0),
(422, 1, 0),
(423, 1, 0),
(424, 1, 0),
(425, 1, 0),
(426, 1, 0),
(427, 1, 0),
(428, 1, 0),
(429, 1, 0),
(432, 1, 0),
(433, 1, 0),
(434, 1, 0),
(435, 1, 0),
(436, 1, 0),
(437, 1, 0),
(438, 1, 0),
(439, 1, 0),
(440, 1, 0),
(483, 12, 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_term_taxonomy`
--

CREATE TABLE `us_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_term_taxonomy`
--

INSERT INTO `us_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 8),
(11, 11, 'districts', '', 0, 0),
(12, 12, 'districts', '', 11, 36),
(13, 13, 'districts', '', 11, 0),
(14, 14, 'districts', '', 11, 0),
(15, 15, 'districts', '', 11, 3),
(16, 16, 'districts', '', 11, 1),
(17, 17, 'item_categories', '', 0, 0),
(18, 18, 'item_categories', '', 17, 0),
(19, 19, 'item_categories', '', 17, 0),
(20, 20, 'item_categories', '', 17, 0),
(21, 21, 'item_categories', '', 17, 0),
(23, 23, 'shop_categories', '', 0, 0),
(24, 24, 'shop_categories', '', 23, 0),
(25, 25, 'shop_categories', '', 23, 1),
(26, 26, 'service-category', '', 0, 0),
(27, 27, 'service-category', '', 26, 0),
(28, 28, 'service-category', '', 26, 0),
(29, 29, 'service_categories', '', 0, 0),
(30, 30, 'service_categories', '', 29, 0),
(31, 31, 'service_categories', '', 29, 0),
(32, 32, 'custom_status', '', 0, 0),
(33, 33, 'custom_status', '', 0, 0),
(34, 34, 'districts', '', 11, 0),
(36, 36, 'districts', '', 11, 0),
(37, 37, 'shop_categories', '', 23, 0);

-- --------------------------------------------------------

--
-- Table structure for table `us_usermeta`
--

CREATE TABLE `us_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_usermeta`
--

INSERT INTO `us_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'us_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'us_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:2:{s:64:\"3e01a5400e4fef3a1d260af4532a9c3f52cdef6a2be23d8457aacdf822465c40\";a:4:{s:10:\"expiration\";i:1620017046;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36\";s:5:\"login\";i:1619844246;}s:64:\"934c8485c5bddad02d64efac2d589ab0eb18ab518c38d3ea9a3ff637c59f1aee\";a:4:{s:10:\"expiration\";i:1620017046;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36\";s:5:\"login\";i:1619844246;}}'),
(17, 1, 'us_dashboard_quick_press_last_post_id', '481'),
(18, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:33:\"add-post-type-manage_cpt_template\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}'),
(20, 1, 'nav_menu_recently_edited', '2'),
(21, 1, 'closedpostboxes_manage_cpt_tax', 'a:0:{}'),
(22, 1, 'metaboxhidden_manage_cpt_tax', 'a:1:{i:0;s:7:\"slugdiv\";}'),
(67, 1, 'us_user-settings', 'libraryContent=browse'),
(68, 1, 'us_user-settings-time', '1616483922'),
(463, 1, 'community-events-location', 'a:1:{s:2:\"ip\";s:11:\"192.168.1.0\";}'),
(1100, 78, 'nickname', 'company'),
(1101, 78, 'first_name', 'Company'),
(1102, 78, 'last_name', ''),
(1103, 78, 'description', ''),
(1104, 78, 'rich_editing', 'true'),
(1105, 78, 'syntax_highlighting', 'true'),
(1106, 78, 'comment_shortcuts', 'false'),
(1107, 78, 'admin_color', 'fresh'),
(1108, 78, 'use_ssl', '0'),
(1109, 78, 'show_admin_bar_front', 'true'),
(1110, 78, 'locale', ''),
(1111, 78, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1112, 78, 'us_user_level', '0'),
(1113, 78, 'dismissed_wp_pointers', ''),
(1632, 116, 'nickname', 'manish'),
(1633, 116, 'first_name', ''),
(1634, 116, 'last_name', ''),
(1635, 116, 'description', ''),
(1636, 116, 'rich_editing', 'true'),
(1637, 116, 'syntax_highlighting', 'true'),
(1638, 116, 'comment_shortcuts', 'false'),
(1639, 116, 'admin_color', 'fresh'),
(1640, 116, 'use_ssl', '0'),
(1641, 116, 'show_admin_bar_front', 'true'),
(1642, 116, 'locale', ''),
(1643, 116, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1644, 116, 'us_user_level', '0'),
(1645, 116, 'dismissed_wp_pointers', ''),
(1646, 117, 'nickname', 'arun'),
(1647, 117, 'first_name', ''),
(1648, 117, 'last_name', ''),
(1649, 117, 'description', ''),
(1650, 117, 'rich_editing', 'true'),
(1651, 117, 'syntax_highlighting', 'true'),
(1652, 117, 'comment_shortcuts', 'false'),
(1653, 117, 'admin_color', 'fresh'),
(1654, 117, 'use_ssl', '0'),
(1655, 117, 'show_admin_bar_front', 'true'),
(1656, 117, 'locale', ''),
(1657, 117, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1658, 117, 'us_user_level', '0'),
(1659, 117, 'dismissed_wp_pointers', ''),
(1660, 118, 'nickname', 'sruthy'),
(1661, 118, 'first_name', ''),
(1662, 118, 'last_name', ''),
(1663, 118, 'description', ''),
(1664, 118, 'rich_editing', 'true'),
(1665, 118, 'syntax_highlighting', 'true'),
(1666, 118, 'comment_shortcuts', 'false'),
(1667, 118, 'admin_color', 'fresh'),
(1668, 118, 'use_ssl', '0'),
(1669, 118, 'show_admin_bar_front', 'true'),
(1670, 118, 'locale', ''),
(1671, 118, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1672, 118, 'us_user_level', '0'),
(1673, 118, 'dismissed_wp_pointers', ''),
(1674, 119, 'nickname', 'aiswarya'),
(1675, 119, 'first_name', ''),
(1676, 119, 'last_name', ''),
(1677, 119, 'description', ''),
(1678, 119, 'rich_editing', 'true'),
(1679, 119, 'syntax_highlighting', 'true'),
(1680, 119, 'comment_shortcuts', 'false'),
(1681, 119, 'admin_color', 'fresh'),
(1682, 119, 'use_ssl', '0'),
(1683, 119, 'show_admin_bar_front', 'true'),
(1684, 119, 'locale', ''),
(1685, 119, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1686, 119, 'us_user_level', '0'),
(1687, 119, 'dismissed_wp_pointers', ''),
(1688, 120, 'nickname', 'praseeta'),
(1689, 120, 'first_name', ''),
(1690, 120, 'last_name', ''),
(1691, 120, 'description', ''),
(1692, 120, 'rich_editing', 'true'),
(1693, 120, 'syntax_highlighting', 'true'),
(1694, 120, 'comment_shortcuts', 'false'),
(1695, 120, 'admin_color', 'fresh'),
(1696, 120, 'use_ssl', '0'),
(1697, 120, 'show_admin_bar_front', 'true'),
(1698, 120, 'locale', ''),
(1699, 120, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1700, 120, 'us_user_level', '0'),
(1701, 120, 'dismissed_wp_pointers', ''),
(1702, 121, 'nickname', 'manish'),
(1703, 121, 'first_name', ''),
(1704, 121, 'last_name', ''),
(1705, 121, 'description', ''),
(1706, 121, 'rich_editing', 'true'),
(1707, 121, 'syntax_highlighting', 'true'),
(1708, 121, 'comment_shortcuts', 'false'),
(1709, 121, 'admin_color', 'fresh'),
(1710, 121, 'use_ssl', '0'),
(1711, 121, 'show_admin_bar_front', 'true'),
(1712, 121, 'locale', ''),
(1713, 121, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1714, 121, 'us_user_level', '0'),
(1715, 121, 'dismissed_wp_pointers', ''),
(1716, 122, 'nickname', 'arun'),
(1717, 122, 'first_name', ''),
(1718, 122, 'last_name', ''),
(1719, 122, 'description', ''),
(1720, 122, 'rich_editing', 'true'),
(1721, 122, 'syntax_highlighting', 'true'),
(1722, 122, 'comment_shortcuts', 'false'),
(1723, 122, 'admin_color', 'fresh'),
(1724, 122, 'use_ssl', '0'),
(1725, 122, 'show_admin_bar_front', 'true'),
(1726, 122, 'locale', ''),
(1727, 122, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1728, 122, 'us_user_level', '0'),
(1729, 122, 'dismissed_wp_pointers', ''),
(1730, 123, 'nickname', 'sruthy'),
(1731, 123, 'first_name', ''),
(1732, 123, 'last_name', ''),
(1733, 123, 'description', ''),
(1734, 123, 'rich_editing', 'true'),
(1735, 123, 'syntax_highlighting', 'true'),
(1736, 123, 'comment_shortcuts', 'false'),
(1737, 123, 'admin_color', 'fresh'),
(1738, 123, 'use_ssl', '0'),
(1739, 123, 'show_admin_bar_front', 'true'),
(1740, 123, 'locale', ''),
(1741, 123, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1742, 123, 'us_user_level', '0'),
(1743, 123, 'dismissed_wp_pointers', ''),
(1744, 124, 'nickname', 'aiswarya'),
(1745, 124, 'first_name', ''),
(1746, 124, 'last_name', ''),
(1747, 124, 'description', ''),
(1748, 124, 'rich_editing', 'true'),
(1749, 124, 'syntax_highlighting', 'true'),
(1750, 124, 'comment_shortcuts', 'false'),
(1751, 124, 'admin_color', 'fresh'),
(1752, 124, 'use_ssl', '0'),
(1753, 124, 'show_admin_bar_front', 'true'),
(1754, 124, 'locale', ''),
(1755, 124, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1756, 124, 'us_user_level', '0'),
(1757, 124, 'dismissed_wp_pointers', ''),
(1758, 125, 'nickname', 'praseetha'),
(1759, 125, 'first_name', ''),
(1760, 125, 'last_name', ''),
(1761, 125, 'description', ''),
(1762, 125, 'rich_editing', 'true'),
(1763, 125, 'syntax_highlighting', 'true'),
(1764, 125, 'comment_shortcuts', 'false'),
(1765, 125, 'admin_color', 'fresh'),
(1766, 125, 'use_ssl', '0'),
(1767, 125, 'show_admin_bar_front', 'true'),
(1768, 125, 'locale', ''),
(1769, 125, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1770, 125, 'us_user_level', '0'),
(1771, 125, 'dismissed_wp_pointers', ''),
(1772, 126, 'nickname', 'arun123'),
(1773, 126, 'first_name', ''),
(1774, 126, 'last_name', ''),
(1775, 126, 'description', ''),
(1776, 126, 'rich_editing', 'true'),
(1777, 126, 'syntax_highlighting', 'true'),
(1778, 126, 'comment_shortcuts', 'false'),
(1779, 126, 'admin_color', 'fresh'),
(1780, 126, 'use_ssl', '0'),
(1781, 126, 'show_admin_bar_front', 'true'),
(1782, 126, 'locale', ''),
(1783, 126, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1784, 126, 'us_user_level', '0'),
(1785, 126, 'dismissed_wp_pointers', '');
INSERT INTO `us_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1786, 126, 'session_tokens', 'a:140:{s:64:\"6cd080a8b71603dee0e070e71cf0b5e6da08396a83d9acfab1d943388523518b\";a:4:{s:10:\"expiration\";i:1617771693;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617598893;}s:64:\"ccf87316d6e97389f8625c40f6670c8446887300a2d0e2f83bc580fb02596dff\";a:4:{s:10:\"expiration\";i:1617771693;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617598893;}s:64:\"efd8ee27d3e91f01bdedcd60546ced2e9f4c3b48d079bb4da872c387e356039e\";a:4:{s:10:\"expiration\";i:1617774759;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617601959;}s:64:\"4b3a727fa36e8d43114b3756723469e4125bf89f2b6dad7a986cb4366d498412\";a:4:{s:10:\"expiration\";i:1617774759;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617601959;}s:64:\"4e1f03991190894e8d4e4011c40669610e20a2492d667792ecf4512cb3e04f10\";a:4:{s:10:\"expiration\";i:1617774792;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617601992;}s:64:\"be0312272501eb5e066a3d71b01b449ef884b930cc16d74e07c5a370d15f783a\";a:4:{s:10:\"expiration\";i:1617774792;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617601992;}s:64:\"451921474097b4908e4687ae3f7c161e47aa87e86e186874b978280cd3e0819b\";a:4:{s:10:\"expiration\";i:1617776239;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617603439;}s:64:\"5bebb2ecea871ac358eb93ed270277c1259f60b3e9b9b9ca5a6d6caf4fd12c89\";a:4:{s:10:\"expiration\";i:1617776239;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617603439;}s:64:\"21e65a312214a58a07b52fc68d761cf93129b0f62f9d24190efe480e96898282\";a:4:{s:10:\"expiration\";i:1617777117;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617604317;}s:64:\"fd1e711e68d559f0c955a1b44d92dcbe67bed9bc074d2e572ee132386971e024\";a:4:{s:10:\"expiration\";i:1617777117;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617604317;}s:64:\"70960628c9b79c1f3cbc70085e765ba28e62f3ae6bd99fee6f94ce6f408c39de\";a:4:{s:10:\"expiration\";i:1617777382;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617604582;}s:64:\"4e45c1fc73c4b0e70bd13643819678049a67264262116e69781d650fec070b58\";a:4:{s:10:\"expiration\";i:1617777382;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617604582;}s:64:\"9c9b8215d2a4ff6c6b188ea032d75b920f822c5bf40181ac89e87de9c69008cb\";a:4:{s:10:\"expiration\";i:1617778299;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605499;}s:64:\"c79faa339d5dd48be9ee9f021b5b4e4429814823302c8e3d3211fd2f156ad7ac\";a:4:{s:10:\"expiration\";i:1617778299;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605499;}s:64:\"85eb619735ff055e3058f8f10ef33f7c5ae637e53b95cc74c39256e59c737104\";a:4:{s:10:\"expiration\";i:1617778434;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605634;}s:64:\"8caec92bdaff71898258a3f7f2c308edab0f8a1026d4fc1822045d1e3a87743c\";a:4:{s:10:\"expiration\";i:1617778434;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605634;}s:64:\"943746ffc8ea3ce4cc82b302c1d61dc08a3d34c4190fa89991c5b9c46ca51794\";a:4:{s:10:\"expiration\";i:1617778466;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605666;}s:64:\"cbd1ee0da010869a876875e0ef33fb4d7303c7650f73ee9429433ba9939adfa3\";a:4:{s:10:\"expiration\";i:1617778466;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605666;}s:64:\"5a04eaf1a64206628c4213841d4f490e5ef75ad48768eb33bc375f9c595e0b83\";a:4:{s:10:\"expiration\";i:1617778608;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605808;}s:64:\"e99975659fdc6ba2440eba1266051ae4d7a5424335d90a5fc182bcd8176c9d8b\";a:4:{s:10:\"expiration\";i:1617778608;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617605808;}s:64:\"cfea9750fe405bc325f2282a5e034e6d60eb5cbcda65f60f22e9f19cb867280a\";a:4:{s:10:\"expiration\";i:1617779290;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617606490;}s:64:\"5020903234ad5953210cde1daef2ac2bc7c70b866a8163802375d8c11af0f5ac\";a:4:{s:10:\"expiration\";i:1617779290;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617606490;}s:64:\"93cf699fbf924238ef334a9e6c550789cdb5f31fc9dae0118897ee2db6a41f5a\";a:4:{s:10:\"expiration\";i:1617779449;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617606649;}s:64:\"912998758166b7b8729a9311f4737d07f319a016e71d37c87ce6824709c8efb4\";a:4:{s:10:\"expiration\";i:1617779449;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617606649;}s:64:\"2bf434f4085670630ab553361d6ee7abee105178bcc0246e7547111d723d197f\";a:4:{s:10:\"expiration\";i:1617780244;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617607444;}s:64:\"0f1688b730f90c99d0b6f0004b801ae341d24a7d7417dd5c1677fba3d715cd64\";a:4:{s:10:\"expiration\";i:1617780244;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617607444;}s:64:\"18617bf2d8c7bf0bae4e842b7ae54d1e2e033cb79b8c71502b2cc5763299d42a\";a:4:{s:10:\"expiration\";i:1617780311;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617607511;}s:64:\"4b19137aab036857d572bdf9ca5de8a1e97e0c0e7ab698befe2f987727e8030b\";a:4:{s:10:\"expiration\";i:1617780311;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617607511;}s:64:\"4141df54cbd1298091062ba7d82cf59b84230d076212a6b82183fff0bc96ef80\";a:4:{s:10:\"expiration\";i:1617780945;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617608145;}s:64:\"01417339608b20ac8cfe80f639a2ba1e16922eff39522e3a0a0d955203ffa1ad\";a:4:{s:10:\"expiration\";i:1617780945;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617608145;}s:64:\"89e748d1363911bed73aff9404fb8fea71421685439476d54bfbd3d91d049681\";a:4:{s:10:\"expiration\";i:1617784416;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611616;}s:64:\"c491319b429363186b9d9608fdc67993f034829172ae021f3404d346b54a8266\";a:4:{s:10:\"expiration\";i:1617784416;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611616;}s:64:\"985503d12a051ef1594c74b711fe1ab95cf4edee2b3e5819cbdbc68ceec38dc6\";a:4:{s:10:\"expiration\";i:1617789046;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617616246;}s:64:\"653731f79ae31d4fa131b7f6d0527c4c65b98106a8c6de555b3f5503ffe74ec6\";a:4:{s:10:\"expiration\";i:1617789046;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617616246;}s:64:\"c6b075cccaaf2c93278a2fcb38256a03b9a7c19ee20b3687b29cccaf8ae61d49\";a:4:{s:10:\"expiration\";i:1617791722;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617618922;}s:64:\"f7772288d448cb64046d6ae5af62dfded81781fc0e05654417f7bf18475557fe\";a:4:{s:10:\"expiration\";i:1617791722;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617618922;}s:64:\"aa21e89e4ece9e579d8fefba75064d5b1a693583a1feaf54757fa358a67a493f\";a:4:{s:10:\"expiration\";i:1617791765;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617618965;}s:64:\"d13f5a59e5252a71d039fead37b7e993a0641dc072d5c02ec8084e0ec6a487d7\";a:4:{s:10:\"expiration\";i:1617791765;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617618965;}s:64:\"6b18107d47e402d156553dc49f776c53cacd167af13ee675ecece78f88a8f241\";a:4:{s:10:\"expiration\";i:1617791922;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619122;}s:64:\"05a873097b49e62dc0e7bc0656b5c1e20c91d487cc47225871a43ed8ec127010\";a:4:{s:10:\"expiration\";i:1617791922;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619122;}s:64:\"84abeb865e901d9fd054d2b8b5c91783199e327da8461e36e9009f34cd13e584\";a:4:{s:10:\"expiration\";i:1617792019;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619219;}s:64:\"1f657d6f47b1cc785e9337e2fa16b3c0de9ca1e07896e06ed5ce305c7d6b8dbe\";a:4:{s:10:\"expiration\";i:1617792019;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619219;}s:64:\"6ca9ded44aa1fb18fa9dcf79dccc47ac841a50a72baa701d29ca5b1ab59d6e1f\";a:4:{s:10:\"expiration\";i:1617792205;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619405;}s:64:\"515ab933bd26f5832f8707b1eb36a481940ac9527ff044d9d557c94349b4d331\";a:4:{s:10:\"expiration\";i:1617792205;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619405;}s:64:\"ca92f7f6520393a92f9d9529bf1b1f2b06dad9bb5817f02354d00918a7a2a1d2\";a:4:{s:10:\"expiration\";i:1617792296;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619496;}s:64:\"86ade6ae50497141290b7886a2ea99937bbf107dc457dcbe4afab85888407e40\";a:4:{s:10:\"expiration\";i:1617792296;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619496;}s:64:\"792b8efb87b8d00f3621a6c65e70cf29f552749080d9111fcbe5acce9b46956e\";a:4:{s:10:\"expiration\";i:1617792414;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619614;}s:64:\"f1b0b1ed35beaee034cbb20966f9ddf9d7e1e2f872c9f81410800d6b0ba8c84d\";a:4:{s:10:\"expiration\";i:1617792414;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619614;}s:64:\"6fb2d5c03d444445283b0ec23bb57e534b4fc2daf27d7f2c3646facbf7ea844c\";a:4:{s:10:\"expiration\";i:1617792639;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619839;}s:64:\"4b346f6d1cb20bc9cb3b293efb2e510cbf418f7785f22cda1766c75ab47b5320\";a:4:{s:10:\"expiration\";i:1617792639;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617619839;}s:64:\"4f4cbed6442fe90c551bc9f90d61a8982f785b95aa9d28903f8eb1ce3ab3f911\";a:4:{s:10:\"expiration\";i:1617792897;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620097;}s:64:\"7ec5b4c0a28f446cf72a13a329a5a49d1b6c77509acd9078273907728a617dbf\";a:4:{s:10:\"expiration\";i:1617792897;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620097;}s:64:\"b7d2478d477e331125922441e60c1b99ba250676b3ae6a181446b6b0fa589be3\";a:4:{s:10:\"expiration\";i:1617793051;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620251;}s:64:\"dd0f0fb93ddcaf0162b01da046ec83a6678f610c100b6ee0c24ac0c5a2b246a1\";a:4:{s:10:\"expiration\";i:1617793051;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620251;}s:64:\"c2dea99c9e92e685ce43d24668c21436548ee3229d8066215aea58fba3025702\";a:4:{s:10:\"expiration\";i:1617793105;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620305;}s:64:\"c24c8faf098478ab56a519e56bad498a99fd976da388afbffebcc4051350dcd4\";a:4:{s:10:\"expiration\";i:1617793105;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620305;}s:64:\"894cf8fc76420d556f7943c362eb05e888669afe822f606d6c9cd8086d4aaef4\";a:4:{s:10:\"expiration\";i:1617793342;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620542;}s:64:\"41ccdede88116dc532328b8421b9a48cd53b4179e40b307688b3a2c583c08478\";a:4:{s:10:\"expiration\";i:1617793342;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617620542;}s:64:\"3ab4ec11fc4b8c16b1b0ec3a9874e552c7244d1e0585fb82e220c793bc369cc8\";a:4:{s:10:\"expiration\";i:1617794629;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617621829;}s:64:\"2ce10e21b84338734f018346e47691f6dd64cb9fa4bb927de1e6271c2db2ac27\";a:4:{s:10:\"expiration\";i:1617794629;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617621829;}s:64:\"ccead4fc76ed0198992a56256b66126ff889576f9746b3093da5c4ccbc8bbc73\";a:4:{s:10:\"expiration\";i:1617794858;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622058;}s:64:\"f9a57c1c69b9d83f4c2b2921f1a143ce83660f732b19f7da6b4b08b9a2e2db20\";a:4:{s:10:\"expiration\";i:1617794858;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622058;}s:64:\"1ff756d0365bba5d6a4246517a3bde9c9c73cba3c905dd033f4faf26e81640ba\";a:4:{s:10:\"expiration\";i:1617794875;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622075;}s:64:\"96893012bddf902add0797abe731af936cede26d39e3a408213e1151220ec4bf\";a:4:{s:10:\"expiration\";i:1617794875;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622075;}s:64:\"808ce059b19cb2b329dcd79319d69e488016fe4acdf95211f819f2de97cf5fce\";a:4:{s:10:\"expiration\";i:1617795015;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622215;}s:64:\"7f33e69322f4cdd6f948e8a17e36b9fd99441a93bb344e2de55fa4371255b20d\";a:4:{s:10:\"expiration\";i:1617795015;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622215;}s:64:\"04bf9a68e1252611dcdfa9b030a002f7eaaf87dc0874e383edc7857d6e47f548\";a:4:{s:10:\"expiration\";i:1617795016;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622216;}s:64:\"e47a559be2768869f69c179d983e4935f224f610e27d60363822bc24fde0482f\";a:4:{s:10:\"expiration\";i:1617795016;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622216;}s:64:\"6007e42efb1713026d896f8f9e1ee35882d2a2d472b7611a512058a0ebb6014a\";a:4:{s:10:\"expiration\";i:1617795118;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622318;}s:64:\"94b2180139bcb96006b0b466ab7cf60452ec4d1250e41bc4dcf062e205664b32\";a:4:{s:10:\"expiration\";i:1617795119;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622319;}s:64:\"f0c325de209f71e564d0f17dbbeead376dd064e4fd22d706755dc3f321339158\";a:4:{s:10:\"expiration\";i:1617795199;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622399;}s:64:\"af82d0860d2b35e2a44fd0b4a2027942e6a384cdf15b498cc95fb21ebe89ee29\";a:4:{s:10:\"expiration\";i:1617795199;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622399;}s:64:\"963ccd3617731fa041c2938e7dd69ed180a22a83b70db251fb2882dbe07e022b\";a:4:{s:10:\"expiration\";i:1617795636;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622836;}s:64:\"3c52fc678bd86e03f5a11bc527b669cd6a8f8d163b862044f90ea1be621783ca\";a:4:{s:10:\"expiration\";i:1617795636;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622836;}s:64:\"3a9e13600c2d0f1722bc04b096a4e2d90e4c94dcc8397d9d16b0dd427b43bf9e\";a:4:{s:10:\"expiration\";i:1617795764;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622964;}s:64:\"ca8d8a25340fd2fd8dfdf2c440e4421cc9d87205d66986c0077f574296cdf753\";a:4:{s:10:\"expiration\";i:1617795764;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617622964;}s:64:\"0264549908a19dc2e24ce217926d9e6b9b4c1ed7c78208549780a0c9bbf4dadd\";a:4:{s:10:\"expiration\";i:1617795903;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623103;}s:64:\"b3140dc48b783fa521124d10e66781bc56602188408b8b6a93c88a93d2c00db1\";a:4:{s:10:\"expiration\";i:1617795903;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623103;}s:64:\"3ac7fddd05db8c5333b5a5d5af715450e06c9e5df587f5e629c5527e2ee27fcf\";a:4:{s:10:\"expiration\";i:1617795985;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623185;}s:64:\"96fb170a12ee8e757d54e6e57ba7196cd41d7a348cd4de8ea193895655defecd\";a:4:{s:10:\"expiration\";i:1617795985;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623185;}s:64:\"07e55ab083a4825d51584e9fc6210973e2f22f90dc65dbae31ba39ce84773656\";a:4:{s:10:\"expiration\";i:1617796333;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623533;}s:64:\"e6a8b038bcb2b47c680c46b38f55c144afb54bb9e95ed4005489d82c53532d83\";a:4:{s:10:\"expiration\";i:1617796333;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623533;}s:64:\"3ac53d2769f6ca5954e81cc93b2d795d123612333610c01f89f462e1979e02bb\";a:4:{s:10:\"expiration\";i:1617796517;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623717;}s:64:\"a9d7151c7d9aac5c40c83950d89635da494d607dece17017c7d45692933bce50\";a:4:{s:10:\"expiration\";i:1617796517;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623717;}s:64:\"c7ce0c2a2f71322aa80c53e5b951d06780da8c712e4504330502b57d2fab7d05\";a:4:{s:10:\"expiration\";i:1617796628;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623828;}s:64:\"1999460ee24e5be221f2eea80285241bc285ef27c85f5f274bfefda114dad029\";a:4:{s:10:\"expiration\";i:1617796628;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623828;}s:64:\"2054de571766177ad044af38e0920a2ac67bce804d04cf6023f5c7211c4829fd\";a:4:{s:10:\"expiration\";i:1617796697;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623897;}s:64:\"c4d645e9271d0a0e78d2ad23d3986535203988c064f0201dc6bf8937a9defbb4\";a:4:{s:10:\"expiration\";i:1617796697;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623897;}s:64:\"b93148d18eac23e3d1a001486d4269a250687f95a443615376c4d41ea9a973e2\";a:4:{s:10:\"expiration\";i:1617796726;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623926;}s:64:\"0761d57c2cdbf73b2b0dc0f2a0cef146de2c11eb73dce5aac8add94cd9caf1b8\";a:4:{s:10:\"expiration\";i:1617796727;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623927;}s:64:\"99088d62d1bb47bd5ba0da64d9dada9e093ff6e2daa84fda558a20ecea54ccac\";a:4:{s:10:\"expiration\";i:1617796765;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623965;}s:64:\"d68b16cc265ef9703dc475b71c589ed41142f22fb56129439e156fd0ab3dc24e\";a:4:{s:10:\"expiration\";i:1617796765;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617623965;}s:64:\"bd8babaa8c4b2f288ac47a2204067850f9ae47d17dda7686069d1a64435c746a\";a:4:{s:10:\"expiration\";i:1617796856;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624056;}s:64:\"375637acddea6ee613a3f98e8cea4dd451dc6797d01030937528137e40d4ff7a\";a:4:{s:10:\"expiration\";i:1617796856;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624056;}s:64:\"0dd5f190319813368306823c32cde02a3f0bfbef22b7290f2115fc6f4f7d43ec\";a:4:{s:10:\"expiration\";i:1617796874;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624074;}s:64:\"9a02b791acde2bf77c2c72fe51f964b5cb1d11556864fff10f12166ab7844cee\";a:4:{s:10:\"expiration\";i:1617796874;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624074;}s:64:\"e9d8cc20031d05cc841876f5bdd41bd60b682bbf6e2b4f659cc65ec25777c9fc\";a:4:{s:10:\"expiration\";i:1617796885;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624085;}s:64:\"188ca7e6e6092d63368dd02c964c1aa4ec81a81e4c3ffb90ae9a6fba1fe2d67e\";a:4:{s:10:\"expiration\";i:1617796885;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624085;}s:64:\"bc96165753f262780c033257107acae5bc4f65ff3f5b172bf0b53a64d268ed28\";a:4:{s:10:\"expiration\";i:1617796956;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624156;}s:64:\"88d5f7b7fd9d0edf40b414f2b7edbcaca5d209c78d85a74d5df5138e7b9c5ac4\";a:4:{s:10:\"expiration\";i:1617796957;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624157;}s:64:\"a36fba69aaac0c102a69847f0be04243147df8de0eb43678e5944b7de7381b41\";a:4:{s:10:\"expiration\";i:1617797305;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624505;}s:64:\"338f380a781b9fcaf9b71406d427f47ea46b4050f7a64905ea6a6daa9afbae48\";a:4:{s:10:\"expiration\";i:1617797305;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624505;}s:64:\"684bef79e12cc9cd69ba7c53179949822801f602e4a013753ff5a1672913f4d9\";a:4:{s:10:\"expiration\";i:1617797345;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624545;}s:64:\"d589593f8ea8ba5b3807bc7951deeffaf9602af3ba277a255cbde5dcac8fb994\";a:4:{s:10:\"expiration\";i:1617797345;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624545;}s:64:\"5890beee68a65e81e73be561750d9609ead4b525bf89e157de842504cd041440\";a:4:{s:10:\"expiration\";i:1617797354;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624554;}s:64:\"50d20411a15d70ad4b5bc0b40d6b8540e253440c9aca55e0c7998617f47f191e\";a:4:{s:10:\"expiration\";i:1617797354;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624554;}s:64:\"183b0a7e53b0766461611004032a9e2013115abb05dae3db0724ecabb8208053\";a:4:{s:10:\"expiration\";i:1617797393;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624593;}s:64:\"f5fb5d0228bbf9e66dc7d0b6a24c773a4e7f737b95cbc470d96d038251b6d348\";a:4:{s:10:\"expiration\";i:1617797393;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624593;}s:64:\"76b5f4de4246fd9ad3e45477271ba7a87aa2e8326fbfdec99f687754d2dfdfa0\";a:4:{s:10:\"expiration\";i:1617797463;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624663;}s:64:\"aaf039212653dd1b526c7ef1e9d8a5fafce9f8a6b5db45dc55d9475711f66456\";a:4:{s:10:\"expiration\";i:1617797463;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624663;}s:64:\"5144a53a7e16f23ea8c32bd3a88fe1df5003967e559191c4f022954066a5eac3\";a:4:{s:10:\"expiration\";i:1617797550;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624750;}s:64:\"482be8963ebba1225b35817f415356227defba3eed4db69c49ff46d374dc2543\";a:4:{s:10:\"expiration\";i:1617797550;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624750;}s:64:\"579d2d60702fcc0b3b72231f7b5e2c84bc6cecd3bd02f25c485e05120776623f\";a:4:{s:10:\"expiration\";i:1617797645;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624845;}s:64:\"d7a19e4cceb7031ea3c447c203118dd798f4b616dc8017a0c49747952ad0e2bf\";a:4:{s:10:\"expiration\";i:1617797645;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624845;}s:64:\"88fc59344682ce5c7edcf3ec7ee7fba01aec0e41ca3c2795cc6901a68b52d190\";a:4:{s:10:\"expiration\";i:1617797646;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624846;}s:64:\"0236475c90c61ae910d79baa39a62e512917104fd560206802e3c0746837ae63\";a:4:{s:10:\"expiration\";i:1617797646;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617624846;}s:64:\"cce23849c45e3d8df6f1300b5189c508d63256873f7924d210cf39b448f17358\";a:4:{s:10:\"expiration\";i:1617798077;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625277;}s:64:\"1f70ee951b066719090d4d46da3e160c015e1da902e812a8ee66883f46853ee7\";a:4:{s:10:\"expiration\";i:1617798077;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625277;}s:64:\"5b70667460cee9a1a78e4ddb796ec413ad72fda22153c9fd6dddc5dd95b033e1\";a:4:{s:10:\"expiration\";i:1617798077;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625277;}s:64:\"57dbd27a3d1763061e356a05c28cf70fba102fb727891cf1f1d1836f5760d896\";a:4:{s:10:\"expiration\";i:1617798077;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625277;}s:64:\"d6ca2ce86a46f5da4c22e6522d54ee08c14c232359e30e1d2e28708c6d1df9e4\";a:4:{s:10:\"expiration\";i:1617798199;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625399;}s:64:\"e4b2b96b98f38b530a7150b37980092d00c8baebdcda648c43d2710d785a2905\";a:4:{s:10:\"expiration\";i:1617798199;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625399;}s:64:\"5d5ecb3f6ec2fd7559020cf71f066a1b5cd7f51e7712d3feb7037d42a81766ce\";a:4:{s:10:\"expiration\";i:1617798297;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625497;}s:64:\"12da6f1ccf27a45705aac1944ecc6ddf020fd85c4a947c24b6e4d848c26807dd\";a:4:{s:10:\"expiration\";i:1617798297;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625497;}s:64:\"28c048add784db5594503fdad9127b4d1d5440e552712756ff6d7f497b84a98a\";a:4:{s:10:\"expiration\";i:1617798386;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625586;}s:64:\"d155c61e9a2dca613a069f41bdd976c0d1d55b8cf3553465e337e6ae4dd28f63\";a:4:{s:10:\"expiration\";i:1617798386;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625586;}s:64:\"42d73e94f4340a4e9d67f0c8392be6fcdc004f252b6454c73fd188f70027fee1\";a:4:{s:10:\"expiration\";i:1617798530;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625730;}s:64:\"257c033a711f9653ac444db725f1c9f745928a47de955548260b5620b8a5258f\";a:4:{s:10:\"expiration\";i:1617798531;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617625731;}s:64:\"8f04ef4884cc780b0e83148a0a410ba2fdc12534fe417bdb02fc229b1d98d0f0\";a:4:{s:10:\"expiration\";i:1617799052;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626252;}s:64:\"d1af1217c9f8b6ba25ee64c3a318279b28fa68d098f94cd4b0a90a2c27d096e9\";a:4:{s:10:\"expiration\";i:1617799052;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626252;}s:64:\"b754b068b3c02f6f81efd7398dd07ec740e40301f619d8be23ebf043d9d5995e\";a:4:{s:10:\"expiration\";i:1617799092;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626292;}s:64:\"b3a71e9304d8aa11c83d696ae5a76c2d50575cb17c06fba475da878e7c1166fc\";a:4:{s:10:\"expiration\";i:1617799092;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626292;}s:64:\"7b9e32f426d71b81522d98867522935d8955b769c6c7532fac82168a0a0aaa8e\";a:4:{s:10:\"expiration\";i:1617799135;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626335;}s:64:\"d90698b2e0db09752e7b8dd419ae69c0e97f076cef616782af6bf4686fa71bcb\";a:4:{s:10:\"expiration\";i:1617799135;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626335;}s:64:\"3949f0091e74f65fe784dc22f7b7e134c01295a8d6ee6246c9e015d299c0821c\";a:4:{s:10:\"expiration\";i:1617799721;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626921;}s:64:\"5c64f2f2affd5a93652a6a2e273be83a8e365de09cc44e263096ae241f93269a\";a:4:{s:10:\"expiration\";i:1617799721;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617626921;}s:64:\"73d6c858cb3236ad1556643a8bcf12a60e59783b064be476b9fb527996ec2c7c\";a:4:{s:10:\"expiration\";i:1617800159;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617627359;}s:64:\"133186a69240167c111b69fdf7b3357f7bb2baa567c3a553c376f105a6353ab9\";a:4:{s:10:\"expiration\";i:1617800159;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617627359;}s:64:\"46841f50a2ed07d090db16233f78cc7fdae55664bd0b2a58497a7b942b1f17a2\";a:4:{s:10:\"expiration\";i:1617800337;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617627537;}s:64:\"abe52c4bdc7ffdadf364b4b82b4ca9be101f00c0628fb00fbda462cbfd40aaa5\";a:4:{s:10:\"expiration\";i:1617800337;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617627537;}}');
INSERT INTO `us_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1787, 121, 'session_tokens', 'a:4:{s:64:\"3384a50549bdc8ccd5a647d1acff489deee8aa8a51ea9a26bc4fd51c0e9c736c\";a:4:{s:10:\"expiration\";i:1617784496;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611696;}s:64:\"465b6ac9e1471854aba3ec4daf9c45d066fdf99131479c84ea83f4063eb944c9\";a:4:{s:10:\"expiration\";i:1617784496;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611696;}s:64:\"e83f051baa170a47d42a95be6dcd65038b9dc651d1c172f9ba41b80672d83491\";a:4:{s:10:\"expiration\";i:1617784536;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611736;}s:64:\"f416dad50ae607bafdf49fb24c8bd41c71713ebe0a767167286764358c8ae888\";a:4:{s:10:\"expiration\";i:1617784536;s:2:\"ip\";s:12:\"192.168.1.11\";s:2:\"ua\";s:161:\"Mozilla/5.0 (Linux; Android 10; vivo 1818 Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/89.0.4389.105 Mobile Safari/537.36\";s:5:\"login\";i:1617611736;}}'),
(1788, 127, 'nickname', 'mp'),
(1789, 127, 'first_name', ''),
(1790, 127, 'last_name', ''),
(1791, 127, 'description', ''),
(1792, 127, 'rich_editing', 'true'),
(1793, 127, 'syntax_highlighting', 'true'),
(1794, 127, 'comment_shortcuts', 'false'),
(1795, 127, 'admin_color', 'fresh'),
(1796, 127, 'use_ssl', '0'),
(1797, 127, 'show_admin_bar_front', 'true'),
(1798, 127, 'locale', ''),
(1799, 127, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1800, 127, 'us_user_level', '0'),
(1801, 127, 'dismissed_wp_pointers', ''),
(1802, 128, 'nickname', 'mp1'),
(1803, 128, 'first_name', ''),
(1804, 128, 'last_name', ''),
(1805, 128, 'description', ''),
(1806, 128, 'rich_editing', 'true'),
(1807, 128, 'syntax_highlighting', 'true'),
(1808, 128, 'comment_shortcuts', 'false'),
(1809, 128, 'admin_color', 'fresh'),
(1810, 128, 'use_ssl', '0'),
(1811, 128, 'show_admin_bar_front', 'true'),
(1812, 128, 'locale', ''),
(1813, 128, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1814, 128, 'us_user_level', '0'),
(1815, 128, 'dismissed_wp_pointers', ''),
(1816, 129, 'nickname', 'mp2'),
(1817, 129, 'first_name', ''),
(1818, 129, 'last_name', ''),
(1819, 129, 'description', ''),
(1820, 129, 'rich_editing', 'true'),
(1821, 129, 'syntax_highlighting', 'true'),
(1822, 129, 'comment_shortcuts', 'false'),
(1823, 129, 'admin_color', 'fresh'),
(1824, 129, 'use_ssl', '0'),
(1825, 129, 'show_admin_bar_front', 'true'),
(1826, 129, 'locale', ''),
(1827, 129, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1828, 129, 'us_user_level', '0'),
(1829, 129, 'dismissed_wp_pointers', ''),
(1830, 130, 'nickname', 'mp3'),
(1831, 130, 'first_name', ''),
(1832, 130, 'last_name', ''),
(1833, 130, 'description', ''),
(1834, 130, 'rich_editing', 'true'),
(1835, 130, 'syntax_highlighting', 'true'),
(1836, 130, 'comment_shortcuts', 'false'),
(1837, 130, 'admin_color', 'fresh'),
(1838, 130, 'use_ssl', '0'),
(1839, 130, 'show_admin_bar_front', 'true'),
(1840, 130, 'locale', ''),
(1841, 130, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1842, 130, 'us_user_level', '0'),
(1843, 130, 'dismissed_wp_pointers', ''),
(1844, 131, 'nickname', '1234'),
(1845, 131, 'first_name', ''),
(1846, 131, 'last_name', ''),
(1847, 131, 'description', ''),
(1848, 131, 'rich_editing', 'true'),
(1849, 131, 'syntax_highlighting', 'true'),
(1850, 131, 'comment_shortcuts', 'false'),
(1851, 131, 'admin_color', 'fresh'),
(1852, 131, 'use_ssl', '0'),
(1853, 131, 'show_admin_bar_front', 'true'),
(1854, 131, 'locale', ''),
(1855, 131, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1856, 131, 'us_user_level', '0'),
(1857, 131, 'dismissed_wp_pointers', ''),
(1858, 132, 'nickname', 'user'),
(1859, 132, 'first_name', ''),
(1860, 132, 'last_name', ''),
(1861, 132, 'description', ''),
(1862, 132, 'rich_editing', 'true'),
(1863, 132, 'syntax_highlighting', 'true'),
(1864, 132, 'comment_shortcuts', 'false'),
(1865, 132, 'admin_color', 'fresh'),
(1866, 132, 'use_ssl', '0'),
(1867, 132, 'show_admin_bar_front', 'true'),
(1868, 132, 'locale', ''),
(1869, 132, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1870, 132, 'us_user_level', '0'),
(1871, 132, 'dismissed_wp_pointers', ''),
(1872, 133, 'nickname', 'test'),
(1873, 133, 'first_name', ''),
(1874, 133, 'last_name', ''),
(1875, 133, 'description', ''),
(1876, 133, 'rich_editing', 'true'),
(1877, 133, 'syntax_highlighting', 'true'),
(1878, 133, 'comment_shortcuts', 'false'),
(1879, 133, 'admin_color', 'fresh'),
(1880, 133, 'use_ssl', '0'),
(1881, 133, 'show_admin_bar_front', 'true'),
(1882, 133, 'locale', ''),
(1883, 133, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1884, 133, 'us_user_level', '0'),
(1885, 133, 'dismissed_wp_pointers', ''),
(1886, 134, 'nickname', 'asdf'),
(1887, 134, 'first_name', ''),
(1888, 134, 'last_name', ''),
(1889, 134, 'description', ''),
(1890, 134, 'rich_editing', 'true'),
(1891, 134, 'syntax_highlighting', 'true'),
(1892, 134, 'comment_shortcuts', 'false'),
(1893, 134, 'admin_color', 'fresh'),
(1894, 134, 'use_ssl', '0'),
(1895, 134, 'show_admin_bar_front', 'true'),
(1896, 134, 'locale', ''),
(1897, 134, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1898, 134, 'us_user_level', '0'),
(1899, 134, 'dismissed_wp_pointers', ''),
(1900, 135, 'nickname', 'asdf1'),
(1901, 135, 'first_name', ''),
(1902, 135, 'last_name', ''),
(1903, 135, 'description', ''),
(1904, 135, 'rich_editing', 'true'),
(1905, 135, 'syntax_highlighting', 'true'),
(1906, 135, 'comment_shortcuts', 'false'),
(1907, 135, 'admin_color', 'fresh'),
(1908, 135, 'use_ssl', '0'),
(1909, 135, 'show_admin_bar_front', 'true'),
(1910, 135, 'locale', ''),
(1911, 135, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1912, 135, 'us_user_level', '0'),
(1913, 135, 'dismissed_wp_pointers', ''),
(1914, 136, 'nickname', 'asdf112'),
(1915, 136, 'first_name', ''),
(1916, 136, 'last_name', ''),
(1917, 136, 'description', ''),
(1918, 136, 'rich_editing', 'true'),
(1919, 136, 'syntax_highlighting', 'true'),
(1920, 136, 'comment_shortcuts', 'false'),
(1921, 136, 'admin_color', 'fresh'),
(1922, 136, 'use_ssl', '0'),
(1923, 136, 'show_admin_bar_front', 'true'),
(1924, 136, 'locale', ''),
(1925, 136, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1926, 136, 'us_user_level', '0'),
(1927, 136, 'dismissed_wp_pointers', ''),
(1928, 137, 'nickname', 'asdf112133'),
(1929, 137, 'first_name', ''),
(1930, 137, 'last_name', ''),
(1931, 137, 'description', ''),
(1932, 137, 'rich_editing', 'true'),
(1933, 137, 'syntax_highlighting', 'true'),
(1934, 137, 'comment_shortcuts', 'false'),
(1935, 137, 'admin_color', 'fresh'),
(1936, 137, 'use_ssl', '0'),
(1937, 137, 'show_admin_bar_front', 'true'),
(1938, 137, 'locale', ''),
(1939, 137, 'us_capabilities', 'a:1:{s:8:\"customer\";b:1;}'),
(1940, 137, 'us_user_level', '0'),
(1941, 137, 'dismissed_wp_pointers', '');

-- --------------------------------------------------------

--
-- Table structure for table `us_users`
--

CREATE TABLE `us_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_users`
--

INSERT INTO `us_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Bx/xmQMB9PmoUjXIQEkGUHHthKbLwG.', 'admin', 'manish.bharathamitsolutions@gmail.com', 'http://localhost:8080/upstore', '2021-03-10 04:05:09', '', 0, 'admin'),
(121, 'manish', '$P$BRaoyA3cFGW2BW4ZTJEEIPUPrUxqKI1', 'manish', 'manish@gmail.com', '', '2021-03-31 10:06:47', '', 0, 'manish'),
(122, 'arun', '$P$B1QSE7WlKvHMlVLTIC53PmkEIu4pt9.', 'arun', 'pathrose@gmail.com', '', '2021-03-31 10:09:13', '', 0, 'arun'),
(123, 'sruthy', '$P$BTesKjDEulSekXgb24jegvTLPlbBus0', 'sruthy', 'sruthy@gmail.com', '', '2021-03-31 10:10:38', '', 0, 'sruthy'),
(124, 'aiswarya', '$P$BAdAh1X7g282u6AUNdsz/ue/RWyg270', 'aiswarya', 'aiswarya@gmail.com', '', '2021-03-31 10:12:05', '', 0, 'aiswarya'),
(125, 'praseetha', '$P$BGDDDXXVjbggI8ZKHa1kz4MHjJ8ALh.', 'praseetha', 'praseetha@gmail.com', '', '2021-03-31 10:13:36', '', 0, 'praseetha'),
(126, 'arun123', '$P$BaR4G03B6/naU4J21z5k94FIS1BDHW1', 'arun123', 'arunpathrose7rrt@gmail.com', '', '2021-04-01 07:01:09', '', 0, 'arun123'),
(127, 'mp', '$P$BJISgr75AY5E.rXYKOqMhDi9AotmkR/', 'mp', 'mp@gmai.com', '', '2021-04-06 15:16:33', '', 0, 'mp'),
(128, 'mp1', '$P$BZZ7xmByjYQ9q5GPifS5GodYHUEdVu0', 'mp1', 'mp1@gmai.com', '', '2021-04-06 15:17:43', '', 0, 'mp1'),
(129, 'mp2', '$P$BYGyxs.jkpHoW.08oGbK7B4V6cQcZ00', 'mp2', 'mp2@gmai.com', '', '2021-04-06 15:19:04', '', 0, 'mp2'),
(130, 'mp3', '$P$Bic.DRkxBdtpERvAod3I6qRotsUF6r/', 'mp3', 'mp3@gmai.com', '', '2021-04-06 15:19:59', '', 0, 'mp3'),
(131, '1234', '$P$BuHG3BO7GonN6Riv7ov86bhJ/gIc/M0', '1234', 'location@gmail.com', '', '2021-04-06 15:21:54', '', 0, '1234'),
(132, 'user', '$P$BhSxAI/DjzshfECO5y3fQ.6/msxSKH0', 'user', 'hh@gmail.com', '', '2021-04-06 15:23:50', '', 0, 'user'),
(133, 'test', '$P$BRcvAv8A6mmDpZtcPT/DwiJ6onCEMu1', 'test', 'mp@gm.com', '', '2021-04-06 15:38:58', '', 0, 'test'),
(134, 'asdf', '$P$BWSdxRfUswqUqhYvYmQ4PX2ln22nxM/', 'asdf', 'asdsd@gmail.com', '', '2021-04-06 15:40:24', '', 0, 'asdf'),
(135, 'asdf1', '$P$BmvN2iEIYbrcvLlE8Dsm7vv67siI7i.', 'asdf1', 'asdsasasd@gmail.com', '', '2021-04-06 15:42:22', '', 0, 'asdf1'),
(136, 'asdf112', '$P$BAvhem4w5wGflN7rLdGzaSzENMkyRO0', 'asdf112', 'a11asd@gmail.com', '', '2021-04-06 15:45:04', '', 0, 'asdf112'),
(137, 'asdf112133', '$P$BxAjPOsAW9Ozn09iYZoFUIHTR/Vmah1', 'asdf112133', 'a11asdsdsd@gmail.com', '', '2021-04-06 15:57:54', '', 0, 'asdf112133');

-- --------------------------------------------------------

--
-- Table structure for table `us_user_data`
--

CREATE TABLE `us_user_data` (
  `t_id` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `alt_mobile` varchar(15) NOT NULL,
  `display_name` varchar(30) NOT NULL,
  `address` varchar(200) NOT NULL,
  `town_name` varchar(50) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `district_id` varchar(30) NOT NULL,
  `street_name` varchar(40) NOT NULL,
  `postoffice` varchar(30) NOT NULL,
  `landmark` varchar(150) NOT NULL,
  `sponser_code` varchar(500) NOT NULL,
  `profile_pic` int(11) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(25) DEFAULT NULL,
  `status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_user_data`
--

INSERT INTO `us_user_data` (`t_id`, `ID`, `mobile`, `alt_mobile`, `display_name`, `address`, `town_name`, `pincode`, `district_id`, `street_name`, `postoffice`, `landmark`, `sponser_code`, `profile_pic`, `created_on`, `created_by`, `status`) VALUES
(19, 78, '', '', '', '', '', '', '', '', '', '', 'UPST6DGSM35AS13', 0, '2021-03-31 14:31:23', NULL, NULL),
(62, 121, '9961824567', '234579009', 'manish', 'manish', 'thrissur', '680562', '12', 'mapranam', 'arattupuzha', 'arattupuzg', 'UPST1212UV0P4SOW3', 339, '2021-03-31 15:36:47', NULL, NULL),
(63, 122, '9847529119', '9876543021', 'arun', 'kuttikattil', 'lal', '680712', '12', 'kallada', 'Madayikonam', 'st joseph church', 'UPST122D4TZDVG0IR', 340, '2021-03-31 15:39:13', NULL, NULL),
(64, 123, '7559156783', '9876504311', 'sruthy', 'sru', 'palakkad', '679301', '13', 'lakkidi', 'Lakkidi', 'sreekrishna temple', 'UPST1232WQLCK18XS', 341, '2021-03-31 15:40:38', NULL, NULL),
(65, 124, '8521046239', '9745632108', 'aiswarya', 'koottala', 'pallisery', '680562', '12', 'pallisery', 'Arattupuzha', 'SBI bank', 'UPST124FKOXU07SXU', 342, '2021-03-31 15:42:05', NULL, NULL),
(66, 125, '8541099877', '9966541203', 'praseetha', 'moothedath', 'urakam', '680562', '12', 'urakam', 'Arattupuzha', 'postoffice', 'UPST125S2E62VRSN1', 343, '2021-03-31 15:43:36', NULL, NULL),
(67, 126, '8075065037567', '4566655667', 'arun123', 'chittilappilly housetyyyuu', 'thrissurttyyyuu', '680551556', '', 'adat', 'adatyuuuujfurufhdhfhd', 'adattyyyyjfjfifuftist', '', 361, '2021-04-01 12:31:11', NULL, NULL),
(68, 127, '9947374784', '8147374784', 'sagartest', 'location', 'location', '680712', '12', 'thrissur', 'Madayikonam', 'Mapranam', 'UPST1277AULYTJVEN', 441, '2021-04-06 20:46:44', NULL, NULL),
(69, 128, '9947374784', '8147374784', 'sagartest', 'location', 'location', '680712', '12', 'thrissur', 'Madayikonam', 'Mapranam', 'UPST128T5RETKKPB5', 442, '2021-04-06 20:47:52', NULL, NULL),
(70, 129, '9947374784', '8147374784', 'sagartest', 'location', 'location', '680712', '12', 'thrissur', 'Madayikonam', 'Mapranam', 'UPST1291KXRQYFV59', 443, '2021-04-06 20:49:13', NULL, NULL),
(71, 130, '9947374784', '8147374784', 'sagartest', 'location', 'location', '680712', '12', 'thrissur', 'Madayikonam', 'Mapranam', 'UPST130QK86O7BR6A', 444, '2021-04-06 20:50:08', NULL, NULL),
(72, 131, '45454', '545454', 'location', 'address', 'address', '680712', '15', 'asdasd', 'Madayikonam', 'asdasd', 'UPST131KFCIQ2T752', 445, '2021-04-06 20:51:54', NULL, NULL),
(73, 132, '22', '121', 'jhjh', 'hjgh', 'ghghg', '680712', '12', 'jgh', 'Madayikonam', 'jkhjkh', 'UPST132IG0ZW8NF82', 446, '2021-04-06 20:53:50', NULL, NULL),
(74, 133, '1234', '1234', 'manish', 'location', 'location', '680712', '12', 'adsas', 'Madayikonam', 'asd', 'UPST13375TRVA5GIN', 447, '2021-04-06 21:08:58', NULL, NULL),
(75, 134, '1234', '135', 'asdasd', 'asdasd', 'asdasd', '680712', '12', 'asdasd', 'Madayikonam', 'asdasd', 'UPST13449SLSA6A36', 448, '2021-04-06 21:10:24', NULL, NULL),
(76, 135, '1234', '135', 'asdasd', 'asdasd', 'asdasd', '680712', '12', 'asdasd', 'Madayikonam', 'asdasd', 'UPST135M3RFSYERWF', 449, '2021-04-06 21:12:22', NULL, NULL),
(77, 136, '1234', '135', 'asdasd', 'asdasd', 'asdasd', '680712', '12', 'asdasd', 'Madayikonam', 'asdasd', 'UPST136U1YO00FC27', 450, '2021-04-06 21:15:05', NULL, NULL),
(78, 137, '1234', '135', 'asdasd', 'asdasd', 'asdasd', '680712', '12', 'asdasd', 'Madayikonam', 'asdasd', 'UPST1379ZVYCG1DQ6', 451, '2021-04-06 21:27:54', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `us_user_relation_child`
--

CREATE TABLE `us_user_relation_child` (
  `id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `Level_id` int(11) NOT NULL,
  `position_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_user_relation_child`
--

INSERT INTO `us_user_relation_child` (`id`, `child_id`, `parent_id`, `Level_id`, `position_id`) VALUES
(30, 78, 1, 1, 'S'),
(72, 121, 78, 1, 'S'),
(73, 121, 1, 2, 'S'),
(74, 122, 121, 1, 'S'),
(75, 122, 78, 2, 'S'),
(76, 122, 1, 3, 'S'),
(77, 123, 122, 1, 'S'),
(78, 123, 121, 2, 'S'),
(79, 123, 78, 3, 'S'),
(80, 123, 1, 4, 'S'),
(81, 124, 123, 1, 'S'),
(82, 124, 122, 2, 'S'),
(83, 124, 121, 3, 'S'),
(84, 124, 78, 4, 'S'),
(85, 124, 1, 5, 'S'),
(86, 125, 124, 1, 'S'),
(87, 125, 123, 2, 'S'),
(88, 125, 122, 3, 'S'),
(89, 125, 121, 4, 'S'),
(90, 125, 78, 5, 'S'),
(91, 125, 1, 6, 'S'),
(92, 126, 125, 1, 'S'),
(93, 126, 124, 2, 'S'),
(94, 126, 123, 3, 'S'),
(95, 126, 122, 4, 'S'),
(96, 126, 121, 5, 'S'),
(97, 126, 78, 6, 'S'),
(98, 126, 1, 7, 'S'),
(99, 127, 78, 1, 'S'),
(100, 127, 1, 2, 'S'),
(101, 128, 78, 1, 'S'),
(102, 128, 1, 2, 'S'),
(103, 129, 78, 1, 'S'),
(104, 129, 1, 2, 'S'),
(105, 130, 78, 1, 'S'),
(106, 130, 1, 2, 'S'),
(107, 131, 78, 1, 'S'),
(108, 131, 1, 2, 'S'),
(109, 132, 78, 1, 'S'),
(110, 132, 1, 2, 'S'),
(111, 133, 78, 1, 'S'),
(112, 133, 1, 2, 'S'),
(113, 134, 78, 1, 'S'),
(114, 134, 1, 2, 'S'),
(115, 135, 78, 1, 'S'),
(116, 135, 1, 2, 'S'),
(117, 136, 78, 1, 'S'),
(118, 136, 1, 2, 'S'),
(119, 137, 78, 1, 'S'),
(120, 137, 1, 2, 'S');

-- --------------------------------------------------------

--
-- Table structure for table `us_user_returns`
--

CREATE TABLE `us_user_returns` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ppv` varchar(100) NOT NULL,
  `dpv` varchar(100) NOT NULL,
  `tpv` varchar(100) NOT NULL,
  `company_dpv` varchar(100) NOT NULL,
  `company_share` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `us_user_returns`
--

INSERT INTO `us_user_returns` (`id`, `user_id`, `ppv`, `dpv`, `tpv`, `company_dpv`, `company_share`) VALUES
(13, 78, '', '', '', '10.38', '3.7599999999999993'),
(52, 121, '0.072', '0.18', '0.72', '', ''),
(53, 122, '', '0.18', '', '', ''),
(54, 123, '', '0.18', '', '', ''),
(55, 124, '', '0.18', '', '', ''),
(56, 125, '0', '0.18', '', '', ''),
(57, 126, '0.18', '', '', '', ''),
(58, 127, '', '', '', '', ''),
(59, 128, '', '', '', '', ''),
(60, 129, '', '', '', '', ''),
(61, 130, '', '', '', '', ''),
(62, 131, '', '', '', '', ''),
(63, 132, '', '', '', '', ''),
(64, 133, '', '', '', '', ''),
(65, 134, '', '', '', '', ''),
(66, 135, '', '', '', '', ''),
(67, 136, '', '', '', '', ''),
(68, 137, '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `us_wml_entries`
--

CREATE TABLE `us_wml_entries` (
  `id` int(11) NOT NULL,
  `to_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `attachments` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sent_date` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `captured_gmt` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_wml_entries`
--

INSERT INTO `us_wml_entries` (`id`, `to_email`, `subject`, `message`, `headers`, `attachments`, `sent_date`, `captured_gmt`) VALUES
(1, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 15:38:58', '2021-04-06 15:38:58'),
(2, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 15:40:24', '2021-04-06 15:40:24'),
(3, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 15:42:22', '2021-04-06 15:42:22'),
(4, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 15:45:05', '2021-04-06 15:45:05'),
(5, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 15:57:54', '2021-04-06 15:57:54'),
(6, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:07:43', '2021-04-06 16:07:43'),
(7, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:09:23', '2021-04-06 16:09:23'),
(8, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:10:08', '2021-04-06 16:10:08'),
(9, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:10:21', '2021-04-06 16:10:21'),
(10, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:12:07', '2021-04-06 16:12:07'),
(11, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:14:18', '2021-04-06 16:14:18'),
(12, 'manish.bharathamitsolutions@gmail.com', 'The subject', 'this is manish mohans test', '', 'false', '2021-04-06 16:15:12', '2021-04-06 16:15:12');

-- --------------------------------------------------------

--
-- Table structure for table `us_wpmailsmtp_tasks_meta`
--

CREATE TABLE `us_wpmailsmtp_tasks_meta` (
  `id` bigint(20) NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `us_wpmailsmtp_tasks_meta`
--

INSERT INTO `us_wpmailsmtp_tasks_meta` (`id`, `action`, `data`, `date`) VALUES
(1, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-04-06 15:57:04'),
(2, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-04-19 05:56:02'),
(3, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-04-19 06:03:56'),
(4, 'wp_mail_smtp_admin_notifications_update', 'W10=', '2021-05-01 04:44:07');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `us_actionscheduler_actions`
--
ALTER TABLE `us_actionscheduler_actions`
  ADD PRIMARY KEY (`action_id`),
  ADD KEY `hook` (`hook`),
  ADD KEY `status` (`status`),
  ADD KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  ADD KEY `args` (`args`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `last_attempt_gmt` (`last_attempt_gmt`),
  ADD KEY `claim_id` (`claim_id`);

--
-- Indexes for table `us_actionscheduler_claims`
--
ALTER TABLE `us_actionscheduler_claims`
  ADD PRIMARY KEY (`claim_id`),
  ADD KEY `date_created_gmt` (`date_created_gmt`);

--
-- Indexes for table `us_actionscheduler_groups`
--
ALTER TABLE `us_actionscheduler_groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `slug` (`slug`(191));

--
-- Indexes for table `us_actionscheduler_logs`
--
ALTER TABLE `us_actionscheduler_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `action_id` (`action_id`),
  ADD KEY `log_date_gmt` (`log_date_gmt`);

--
-- Indexes for table `us_commentmeta`
--
ALTER TABLE `us_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `us_comments`
--
ALTER TABLE `us_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `us_districts`
--
ALTER TABLE `us_districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_duplicator_packages`
--
ALTER TABLE `us_duplicator_packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hash` (`hash`);

--
-- Indexes for table `us_email_log`
--
ALTER TABLE `us_email_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_links`
--
ALTER TABLE `us_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `us_options`
--
ALTER TABLE `us_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `us_postmeta`
--
ALTER TABLE `us_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `us_posts`
--
ALTER TABLE `us_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `us_purchase`
--
ALTER TABLE `us_purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_shops`
--
ALTER TABLE `us_shops`
  ADD PRIMARY KEY (`shop_id`);

--
-- Indexes for table `us_states`
--
ALTER TABLE `us_states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_termmeta`
--
ALTER TABLE `us_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `us_terms`
--
ALTER TABLE `us_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `us_term_relationships`
--
ALTER TABLE `us_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `us_term_taxonomy`
--
ALTER TABLE `us_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `us_usermeta`
--
ALTER TABLE `us_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `us_users`
--
ALTER TABLE `us_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- Indexes for table `us_user_data`
--
ALTER TABLE `us_user_data`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `us_user_relation_child`
--
ALTER TABLE `us_user_relation_child`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_user_returns`
--
ALTER TABLE `us_user_returns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_wml_entries`
--
ALTER TABLE `us_wml_entries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `us_wpmailsmtp_tasks_meta`
--
ALTER TABLE `us_wpmailsmtp_tasks_meta`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `us_actionscheduler_actions`
--
ALTER TABLE `us_actionscheduler_actions`
  MODIFY `action_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=458;

--
-- AUTO_INCREMENT for table `us_actionscheduler_claims`
--
ALTER TABLE `us_actionscheduler_claims`
  MODIFY `claim_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=91;

--
-- AUTO_INCREMENT for table `us_actionscheduler_groups`
--
ALTER TABLE `us_actionscheduler_groups`
  MODIFY `group_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `us_actionscheduler_logs`
--
ALTER TABLE `us_actionscheduler_logs`
  MODIFY `log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `us_commentmeta`
--
ALTER TABLE `us_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_comments`
--
ALTER TABLE `us_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `us_duplicator_packages`
--
ALTER TABLE `us_duplicator_packages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_email_log`
--
ALTER TABLE `us_email_log`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `us_links`
--
ALTER TABLE `us_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `us_options`
--
ALTER TABLE `us_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=985;

--
-- AUTO_INCREMENT for table `us_postmeta`
--
ALTER TABLE `us_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=448;

--
-- AUTO_INCREMENT for table `us_posts`
--
ALTER TABLE `us_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=488;

--
-- AUTO_INCREMENT for table `us_purchase`
--
ALTER TABLE `us_purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=441;

--
-- AUTO_INCREMENT for table `us_states`
--
ALTER TABLE `us_states`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `us_termmeta`
--
ALTER TABLE `us_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `us_terms`
--
ALTER TABLE `us_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `us_term_taxonomy`
--
ALTER TABLE `us_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `us_usermeta`
--
ALTER TABLE `us_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1998;

--
-- AUTO_INCREMENT for table `us_users`
--
ALTER TABLE `us_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `us_user_data`
--
ALTER TABLE `us_user_data`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `us_user_relation_child`
--
ALTER TABLE `us_user_relation_child`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `us_user_returns`
--
ALTER TABLE `us_user_returns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `us_wml_entries`
--
ALTER TABLE `us_wml_entries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `us_wpmailsmtp_tasks_meta`
--
ALTER TABLE `us_wpmailsmtp_tasks_meta`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
