
function AjaxCall(element, action, arg, handle) {    
    if ( typeof arg == 'object' ) {
        data = arg;
        if (action) data.action = action;
        //if (!data.nonce) data.nonce = nonce;
    } else if ( typeof arg == 'string' ) {
        if (action) data = "action=" + action;
        if (arg)    data = arg + "&action=" + action;
        if (arg && !action) data = arg;

        var n = data.search("nonce");
        if (n >= 0) {
            data = data + "&nonce=" + nonce;
        }
        data = data + "&is_ajax=true";
    }
    
    if( typeof(ajaxurl) == 'undefined' ) ajaxurl = ajaxurl;

    AjaxRequest = jQuery.ajax({
    type: "post",
    dataType: "json",
    url: ajaxurl,
    data: { action: action, formdata: data },
        beforeSend: function() { 
            jQuery('.progress').removeClass('d-none');
        },
        success: function( data ){
            jQuery('.progress').addClass('d-none');
            handle(data);
        }
    });    
}

// function AjaxRequest(element) {  
//     bindElement = jQuery(element);
//     bindElement.parent().children(".ajax_result").remove();
//     arg = jQuery( element ).serialize();
//     AjaxCall( bindElement, 'ajax_request', arg, function(data) {
//         bindElement.after("<div class='ajax_result'>"+data+"</div>");        
//     });    
     
// }

// $.ajax({
//     url    : ajaxurl,
//     method : 'POST',
//     data   : data,
//     success: function (result) {
//         var resultObj = $.parseJSON(result);
//         if (resultObj.success) {
//             // Redirect to the "Account" page and sync the license.
//             window.location.href = resultObj.next_page;
//         } else {
//             resetLoadingMode();
//             // Show error.
//             $('.fs-content').prepend('<p class="fs-error">' + (resultObj.error.message ?  resultObj.error.message : resultObj.error) + '</p>');
//         }
//     },
//     error: function () {
//         resetLoadingMode();
//     }
// });
