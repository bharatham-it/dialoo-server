jQuery('#user-login').submit(function () {
    event.preventDefault();
    bindElement = jQuery('#user-login');
    var action = bindElement.attr('action');
    //bindElement.parent().children(".ajax_result").remove();
    arg = bindElement.serialize();
    AjaxCall( bindElement, action, arg, function(data) {
        //bindElement.after("<div class='ajax_result'>"+data+"</div>");   
        sweetalert(data);
    }); 
});
jQuery('#user-registration').submit(function () {
    event.preventDefault();
    bindElement = jQuery('#user-registration');
    var action = bindElement.attr('action');
    arg = bindElement.serialize();
    AjaxCall( bindElement, action, arg, function(data) {
        //bindElement.after("<div class='ajax_result'>"+data+"</div>");   
        sweetalert(data);
    }); 
});
