<?php
/**
* The template for displaying the login
*
* Template Name: Wallet Template
*
* @package WordPress
* @subpackage Poultry
* @since Poultry 1.0
*/
?>
<?php
get_header();
?>




<?php
get_footer();
?>