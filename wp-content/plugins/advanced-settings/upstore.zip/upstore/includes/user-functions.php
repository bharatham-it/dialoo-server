<?php
/**
 * Used to set up and fix common variables and include
 * the WordPress procedural and class library.
 *
 * Allows for some configuration in wp-config.php (see default-constants.php)
 *
 * @package WordPress
 */
/**
 * Stores the location of the WordPress directory of functions, classes, and core content.
 *
 * @since 1.0.0
 */
if(is_user_logged_in()){
    $loggedinuser = get_current_user_data();
    $user_roles = $loggedinuser['roles'];
    $types = array();
    if(in_array('integrator',$user_roles)){
        $types = array_merge($types, array('farm', 'batch'));
    }
    $template = array();
    foreach(array_unique($types) as $type){
        if(is_array($type)){
            foreach($type as $typ){
                $template[] = TEMPLATEDIR . '/page-templates/'.$typ. '-template.php';
            }
        }else{
            $template[] = TEMPLATEDIR . '/page-templates/'.$type. '-template.php';
        }
    }
    locate_template( $template );

}

function get_role_names() {
    global $wp_roles;
    if ( ! isset( $wp_roles ) )
        $wp_roles = new WP_Roles();
    return $wp_roles->get_names();
}
    
function get_current_user_data()
{
    $current_user = wp_get_current_user();
    $user_data = array(
        'name' => $current_user->display_name, 
        'roles' => $current_user->roles, 
        'email' => $current_user->user_email
    );
    return $user_data;
}

function get_display_name($user_id) {
    if (!$user = get_userdata($user_id))
        return false;
    return $user->data->display_name;
}

function get_users_by_role($role, $orderby = 'display_name', $order='ASC')
{
    $args = array('role' => $role, 'orderby' => $orderby, 'order' => $order);
    $users = get_users($args);
    return $users;
}

add_action('wp_ajax_nopriv_submit_function_login_user', 'submit_function_login_user');
function submit_function_login_user()
{
    $get_user_data = get_form_request('formdata');
    $params = array('user_login', 'user_password','remember');
    $prefix = '';
    $build_userdata = build_form_data($get_user_data, $params, $prefix);
    $res = wp_signon($build_userdata, true);
    if (!is_wp_error($res)) {
        $user_id = $res->ID;
        wp_clear_auth_cookie();
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        $response = array('id' => $user_id, 'status' => 1, 'title' => 'success', 'subtitle' => 'Logged in sucessfully !', 'url' => $redirect_url);
    } else {
        $response = array('id' => 0, 'status' => 2, 'title' => 'failed', 'subtitle' => 'Invalid user');
    }
    $addl_response = array('redirecturl' => '');
    echo  build_response_json($response, $addl_response);
    die();
}

add_action('wp_ajax_nopriv_submit_function_register_user', 'submit_function_register_user');
function submit_function_register_user()
{
    $get_user_data = get_form_request('formdata');
    $params = array('user_login', 'user_pass', 'user_email','role');
    $prefix = '';
    $build_userdata = build_form_data($get_user_data, $params,$prefix);
    $res = wp_insert_user($build_userdata);
    $user_id = $res->ID;
    if (!is_wp_error($res)) {
        $response = array('id' => $user_id, 'status' => 1, 'title' => 'success', 'subtitle' => 'Registered in sucessfully !', 'url' => '');
    } else {
        $response = array('id' => 0, 'status' => 2, 'title' => 'failed', 'subtitle' => 'Faile user registration');
    }
    $addl_response = array('redirecturl' => '');
    echo  build_response_json($response, $addl_response);
    die();
}
function add_user_with_role()
{
    $get_data = get_form_request('formdata');
    $params = array('user_login', 'user_pass', 'user_email','role');
    $build_data = build_form_data($get_data, $params,'');
    $user_id = wp_insert_user($build_data);
    return $user_id;

}

function wp_get_menu_array($current_menu) {
 
    $array_menu = wp_get_nav_menu_items($current_menu);
    $menu = array();
    if(!empty($array_menu)){
    foreach ($array_menu as $m) {
        if (empty($m->menu_item_parent)) {
            $menu[$m->ID] = array();
            $menu[$m->ID]['ID']      =   $m->ID;
            $menu[$m->ID]['title']       =   $m->title;
            $menu[$m->ID]['url']         =   $m->url;
            $menu[$m->ID]['children']    =   array();
        }
    }
    $submenu = array();
    foreach ($array_menu as $m) {
        if ($m->menu_item_parent) {
            $submenu[$m->ID] = array();
            $submenu[$m->ID]['ID']       =   $m->ID;
            $submenu[$m->ID]['title']    =   $m->title;
            $submenu[$m->ID]['url']  =   $m->url;
            $menu[$m->menu_item_parent]['children'][$m->ID] = $submenu[$m->ID];
        }
    }
    return $menu;
}
     
}

?>