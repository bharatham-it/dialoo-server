<?php
function build_posts_args($type, $num, $status)
{
    if($num = "all"){
        $num = -1;
    }
    $get_args = array(
        'post_type' => $type,
        'posts_per_page' => $num,
        'post_status' => $status,

    );
    return $get_args;
}
?>