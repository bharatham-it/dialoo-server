<?php
function get_child_of($taxonomy, $parentid, $addl = array())
{
    $args = array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
        'child_of' => $parentid, 
    );
    if($addl) {
        $args = array_merge($args, $addl);
    }
    return get_terms($args); 
}

function get_taxonomy_name_by_post($postid, $taxonomy, $field)
{
    $list = get_the_terms( $postid, $taxonomy);
    return join(', ', wp_list_pluck($list, $field));
}

function sentenceCase($string) { 
    $sentences = preg_split('/([.?!]+)/', $string, -1,PREG_SPLIT_NO_EMPTY|PREG_SPLIT_DELIM_CAPTURE); 
    $newString = ''; 
    $sentences =str_replace('_',' ',$sentences);
    foreach ($sentences as $key => $sentence) { 
        $newString .= ($key & 1) == 0? 
            ucfirst(strtolower(trim($sentence))) : 
            $sentence.' '; 
    } 
    return trim($newString); 
}