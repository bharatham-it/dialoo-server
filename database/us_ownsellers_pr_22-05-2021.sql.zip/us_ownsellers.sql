-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2021 at 04:43 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `upstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `us_ownsellers`
--

CREATE TABLE `us_ownsellers` (
  `id` int(11) NOT NULL,
  `ownseller_id` int(11) NOT NULL,
  `ownseller_code` varchar(100) NOT NULL,
  `ownseller_name` varchar(100) NOT NULL,
  `ownseller_email` varchar(150) NOT NULL,
  `ownseller_mobile` varchar(15) NOT NULL,
  `ownseller_alt_mobile` varchar(15) NOT NULL,
  `address` varchar(250) NOT NULL,
  `town_name` varchar(100) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `district_id` varchar(30) NOT NULL,
  `street_name` varchar(50) NOT NULL,
  `landmark` varchar(100) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `status` varchar(10) NOT NULL,
  `profile_pic` int(11) NOT NULL,
  `ownseller_offer` varchar(600) NOT NULL,
  `rating` varchar(10) NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(30) NOT NULL,
  `updated_on` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `device` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `us_ownsellers`
--
ALTER TABLE `us_ownsellers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `us_ownsellers`
--
ALTER TABLE `us_ownsellers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
